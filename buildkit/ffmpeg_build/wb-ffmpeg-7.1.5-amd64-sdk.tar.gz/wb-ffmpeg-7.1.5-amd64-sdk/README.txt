Web Broadcaster FFmpeg 7.1.5 audio + URL + Icecast SDK
===========================================

This package contains the complete runtime plus C headers and relocatable
pkg-config metadata for compiling the Web Broadcaster native audio engine.

Example:
  export PKG_CONFIG_PATH="$(pwd)/lib/pkgconfig"
  cc engine.c -o wb_audio_engine \
    $(pkg-config --cflags --libs libavformat libavcodec libavfilter libavutil libswresample) \
    -Wl,-rpath,'$ORIGIN/lib'

The final Web Broadcaster installation normally needs only the runtime files,
not include/ or lib/pkgconfig/.

Read LICENSE-WARNING.txt before distribution.
