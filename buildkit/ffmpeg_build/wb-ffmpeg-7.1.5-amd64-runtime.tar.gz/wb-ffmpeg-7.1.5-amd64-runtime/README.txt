Web Broadcaster FFmpeg 7.1.5 audio + URL + Icecast runtime
===============================================

bin/ contains relocatable ffmpeg and ffprobe tools.
lib/ contains their application-local shared libraries, including
libmp3lame and libfdk-aac.

No system FFmpeg installation is required. No real video encoder or decoder is
included. HTTP, HTTPS, ICY radio streams, audio-only HLS, and Icecast output are enabled. The
runtime is intended for Debian 12 on the architecture shown in BUILD-INFO.txt.

Test:
  ./bin/ffmpeg -version
  ./bin/ffmpeg -encoders
  ./bin/ffmpeg -decoders

Read LICENSE-WARNING.txt before distribution.
