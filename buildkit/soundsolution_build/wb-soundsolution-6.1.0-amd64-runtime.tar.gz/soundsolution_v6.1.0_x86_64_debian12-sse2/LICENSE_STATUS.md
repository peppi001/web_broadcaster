# License status

No open-source license has been selected for this repository.

The project contains a clean native port produced from user-supplied
reverse-engineering and compatibility work, including reconstructed constant
and configuration data. Before making the repository public, the repository
owner should verify that they have the necessary rights to publish and
redistribute every included component.

Until a license is added by the rights holder, the absence of a license means
that normal copyright restrictions apply. Do not add an arbitrary open-source
license without completing that review.
