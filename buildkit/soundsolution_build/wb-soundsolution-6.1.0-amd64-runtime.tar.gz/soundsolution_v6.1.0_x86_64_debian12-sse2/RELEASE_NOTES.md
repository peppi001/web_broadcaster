# SoundSolution Native 6.1.0 — final generic SSE2 release

## Final production selection

Version 6.1.0 promotes the `fast-sse2-direct-r2` implementation to the stable
production engine and removes experimental naming from the runtime package.

The final implementation combines direct control flow, explicit SSE2 stereo
filters, typed cached memory regions, measured hot-path inlining, an exact banked
`pow()` result cache, generic mixed-workload PGO and LTO. The ISA remains the
generic x86-64/SSE2 baseline.

## Target-host validation

On the user's Debian 12 target, a 300.826122-second music file measured:

- strict bit-exact reference: 21.67 seconds;
- final SSE2-direct engine: 12.46 seconds;
- speedup: 1.739x;
- processing-time reduction: 42.50%.

The two 16-bit PCM outputs differed in only 4 of 26,532,864 samples. Every
difference was exactly 1 LSB; RMS error was -158.53 dBFS and measured SNR was
146.82 dB.

Timing is host-dependent. The release does not contain CPU-model-specific tuning.
