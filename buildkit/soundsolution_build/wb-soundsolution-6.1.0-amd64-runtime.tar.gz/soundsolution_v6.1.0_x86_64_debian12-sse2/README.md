# SoundSolution Native 6.1.0 — generic x86-64/SSE2 final

This is the final Debian 12 x86-64 production release of the direct SSE2 DSP engine.
It is intentionally CPU-model independent: the release is built with `-march=x86-64`
and requires only the SSE2 baseline guaranteed by x86-64. It does not require AVX,
AVX2 or FMA.

## Production engine

- direct structured process flow; no legacy VM and no hot 87-way switch;
- explicit `__m128d` stereo biquad, one-pole and fourth-order kernels;
- typed, cached and alias-qualified global/frame/audio regions;
- inlined measured hot fourth-order, dynamics and M13 paths;
- twelve exact 64-entry `pow()` result-cache banks;
- compact 16-byte cache entries using complete binary64 keys;
- generic mixed-workload PGO and LTO;
- block-size deterministic processing.

No approximate `pow()`, mantissa quantization, CPU-specific `-mtune`, AVX-family
instruction or hidden runtime dispatch is used.

## Build the final runtime

```bash
chmod +x build.sh verify.sh
./verify.sh
./build.sh
```

The runtime archive is written to:

```text
dist/soundsolution_v6.1.0_x86_64_debian12-sse2.tar.gz
```

The release build performs unit tests, PCM comparison against the strict x87
reference engine, block-size determinism tests, a 270-second continuous test,
SONAME/glibc checks and an AVX/AVX2/FMA rejection audit before packaging.

## Direct development builds

Two CMake presets are provided:

```bash
cmake --preset production-sse2
cmake --build --preset production-sse2
ctest --preset production-sse2

cmake --preset reference-bitexact
cmake --build --preset reference-bitexact
ctest --preset reference-bitexact
```

The presets do not run PGO. Use `./build.sh` for the final PGO release.

## Git release

The source tree contains `.gitignore`, `.gitattributes`, GitHub Actions CI,
release metadata and a reproducible source manifest. The intended tag is `v6.1.0`.
See `GIT_RELEASE.md`.

## Publication and licensing

No open-source license has yet been selected. Read `LICENSE_STATUS.md` before
publishing the repository, especially before making it public.
