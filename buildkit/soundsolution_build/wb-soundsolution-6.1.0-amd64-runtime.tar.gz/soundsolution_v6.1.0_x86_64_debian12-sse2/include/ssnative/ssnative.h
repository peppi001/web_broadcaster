#ifndef SSNATIVE_SSNATIVE_H
#define SSNATIVE_SSNATIVE_H

#include <stddef.h>
#include <stdint.h>

#if defined(_WIN32)
#  if defined(SSNATIVE_BUILDING_LIBRARY)
#    define SSNATIVE_API __declspec(dllexport)
#  else
#    define SSNATIVE_API __declspec(dllimport)
#  endif
#else
#  define SSNATIVE_API __attribute__((visibility("default")))
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef struct ssnative_dsp ssnative_dsp;

typedef enum ssnative_status {
    SSNATIVE_STATUS_OK = 0,
    SSNATIVE_STATUS_INVALID_ARGUMENT = 1,
    SSNATIVE_STATUS_INVALID_DAT = 2,
    SSNATIVE_STATUS_IO_ERROR = 3,
    SSNATIVE_STATUS_INVALID_AUDIO_FORMAT = 4,
    /* Retained for ABI compatibility with the first prototype; never returned. */
    SSNATIVE_STATUS_CORE_NOT_YET_PORTED = 5,
    SSNATIVE_STATUS_OUT_OF_MEMORY = 6,
    SSNATIVE_STATUS_INTERNAL_ERROR = 7
} ssnative_status;

SSNATIVE_API const char* ssnative_version(void);
SSNATIVE_API const char* ssnative_arithmetic_mode(void);
SSNATIVE_API const char* ssnative_state_layout(void);
SSNATIVE_API const char* ssnative_control_layout(void);
SSNATIVE_API size_t ssnative_state_active_bytes(void);
SSNATIVE_API size_t ssnative_state_virtual_bytes(void);
SSNATIVE_API size_t ssnative_control_stack_virtual_bytes(void);
SSNATIVE_API size_t ssnative_control_stack_physical_bytes(void);
SSNATIVE_API size_t ssnative_cold_control_stack_physical_bytes(void);
SSNATIVE_API size_t ssnative_configure_control_stack_physical_bytes(void);
SSNATIVE_API size_t ssnative_postload_control_stack_physical_bytes(void);
SSNATIVE_API size_t ssnative_control_continuation_capacity(void);
SSNATIVE_API size_t ssnative_control_executor_bytes(void);
SSNATIVE_API size_t ssnative_hot_control_cache_bytes(void);
SSNATIVE_API size_t ssnative_control_domain_count(void);
SSNATIVE_API size_t ssnative_control_continuation_state_bytes(void);
SSNATIVE_API size_t ssnative_persistent_continuation_bytes(void);
SSNATIVE_API size_t ssnative_configure_continuation_state_bytes(void);
SSNATIVE_API size_t ssnative_postload_continuation_state_bytes(void);
SSNATIVE_API size_t ssnative_native_configure_function_count(void);
SSNATIVE_API size_t ssnative_native_configure_static_operation_count(void);
SSNATIVE_API size_t ssnative_native_postload_function_count(void);
SSNATIVE_API size_t ssnative_native_postload_direct_call_count(void);
SSNATIVE_API size_t ssnative_native_postload_static_operation_count(void);
SSNATIVE_API size_t ssnative_process_program_instruction_count(void);
SSNATIVE_API size_t ssnative_process_frame_bytes(void);
SSNATIVE_API size_t ssnative_direct_process_body_count(void);
SSNATIVE_API size_t ssnative_structured_process_stage_count(void);
SSNATIVE_API size_t ssnative_persistent_process_workspace_bytes(void);

SSNATIVE_API ssnative_dsp* ssnative_create(void);
SSNATIVE_API void ssnative_destroy(ssnative_dsp* dsp);

SSNATIVE_API ssnative_status ssnative_load_dat(ssnative_dsp* dsp,
                                                const char* filename);
SSNATIVE_API ssnative_status ssnative_reset(ssnative_dsp* dsp);

SSNATIVE_API ssnative_status ssnative_process_s16_interleaved(
    ssnative_dsp* dsp,
    int16_t* samples,
    size_t frames,
    uint32_t channels,
    uint32_t sample_rate);

SSNATIVE_API const char* ssnative_last_error(const ssnative_dsp* dsp);
SSNATIVE_API const char* ssnative_status_string(ssnative_status status);

#ifdef __cplusplus
}
#endif

#endif
