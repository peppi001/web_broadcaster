#pragma once

#include <array>
#include <bit>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <span>
#include <string>
#include <string_view>

namespace ssnative {

inline constexpr std::size_t kDatFileSize = 0x47F2;
inline constexpr std::size_t kDatVersionSize = 10;
inline constexpr std::uint32_t kDatSignature = 0x00075AB3U;
inline constexpr std::size_t kProcessRecordCount = 21;
inline constexpr std::size_t kProcessRecordSize = 0x33C;
inline constexpr std::size_t kCommonBlockSize = 0x3F8;
inline constexpr std::size_t kProcessBandCount = 7;
inline constexpr std::size_t kProcessStageCount = 3;

#pragma pack(push, 1)
struct ProcessRecordRaw {
    // These seven int32 values are the only non-zero values in the supplied
    // ss18.dat. Names remain neutral until every use in the DSP is labelled.
    std::array<std::int32_t, 7> parameter{};
    std::array<std::byte, kProcessRecordSize - 7 * sizeof(std::int32_t)> reserved{};
};

struct CommonBlockRaw {
    std::array<char, 60> name{};
    std::array<std::int32_t, (kCommonBlockSize - 60) / sizeof(std::int32_t)> parameter{};
};

struct DatImageRaw {
    std::array<char, kDatVersionSize> version{};
    std::uint32_t signature{};
    std::array<ProcessRecordRaw, kProcessRecordCount> process{};
    CommonBlockRaw common{};
};
#pragma pack(pop)

static_assert(std::endian::native == std::endian::little,
              "Sound Solution DAT support currently requires a little-endian host");
static_assert(sizeof(ProcessRecordRaw) == kProcessRecordSize);
static_assert(sizeof(CommonBlockRaw) == kCommonBlockSize);
static_assert(sizeof(DatImageRaw) == kDatFileSize);

// The DLL traverses the 21 records as seven rows and three stages.
[[nodiscard]] constexpr std::size_t process_index(
    const std::size_t band,
    const std::size_t stage) noexcept {
    return band * kProcessStageCount + stage;
}

class DatFile {
public:
    DatFile() = default;

    [[nodiscard]] static DatFile load(const std::filesystem::path& path);
    [[nodiscard]] static DatFile from_bytes(std::span<const std::byte> bytes);

    void save(const std::filesystem::path& path) const;
    [[nodiscard]] std::array<std::byte, kDatFileSize> to_bytes() const noexcept;

    [[nodiscard]] const DatImageRaw& raw() const noexcept { return image_; }
    [[nodiscard]] DatImageRaw& raw() noexcept { return image_; }

    [[nodiscard]] std::string version_string() const;
    [[nodiscard]] std::string name() const;
    void set_name(std::string_view value);

    [[nodiscard]] const ProcessRecordRaw& process(std::size_t band, std::size_t stage) const;
    [[nodiscard]] ProcessRecordRaw& process(std::size_t band, std::size_t stage);

    [[nodiscard]] bool is_supported() const noexcept;

private:
    explicit DatFile(const DatImageRaw& image) : image_(image) {}
    DatImageRaw image_{};
};

} // namespace ssnative
