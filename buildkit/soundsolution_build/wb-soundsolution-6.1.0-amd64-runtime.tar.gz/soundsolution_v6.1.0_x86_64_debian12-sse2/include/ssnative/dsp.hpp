#pragma once

#include "ssnative/dat.hpp"

#include <cstddef>
#include <cstdint>
#include <span>
#include <memory>
#include <string>

namespace ssnative {

namespace detail { class NamedStateEngine; }

enum class ProcessStatus {
    ok,
    invalid_format,
    internal_error
};

class Dsp {
public:
    Dsp();
    ~Dsp();
    Dsp(Dsp&&) noexcept;
    Dsp& operator=(Dsp&&) noexcept;
    Dsp(const Dsp&) = delete;
    Dsp& operator=(const Dsp&) = delete;

    void load_config(const DatFile& config);
    void reset() noexcept;

    // Processes signed 16-bit interleaved PCM in place. The handle keeps all
    // delay-line, filter and dynamics state between calls.
    [[nodiscard]] ProcessStatus process_s16_interleaved(
        std::span<std::int16_t> samples,
        std::size_t channels,
        std::uint32_t sample_rate) noexcept;

    [[nodiscard]] const DatFile& config() const noexcept { return config_; }
    [[nodiscard]] const std::string& last_error() const noexcept { return last_error_; }

private:
    DatFile config_{};
    std::unique_ptr<detail::NamedStateEngine> engine_;
    std::string last_error_;
};

// Helpers already reconstructed directly from the DLL instruction sequences.
[[nodiscard]] double time_coefficient_ms(std::int32_t milliseconds,
                                         std::uint32_t sample_rate) noexcept;
[[nodiscard]] std::int32_t db_hundredths_to_pcm(std::int32_t db_hundredths) noexcept;
[[nodiscard]] std::int32_t db_tenths_to_pcm(std::int32_t db_tenths) noexcept;

} // namespace ssnative
