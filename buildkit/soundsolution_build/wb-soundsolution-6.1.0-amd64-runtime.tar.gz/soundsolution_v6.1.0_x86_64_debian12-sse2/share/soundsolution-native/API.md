# C API

The public header is `include/ssnative/ssnative.h`.

- `ssnative_version()` returns `6.1.0`.
- `ssnative_arithmetic_mode()` returns `x87-binary80-bitexact`.
- `ssnative_state_layout()` reports the direct named-state layout.
- `ssnative_create()` and `ssnative_destroy()` manage independent DSP handles.
- `ssnative_load_dat()` loads the fixed SoundSolution `.dat` configuration.
- `ssnative_process_s16_interleaved()` processes 44.1 kHz stereo S16 PCM in place.

The package includes SONAME 2 and a filename compatibility alias for SONAME 0.
