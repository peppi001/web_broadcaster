# Build and validation

```bash
SSNATIVE_RUN_LONG_VALIDATION=1 ./build.sh
```

Requirements: Debian 12 x86-64, GCC 12 or newer, CMake 3.20+, Python 3,
GNU binutils, GNU time, and Ninja or Make.

The build script creates fresh PGO data, rebuilds with profile use, runs CTest,
checks eight block sizes, validates the normal and stress corpora, optionally
runs the 270-second corpus, checks the maximum required glibc symbol version,
and creates the runtime archive under `_dist/`.
