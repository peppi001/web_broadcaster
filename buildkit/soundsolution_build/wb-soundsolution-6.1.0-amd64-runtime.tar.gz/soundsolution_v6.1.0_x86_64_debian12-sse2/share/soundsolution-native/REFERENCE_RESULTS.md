# Reference results

| Corpus | x87 bit-exact SHA-256 |
|---|---|
| 3-second output | `ea5c85b2ebb0100fa44585ec4f106a9cae8b61c16489ff358beddf6ac181d49a` |
| 30-second output | `a1a4768be678cc2bffe50828a2eb1de655d1125a9ebad063de07b1776dac3e12` |
| 30-second stress output | `7a83b7fd031719070d943dfe74d01054066ec90e9d333ea40553af3146e844b9` |
| 270-second output | `7eafc62739b028cb2bd56acf85571b025667b2726b142a95d5dfac5fb779f329` |

The 3-second result is identical at 1, 7, 64, 255, 256, 1024, 2048 and
4096-frame block sizes. All four results match the validated x86 v0.5.0 engine.

## Reference-host performance

Controlled five-run, single-CPU 30-second CPU-time medians:

| Build | Median CPU time |
|---|---:|
| v6.0.0 x86-64-v2 paired PGO | 2.19 s |
| v6.0.1 x86-64-v2 scalar PGO | 2.04 s |

The scalar result is 7.35% faster on the reference host. The v3 target did not
improve this strict x87 path, so the runtime intentionally ships generic and
v2 variants only; v3 hosts select the v2 hwcaps library. All PCM hashes above
remain unchanged.
