# Sound Solution 2.0 `.dat` format

The supplied `ss18.dat` and the DLL load routine agree on the following fixed
binary layout. All integers are little-endian.

| File offset | Size | Meaning |
|---:|---:|---|
| `0x0000` | 10 | NUL-padded version text (`2.0`) |
| `0x000A` | 4 | Signature `0x00075AB3` |
| `0x000E` | `21 × 0x33C` | Process records |
| `0x43FA` | `0x3F8` | Common block |
| total | `0x47F2` | 18,418 bytes |

## Process record ordering

The original initialization code does not iterate the records as one flat
array. It uses seven bands and three stages:

```text
record_index = band * 3 + stage
```

The supplied file has meaningful values in the first seven signed 32-bit
integers of each record. The remaining bytes are retained byte-for-byte and
are not discarded by the native parser.

## Common block

The first 60 bytes are a NUL-terminated name. In the supplied configuration:

```text
SZIVKULDI :D
```

The rest is an array of signed 32-bit settings. Unknown and reserved fields are
kept intact, so loading and saving is lossless before every field has received
a semantic name.
