# Architecture

SoundSolution Native 6.1.0 x86-64 is a direct C++20 DSP implementation.

- configure: direct stackless C++
- postload: direct stackless C++
- reset: direct named-state C++
- process: structured typed C++ stage loop
- runtime interpreter: none
- runtime instruction table: none
- audio-path allocation: none

## Numeric model

The logical persistent storage format remains IEEE-754 binary64. Live DSP
temporaries use the x86-64 SysV binary80 `long double` representation. Explicit
conversion helpers recreate every original binary64 state/scratch store and
reload point, so PGO and register allocation cannot alter the PCM. FMA
contraction and tree vectorization are disabled. The isolated hot-control cache
is 17,408 bytes because it stores binary80 values.
