# Changelog

## 6.1.0

- Promoted the generic SSE2-direct r2 implementation to the final production engine.
- Added a clean single-engine Debian 12 runtime package.
- Added Git-ready source metadata, CMake presets, dual-profile CI and release instructions.
- Added mandatory release gates for reference comparison, 270-second validation,
  block determinism, ABI/glibc limits and AVX/AVX2/FMA rejection.
- Preserved the strict x87 bit-exact engine in source as the validation reference.

## 6.0.1-fast-sse2-direct-r2

- Added generic direct-flow SSE2 engine.
- Added typed cached global/frame/audio region pointers.
- Added exact banked compact pow-result cache.
- Added mixed generic PGO selection and multi-corpus validation.
- Rejected approximate pow, quantized cache, branchless mapper, forced alignment,
  register-renaming/IPA flags, loop unrolling and CPU-specific tuning after benchmarks.

## 6.0.1-fast-sse2-r1

- Added explicit SSE2 packed-double stereo biquad, one-pole and fourth-order kernels.
- Added exact-result `pow()` cache tuning; the selected release uses 1024 entries.
- Added direct contiguous pair loads/stores while preserving binary64 values exactly.
- Selected compact dynamics, direct constant-cache addressing and no loop unrolling by measurement.
- Added fresh PGO for the SSE2-only x86-64 baseline build.
- Verified no AVX/AVX2/FMA instructions are required by the fast library.
- Reduced the stress-corpus difference from 9 samples in fast-max to 2 samples, both 1 LSB.

## 6.0.1-x86-bitexact-scalar

- Disabled the paired stereo C++ kernels for all release CPU variants.
- Selected independent scalar channel kernels to reduce x87 binary80 register pressure and spills.
- Preserved operation ordering, explicit binary64 store/reload points and all reference PCM hashes.
- Added a release-build guard that verifies stereo-pair kernels are OFF.
- Retained fresh PGO for generic x86-64 and x86-64-v2; v3 hosts use the faster v2 hwcaps build.

## 6.0.0-x86-bitexact

- Ported the Raspberry Pi 5 v6 direct structured DSP engine to Debian 12 x86-64.
- Removed the legacy VM, runtime instruction table, dispatch loop and continuations.
- Preserved x87/binary80 intermediate precision and all original binary64 stores.
- Disabled FMA contraction, arithmetic reassociation and compiler vectorization.
- Added fresh per-CPU-level PGO for x86-64, x86-64-v2 and x86-64-v3.
- Added hard hash gates for block-boundary, normal, stress and long-run PCM.
- Retained a `libsoundsolution.so.0` compatibility alias alongside SONAME 2.
- Verified byte identity against the validated x86 v0.5.0 engine.
