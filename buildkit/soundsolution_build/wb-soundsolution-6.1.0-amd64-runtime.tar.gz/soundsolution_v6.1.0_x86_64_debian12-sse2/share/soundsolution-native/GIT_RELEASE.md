# Git release procedure

Before publishing, review `LICENSE_STATUS.md` and confirm redistribution rights.

```bash
git init
git add .
git commit -m "SoundSolution Native 6.1.0 final SSE2 release"
git branch -M main
git tag -a v6.1.0 -m "SoundSolution Native 6.1.0"
```

After adding a remote:

```bash
git remote add origin <repository-url>
git push -u origin main
git push origin v6.1.0
```

Recommended release assets:

- `soundsolution-native-v6.1.0-x86_64-sse2-final-source.tar.gz`
- `soundsolution-native-v6.1.0-x86_64-sse2-final-source.zip`
- `soundsolution_v6.1.0_x86_64_debian12-sse2.tar.gz`
- `soundsolution-v6.1.0-x86_64-sse2-SHA256SUMS.txt`
