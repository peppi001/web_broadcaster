# Security

Report security-sensitive issues privately to the repository owner. Do not
include private audio, DAT files or unpublished reverse-engineering material in
public issue reports.
