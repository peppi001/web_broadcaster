cmake_minimum_required(VERSION 3.20)
project(soundsolution_native VERSION 6.1.0 LANGUAGES C CXX)

option(SSNATIVE_BUILD_TESTS "Build tests" ON)
option(SSNATIVE_ENABLE_LOOP_UNROLL "Enable compiler loop unrolling" OFF)
option(SSNATIVE_COMPACT_DYNAMICS "Outline compact dynamics kernels" ON)
option(SSNATIVE_ENABLE_STEREO_PAIR_KERNELS "Enable paired stereo C++ kernels (experimental on x86)" OFF)
option(SSNATIVE_FAST_NATIVE_DOUBLE "Use fast binary64 arithmetic instead of strict x87/binary80 emulation" OFF)
option(SSNATIVE_EXPLICIT_SSE2_PAIR "Use explicit SSE2 packed-double stereo kernels" OFF)
option(SSNATIVE_DIRECT_GOTO_FLOW "Use direct label/goto structured process flow" OFF)
option(SSNATIVE_BRANCHLESS_ADDRESS_MAP "Use branchless virtual-address region mapping" OFF)
option(SSNATIVE_FAST_POW_TABLE "Use high-accuracy table/polynomial pow approximation" OFF)
option(SSNATIVE_INLINE_FOURTH_WRAPPER "Inline fourth-order stereo wrapper" OFF)
option(SSNATIVE_INLINE_DYNAMICS_RANGE "Inline dynamics range dispatcher" OFF)
option(SSNATIVE_INLINE_M13_BLOCKS "Inline large native M13 process blocks" OFF)
option(SSNATIVE_COMPACT_POW_CACHE "Use 16-byte hashed pow cache entries" OFF)
set(SSNATIVE_POW_CACHE_SIZE "0" CACHE STRING "pow cache entries: 0, 64, 256, 512, 1024 or 2048")
set(SSNATIVE_POW_CACHE_QUANTIZE_BITS "0" CACHE STRING "low binary64 mantissa bits ignored by fast pow cache: 0, 4, 8, 12, 16, 20 or 24")
set(SSNATIVE_POW_CACHE_BANK_ENTRIES "0" CACHE STRING "per-dynamics-bank pow cache entries: 0, 32, 64 or 128")
set_property(CACHE SSNATIVE_POW_CACHE_BANK_ENTRIES PROPERTY STRINGS 0 32 64 128)
set_property(CACHE SSNATIVE_POW_CACHE_QUANTIZE_BITS PROPERTY STRINGS 0 4 8 12 16 20 24)
set_property(CACHE SSNATIVE_POW_CACHE_SIZE PROPERTY STRINGS 0 64 256 512 1024 2048)
option(SSNATIVE_M12_UNIFIED_DYNAMICS "Share one dynamics body across bands" ON)
option(SSNATIVE_M13_NATIVE_STATE_OUTPUT "Use native state/output block" ON)
option(SSNATIVE_M13_NATIVE_BAND_POST "Use native band/post block" ON)
option(SSNATIVE_M13_NATIVE_DELAY_OUTPUT "Use native delay/output block" ON)
option(SSNATIVE_M13_NATIVE_PREFILTER_SETUP "Use native prefilter setup" ON)
option(SSNATIVE_M13_NATIVE_POSTFILTER "Use native postfilter block" ON)
option(SSNATIVE_M13_OUTLINE_BIQUAD_STAGE "Outline stereo biquad body" ON)
option(SSNATIVE_M13_OUTLINE_ONE_POLE_STAGE "Outline stereo one-pole body" ON)
option(SSNATIVE_M13_OUTLINE_FOURTH_STAGE "Outline stereo fourth-order body" ON)
option(SSNATIVE_M13_OUTLINE_FILTER_BANK_STAGE "Outline filter-bank stage" OFF)
option(SSNATIVE_M12_DIRECT_CONSTANT_CACHE "Use direct immutable constant cache" OFF)

set(SSNATIVE_CPU_LEVEL "x86-64" CACHE STRING "CPU target: x86-64, x86-64-v2 or x86-64-v3")
set_property(CACHE SSNATIVE_CPU_LEVEL PROPERTY STRINGS x86-64 x86-64-v2 x86-64-v3)
set(SSNATIVE_OPTIMIZATION_LEVEL "3" CACHE STRING "Release optimization level: 2 or 3")
set_property(CACHE SSNATIVE_OPTIMIZATION_LEVEL PROPERTY STRINGS 2 3)
set(SSNATIVE_PGO_MODE "off" CACHE STRING "PGO mode: off, generate or use")
set_property(CACHE SSNATIVE_PGO_MODE PROPERTY STRINGS off generate use)
set(SSNATIVE_PGO_DIR "" CACHE PATH "Directory for GCC profile data")

string(TOLOWER "${CMAKE_SYSTEM_PROCESSOR}" SSNATIVE_SYSTEM_PROCESSOR)
if(NOT SSNATIVE_SYSTEM_PROCESSOR MATCHES "^(x86_64|amd64)$")
    message(FATAL_ERROR "This release is the strict bit-exact x86-64 build; processor=${CMAKE_SYSTEM_PROCESSOR}")
endif()
if(NOT CMAKE_CXX_COMPILER_ID STREQUAL "GNU")
    message(FATAL_ERROR "The strict x87 bit-exact build requires GCC")
endif()
if(NOT SSNATIVE_OPTIMIZATION_LEVEL MATCHES "^[23]$")
    message(FATAL_ERROR "SSNATIVE_OPTIMIZATION_LEVEL must be 2 or 3")
endif()

if(SSNATIVE_CPU_LEVEL STREQUAL "x86-64")
    set(SSNATIVE_ARCH_FLAG "-march=x86-64")
elseif(SSNATIVE_CPU_LEVEL STREQUAL "x86-64-v2")
    set(SSNATIVE_ARCH_FLAG "-march=x86-64-v2")
elseif(SSNATIVE_CPU_LEVEL STREQUAL "x86-64-v3")
    set(SSNATIVE_ARCH_FLAG "-march=x86-64-v3")
else()
    message(FATAL_ERROR "Unknown SSNATIVE_CPU_LEVEL: ${SSNATIVE_CPU_LEVEL}")
endif()

if(SSNATIVE_FAST_NATIVE_DOUBLE)
    message(STATUS "SoundSolution 6.1.0 arithmetic: production native binary64 with explicit SSE2/vectorization")
    message(STATUS "SoundSolution PCM contract: final generic SSE2 production build; minimal validated PCM deviation")
else()
    message(STATUS "SoundSolution 6.1.0 arithmetic: explicit x87/binary80 values with exact binary64 stores")
    message(STATUS "SoundSolution PCM contract: byte-identical to validated x86 v0.5.0")
endif()
message(STATUS "SoundSolution state layout: named-state-v14/structured-process-flow")
if(SSNATIVE_EXPLICIT_SSE2_PAIR AND (NOT SSNATIVE_FAST_NATIVE_DOUBLE OR NOT SSNATIVE_ENABLE_STEREO_PAIR_KERNELS))
    message(FATAL_ERROR "SSNATIVE_EXPLICIT_SSE2_PAIR requires FAST_NATIVE_DOUBLE and stereo pair kernels")
endif()
if(NOT SSNATIVE_POW_CACHE_BANK_ENTRIES MATCHES "^(0|32|64|128)$")
    message(FATAL_ERROR "SSNATIVE_POW_CACHE_BANK_ENTRIES must be 0, 32, 64 or 128")
endif()
if(NOT SSNATIVE_POW_CACHE_QUANTIZE_BITS MATCHES "^(0|4|8|12|16|20|24)$")
    message(FATAL_ERROR "SSNATIVE_POW_CACHE_QUANTIZE_BITS must be 0, 4, 8, 12, 16, 20 or 24")
endif()
if(NOT SSNATIVE_POW_CACHE_SIZE MATCHES "^(0|64|256|512|1024|2048)$")
    message(FATAL_ERROR "SSNATIVE_POW_CACHE_SIZE must be 0, 64, 256, 512, 1024 or 2048")
endif()
if(SSNATIVE_ENABLE_STEREO_PAIR_KERNELS)
    message(STATUS "SoundSolution x86 kernel mode: paired stereo kernels")
else()
    message(STATUS "SoundSolution x86 kernel mode: scalar per-channel kernels")
endif()
message(STATUS "SoundSolution CPU target: ${SSNATIVE_CPU_LEVEL} (${SSNATIVE_ARCH_FLAG})")

add_library(ssnative SHARED
    src/dat.cpp
    src/dsp.cpp
    src/c_api.cpp
    src/kernels.cpp
    src/named_state_engine.cpp
    src/glibc_compat.cpp
)
add_library(ssnative::ssnative ALIAS ssnative)
target_compile_features(ssnative PUBLIC cxx_std_20)
target_include_directories(ssnative
    PUBLIC
        $<BUILD_INTERFACE:${CMAKE_CURRENT_SOURCE_DIR}/include>
        $<INSTALL_INTERFACE:include>
)
target_compile_definitions(ssnative PRIVATE
    SSNATIVE_BUILDING_LIBRARY=1
    SSNATIVE_NATIVE_DOUBLE=1
)
if(SSNATIVE_FAST_NATIVE_DOUBLE)
    target_compile_definitions(ssnative PRIVATE SSNATIVE_FAST_NATIVE_DOUBLE=1)
else()
    target_compile_definitions(ssnative PRIVATE SSNATIVE_X86_BITEXACT_PCM=1)
endif()

foreach(definition IN ITEMS
    SSNATIVE_COMPACT_DYNAMICS
    SSNATIVE_M12_UNIFIED_DYNAMICS
    SSNATIVE_M13_NATIVE_STATE_OUTPUT
    SSNATIVE_M13_NATIVE_BAND_POST
    SSNATIVE_M13_NATIVE_DELAY_OUTPUT
    SSNATIVE_M13_NATIVE_PREFILTER_SETUP
    SSNATIVE_M13_NATIVE_POSTFILTER
    SSNATIVE_M13_OUTLINE_BIQUAD_STAGE
    SSNATIVE_M13_OUTLINE_ONE_POLE_STAGE
    SSNATIVE_M13_OUTLINE_FOURTH_STAGE
    SSNATIVE_M13_OUTLINE_FILTER_BANK_STAGE
    SSNATIVE_M12_DIRECT_CONSTANT_CACHE)
    if(${definition})
        target_compile_definitions(ssnative PRIVATE ${definition}=1)
    endif()
endforeach()
if(SSNATIVE_ENABLE_STEREO_PAIR_KERNELS)
    target_compile_definitions(ssnative PRIVATE SSNATIVE_DOUBLE_PAIR_KERNELS=1)
endif()
if(SSNATIVE_EXPLICIT_SSE2_PAIR)
    target_compile_definitions(ssnative PRIVATE SSNATIVE_EXPLICIT_SSE2_PAIR=1)
endif()
if(SSNATIVE_DIRECT_GOTO_FLOW)
    target_compile_definitions(ssnative PRIVATE SSNATIVE_DIRECT_GOTO_FLOW=1)
endif()
if(SSNATIVE_BRANCHLESS_ADDRESS_MAP)
    target_compile_definitions(ssnative PRIVATE SSNATIVE_BRANCHLESS_ADDRESS_MAP=1)
endif()
if(SSNATIVE_FAST_POW_TABLE)
    target_compile_definitions(ssnative PRIVATE SSNATIVE_FAST_POW_TABLE=1)
endif()
foreach(definition IN ITEMS
    SSNATIVE_INLINE_FOURTH_WRAPPER
    SSNATIVE_INLINE_DYNAMICS_RANGE
    SSNATIVE_INLINE_M13_BLOCKS
    SSNATIVE_COMPACT_POW_CACHE)
    if(${definition})
        target_compile_definitions(ssnative PRIVATE ${definition}=1)
    endif()
endforeach()
if(NOT SSNATIVE_POW_CACHE_SIZE STREQUAL "0")
    target_compile_definitions(ssnative PRIVATE
        SSNATIVE_M9_POW_CACHE_SIZE=${SSNATIVE_POW_CACHE_SIZE}
        SSNATIVE_POW_CACHE_QUANTIZE_BITS=${SSNATIVE_POW_CACHE_QUANTIZE_BITS}
        SSNATIVE_POW_CACHE_BANK_ENTRIES=${SSNATIVE_POW_CACHE_BANK_ENTRIES})
endif()

target_compile_options(ssnative PRIVATE
    -Wall -Wextra -Wpedantic -Wconversion -Wshadow
    $<$<CONFIG:Release>:-O${SSNATIVE_OPTIMIZATION_LEVEL}>
    $<$<CONFIG:Release>:-fno-math-errno>
    $<$<CONFIG:Release>:-fno-semantic-interposition>
    $<$<CONFIG:Release>:-fno-plt>
    $<$<CONFIG:Release>:-fno-asynchronous-unwind-tables>
    $<$<CONFIG:Release>:-fno-unwind-tables>
    $<$<CONFIG:Release>:${SSNATIVE_ARCH_FLAG}>
    $<$<AND:$<CONFIG:Release>,$<BOOL:${SSNATIVE_ENABLE_LOOP_UNROLL}>>:-funroll-loops>
)
if(SSNATIVE_FAST_NATIVE_DOUBLE)
    target_compile_options(ssnative PRIVATE
        $<$<CONFIG:Release>:-ffast-math>
        $<$<CONFIG:Release>:-ffp-contract=fast>
        $<$<CONFIG:Release>:-ftree-vectorize>
        $<$<CONFIG:Release>:-mfpmath=sse>
    )
else()
    target_compile_options(ssnative PRIVATE
        $<$<CONFIG:Release>:-ffp-contract=off>
        $<$<CONFIG:Release>:-fno-tree-vectorize>
        $<$<CONFIG:Release>:-mfpmath=387>
    )
endif()

if(NOT SSNATIVE_PGO_MODE STREQUAL "off")
    if(SSNATIVE_PGO_DIR STREQUAL "")
        message(FATAL_ERROR "SSNATIVE_PGO_DIR is required for PGO")
    endif()
    get_filename_component(SSNATIVE_PGO_DIR_ABS "${SSNATIVE_PGO_DIR}" ABSOLUTE)
    file(MAKE_DIRECTORY "${SSNATIVE_PGO_DIR_ABS}")
    if(SSNATIVE_PGO_MODE STREQUAL "generate")
        target_compile_options(ssnative PRIVATE $<$<CONFIG:Release>:-fprofile-generate=${SSNATIVE_PGO_DIR_ABS}>)
        target_link_options(ssnative PRIVATE $<$<CONFIG:Release>:-fprofile-generate=${SSNATIVE_PGO_DIR_ABS}>)
    elseif(SSNATIVE_PGO_MODE STREQUAL "use")
        target_compile_options(ssnative PRIVATE
            $<$<CONFIG:Release>:-fprofile-use=${SSNATIVE_PGO_DIR_ABS}>
            $<$<CONFIG:Release>:-fprofile-correction>)
        target_link_options(ssnative PRIVATE $<$<CONFIG:Release>:-fprofile-use=${SSNATIVE_PGO_DIR_ABS}>)
    else()
        message(FATAL_ERROR "SSNATIVE_PGO_MODE must be off, generate or use")
    endif()
endif()

target_link_options(ssnative PRIVATE -static-libstdc++ -static-libgcc)
include(CheckIPOSupported)
check_ipo_supported(RESULT SSNATIVE_IPO_SUPPORTED OUTPUT SSNATIVE_IPO_ERROR)
if(SSNATIVE_IPO_SUPPORTED)
    set_property(TARGET ssnative PROPERTY INTERPROCEDURAL_OPTIMIZATION_RELEASE TRUE)
endif()
set_target_properties(ssnative PROPERTIES
    OUTPUT_NAME soundsolution
    VERSION ${PROJECT_VERSION}
    SOVERSION 2
)

add_executable(ssdat-dump tools/ssdat_dump.cpp)
add_executable(ssdat-copy tools/ssdat_copy.cpp)
add_executable(ssnative-load-dat examples/load_dat.c)
add_executable(ssnative-process-raw tools/ssnative_process_raw.cpp)
foreach(target IN ITEMS ssdat-dump ssdat-copy ssnative-load-dat ssnative-process-raw)
    target_link_libraries(${target} PRIVATE ssnative::ssnative)
    set_target_properties(${target} PROPERTIES INSTALL_RPATH "$ORIGIN/../lib")
endforeach()
target_compile_features(ssdat-dump PRIVATE cxx_std_20)
target_compile_features(ssdat-copy PRIVATE cxx_std_20)
target_compile_features(ssnative-process-raw PRIVATE cxx_std_20)
target_compile_options(ssdat-dump PRIVATE -Wall -Wextra -Wpedantic)
target_compile_options(ssdat-copy PRIVATE -Wall -Wextra -Wpedantic)
target_compile_options(ssnative-process-raw PRIVATE -Wall -Wextra -Wpedantic)

if(SSNATIVE_BUILD_TESTS)
    enable_testing()
    add_executable(ssnative-tests tests/test_dat.cpp)
    target_link_libraries(ssnative-tests PRIVATE ssnative::ssnative)
    target_compile_features(ssnative-tests PRIVATE cxx_std_20)
    target_compile_definitions(ssnative-tests PRIVATE SSNATIVE_TEST_DAT="${CMAKE_CURRENT_SOURCE_DIR}/testdata/ss18.dat")
    add_test(NAME ssnative-dat-roundtrip COMMAND ssnative-tests)

    add_executable(ssnative-c-api-tests tests/test_c_api.cpp)
    target_link_libraries(ssnative-c-api-tests PRIVATE ssnative::ssnative)
    target_compile_features(ssnative-c-api-tests PRIVATE cxx_std_20)
    if(SSNATIVE_FAST_NATIVE_DOUBLE)
        target_compile_definitions(ssnative-c-api-tests PRIVATE SSNATIVE_EXPECT_FAST_MODE=1)
    endif()
    target_compile_definitions(ssnative-c-api-tests PRIVATE SSNATIVE_TEST_DAT="${CMAKE_CURRENT_SOURCE_DIR}/testdata/ss18.dat")
    add_test(NAME ssnative-c-api COMMAND ssnative-c-api-tests)

    add_executable(ssnative-kernel-tests tests/test_kernels.cpp)
    target_link_libraries(ssnative-kernel-tests PRIVATE ssnative::ssnative)
    target_include_directories(ssnative-kernel-tests PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/src)
    target_compile_features(ssnative-kernel-tests PRIVATE cxx_std_20)
    add_test(NAME ssnative-translated-kernels COMMAND ssnative-kernel-tests)
endif()

include(GNUInstallDirs)
install(TARGETS ssnative ssdat-dump ssdat-copy ssnative-load-dat ssnative-process-raw
    RUNTIME DESTINATION ${CMAKE_INSTALL_BINDIR}
    LIBRARY DESTINATION ${CMAKE_INSTALL_LIBDIR}
    ARCHIVE DESTINATION ${CMAKE_INSTALL_LIBDIR}
)
install(DIRECTORY include/ DESTINATION ${CMAKE_INSTALL_INCLUDEDIR})
install(FILES
    README.md CHANGELOG.md RELEASE_NOTES.md LICENSE_STATUS.md GIT_RELEASE.md
    PACKAGE-IDENTITY.txt RELEASE-MANIFEST.json VERSION VERSION.json BUILD-ID
    docs/ARCHITECTURE.md docs/API.md docs/BUILD.md docs/DAT_FORMAT.md
    docs/REFERENCE_RESULTS.md
    DESTINATION ${CMAKE_INSTALL_DATADIR}/soundsolution-native
)
install(FILES testdata/ss18.dat DESTINATION ${CMAKE_INSTALL_DATADIR}/soundsolution-native)
