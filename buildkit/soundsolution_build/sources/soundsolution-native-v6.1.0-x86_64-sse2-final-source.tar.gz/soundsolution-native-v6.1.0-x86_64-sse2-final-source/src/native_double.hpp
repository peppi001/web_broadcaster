#pragma once

// Two arithmetic modes share the same translated DSP source:
//   strict: explicit x87/binary80 intermediates and exact binary64 stores;
//   fast:   native binary64 intermediates with compiler FMA/vectorization.

#include <bit>
#include <cmath>
#include <cstdint>
#include <type_traits>
#if defined(SSNATIVE_EXPLICIT_SSE2_PAIR)
#  include <emmintrin.h>
#endif

#if defined(__GNUC__) || defined(__clang__)
#  define SSNATIVE_DOUBLE_ALWAYS_INLINE inline __attribute__((always_inline))
#else
#  define SSNATIVE_DOUBLE_ALWAYS_INLINE inline
#endif

namespace ssnative::detail {

#if defined(SSNATIVE_FAST_NATIVE_DOUBLE)
using NativeDouble = double;
static_assert(sizeof(NativeDouble) == 8, "IEEE-754 binary64 required");
#else
using NativeDouble = long double;
static_assert(sizeof(NativeDouble) == 16, "x86-64 SysV binary80 long double storage required");
static_assert(__LDBL_MANT_DIG__ == 64, "x87 binary80 precision required");
#endif

[[nodiscard]] SSNATIVE_DOUBLE_ALWAYS_INLINE NativeDouble
native_double_from_binary64_bits(const std::uint64_t bits) noexcept {
    return static_cast<NativeDouble>(std::bit_cast<double>(bits));
}

[[nodiscard]] SSNATIVE_DOUBLE_ALWAYS_INLINE std::uint64_t
native_double_round_to_binary64_bits(const NativeDouble value, NativeDouble& rounded) noexcept {
    const double binary64 = static_cast<double>(value);
    const std::uint64_t bits = std::bit_cast<std::uint64_t>(binary64);
    rounded = static_cast<NativeDouble>(binary64);
    return bits;
}

[[nodiscard]] SSNATIVE_DOUBLE_ALWAYS_INLINE std::uint64_t
native_double_to_binary64_bits(const NativeDouble value) noexcept {
    return std::bit_cast<std::uint64_t>(static_cast<double>(value));
}

[[nodiscard]] SSNATIVE_DOUBLE_ALWAYS_INLINE bool
native_double_isnan(const NativeDouble value) noexcept { return std::isnan(value); }
[[nodiscard]] SSNATIVE_DOUBLE_ALWAYS_INLINE NativeDouble
native_double_abs(const NativeDouble value) noexcept { return std::fabs(value); }
[[nodiscard]] SSNATIVE_DOUBLE_ALWAYS_INLINE NativeDouble
native_double_sqrt(const NativeDouble value) noexcept { return std::sqrt(value); }
[[nodiscard]] inline NativeDouble native_double_cos(const NativeDouble value) noexcept { return std::cos(value); }
[[nodiscard]] inline NativeDouble native_double_tan(const NativeDouble value) noexcept { return std::tan(value); }
[[nodiscard]] SSNATIVE_DOUBLE_ALWAYS_INLINE std::int64_t
native_double_trunc_to_i64(const NativeDouble value) noexcept {
    return static_cast<std::int64_t>(std::trunc(value));
}

#if defined(SSNATIVE_EXPLICIT_SSE2_PAIR)
static_assert(std::is_same_v<NativeDouble, double>,
              "Explicit SSE2 pairs require fast binary64 arithmetic");

struct alignas(16) NativeDoublePair final {
    __m128d lanes;

    SSNATIVE_DOUBLE_ALWAYS_INLINE NativeDoublePair() noexcept
        : lanes(_mm_setzero_pd()) {}
    SSNATIVE_DOUBLE_ALWAYS_INLINE NativeDoublePair(
        const NativeDouble first, const NativeDouble second) noexcept
        : lanes(_mm_set_pd(second, first)) {}
    explicit SSNATIVE_DOUBLE_ALWAYS_INLINE NativeDoublePair(
        const __m128d value) noexcept : lanes(value) {}
};

[[nodiscard]] SSNATIVE_DOUBLE_ALWAYS_INLINE NativeDouble
native_double_pair_first(const NativeDoublePair& value) noexcept {
    return _mm_cvtsd_f64(value.lanes);
}
[[nodiscard]] SSNATIVE_DOUBLE_ALWAYS_INLINE NativeDouble
native_double_pair_second(const NativeDoublePair& value) noexcept {
    return _mm_cvtsd_f64(_mm_unpackhi_pd(value.lanes, value.lanes));
}
[[nodiscard]] SSNATIVE_DOUBLE_ALWAYS_INLINE NativeDoublePair
native_double_pair_add(const NativeDoublePair& a, const NativeDoublePair& b) noexcept {
    return NativeDoublePair(_mm_add_pd(a.lanes, b.lanes));
}
[[nodiscard]] SSNATIVE_DOUBLE_ALWAYS_INLINE NativeDoublePair
native_double_pair_sub(const NativeDoublePair& a, const NativeDoublePair& b) noexcept {
    return NativeDoublePair(_mm_sub_pd(a.lanes, b.lanes));
}
[[nodiscard]] SSNATIVE_DOUBLE_ALWAYS_INLINE NativeDoublePair
native_double_pair_mul(const NativeDoublePair& a, const NativeDoublePair& b) noexcept {
    return NativeDoublePair(_mm_mul_pd(a.lanes, b.lanes));
}
[[nodiscard]] SSNATIVE_DOUBLE_ALWAYS_INLINE NativeDoublePair
native_double_pair_mul_right(const NativeDoublePair& a, const NativeDouble b) noexcept {
    return NativeDoublePair(_mm_mul_pd(a.lanes, _mm_set1_pd(b)));
}
[[nodiscard]] SSNATIVE_DOUBLE_ALWAYS_INLINE NativeDoublePair
native_double_pair_mul_left(const NativeDouble a, const NativeDoublePair& b) noexcept {
    return NativeDoublePair(_mm_mul_pd(_mm_set1_pd(a), b.lanes));
}
#else
struct NativeDoublePair final { NativeDouble first{}; NativeDouble second{}; };
[[nodiscard]] SSNATIVE_DOUBLE_ALWAYS_INLINE NativeDouble
native_double_pair_first(const NativeDoublePair& value) noexcept { return value.first; }
[[nodiscard]] SSNATIVE_DOUBLE_ALWAYS_INLINE NativeDouble
native_double_pair_second(const NativeDoublePair& value) noexcept { return value.second; }
[[nodiscard]] SSNATIVE_DOUBLE_ALWAYS_INLINE NativeDoublePair
native_double_pair_add(const NativeDoublePair& a, const NativeDoublePair& b) noexcept {
    return {a.first + b.first, a.second + b.second};
}
[[nodiscard]] SSNATIVE_DOUBLE_ALWAYS_INLINE NativeDoublePair
native_double_pair_sub(const NativeDoublePair& a, const NativeDoublePair& b) noexcept {
    return {a.first - b.first, a.second - b.second};
}
[[nodiscard]] SSNATIVE_DOUBLE_ALWAYS_INLINE NativeDoublePair
native_double_pair_mul(const NativeDoublePair& a, const NativeDoublePair& b) noexcept {
    return {a.first * b.first, a.second * b.second};
}
[[nodiscard]] SSNATIVE_DOUBLE_ALWAYS_INLINE NativeDoublePair
native_double_pair_mul_right(const NativeDoublePair& a, const NativeDouble b) noexcept {
    return {a.first * b, a.second * b};
}
[[nodiscard]] SSNATIVE_DOUBLE_ALWAYS_INLINE NativeDoublePair
native_double_pair_mul_left(const NativeDouble a, const NativeDoublePair& b) noexcept {
    return {a * b.first, a * b.second};
}
#endif
template <bool Subtract>
[[nodiscard]] SSNATIVE_DOUBLE_ALWAYS_INLINE NativeDoublePair
native_double_pair_mul_acc_right(const NativeDoublePair& accumulator,
                                 const NativeDoublePair& value,
                                 const NativeDouble coefficient) noexcept {
    const NativeDoublePair term = native_double_pair_mul_right(value, coefficient);
    if constexpr (Subtract) return native_double_pair_sub(accumulator, term);
    return native_double_pair_add(accumulator, term);
}
template <bool Subtract>
[[nodiscard]] SSNATIVE_DOUBLE_ALWAYS_INLINE NativeDoublePair
native_double_pair_mul_acc_left(const NativeDoublePair& accumulator,
                                const NativeDouble coefficient,
                                const NativeDoublePair& value) noexcept {
    return native_double_pair_mul_acc_right<Subtract>(accumulator, value, coefficient);
}

} // namespace ssnative::detail
#undef SSNATIVE_DOUBLE_ALWAYS_INLINE
