#pragma once

#include "ssnative/dat.hpp"

#include <cstddef>
#include <cstdint>
#include <span>
#include <memory>
#include <string>

namespace ssnative::detail {

[[nodiscard]] std::size_t native_process_executor_bytes() noexcept;
[[nodiscard]] std::size_t hot_control_cache_bytes() noexcept;
[[nodiscard]] std::size_t continuation_state_bytes() noexcept;
[[nodiscard]] std::size_t persistent_continuation_bytes() noexcept;

class NamedStateEngine final {
public:
    NamedStateEngine();
    ~NamedStateEngine();
    NamedStateEngine(const NamedStateEngine&) = delete;
    NamedStateEngine& operator=(const NamedStateEngine&) = delete;
    void load_config(const DatFile& config);
    void reset();
    bool process(std::span<std::int16_t> samples,
                 std::size_t channels,
                 std::uint32_t sample_rate,
                 std::string& error) noexcept;
    [[nodiscard]] bool initialized() const noexcept { return initialized_; }

private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
    bool initialized_{false};

    void initialize_static_image();
    void copy_dat(const DatFile& config);
    void run_postload();
    void run_configure();
    void build_init_tables();
    void run_reset();
};

} // namespace ssnative::detail
