#include "ssnative/dsp.hpp"

#include "named_state_engine.hpp"

#include <cmath>
#include <limits>
#include <utility>

namespace ssnative {

Dsp::Dsp() : engine_(std::make_unique<detail::NamedStateEngine>()) {}
Dsp::~Dsp() = default;
Dsp::Dsp(Dsp&&) noexcept = default;
Dsp& Dsp::operator=(Dsp&&) noexcept = default;

void Dsp::load_config(const DatFile& config) {
    config_ = config;
    engine_->load_config(config_);
    last_error_.clear();
}

void Dsp::reset() noexcept {
    try {
        if (config_.is_supported()) {
            engine_->load_config(config_);
        } else {
            engine_->reset();
        }
        last_error_.clear();
    } catch (const std::exception& error) {
        last_error_ = error.what();
    } catch (...) {
        last_error_ = "unknown DSP reset failure";
    }
}

ProcessStatus Dsp::process_s16_interleaved(
    const std::span<std::int16_t> samples,
    const std::size_t channels,
    const std::uint32_t sample_rate) noexcept {
    if ((channels != 1U && channels != 2U) || sample_rate < 44100U ||
        (samples.size() % channels) != 0U) {
        return ProcessStatus::invalid_format;
    }
    if (!engine_->process(samples, channels, sample_rate, last_error_)) {
        return ProcessStatus::internal_error;
    }
    return ProcessStatus::ok;
}

double time_coefficient_ms(const std::int32_t milliseconds,
                           const std::uint32_t sample_rate) noexcept {
    if (milliseconds <= 0 || sample_rate == 0U) return 0.0;
    return std::exp(-4600.0 /
                    (static_cast<double>(sample_rate) * static_cast<double>(milliseconds)));
}

std::int32_t db_hundredths_to_pcm(const std::int32_t db_hundredths) noexcept {
    const double value = 32767.0 * std::pow(10.0, static_cast<double>(db_hundredths) * 0.005);
    if (value >= static_cast<double>(std::numeric_limits<std::int32_t>::max())) return std::numeric_limits<std::int32_t>::max();
    if (value <= static_cast<double>(std::numeric_limits<std::int32_t>::min())) return std::numeric_limits<std::int32_t>::min();
    return static_cast<std::int32_t>(value);
}

std::int32_t db_tenths_to_pcm(const std::int32_t db_tenths) noexcept {
    const double value = 32767.0 * std::pow(10.0, static_cast<double>(db_tenths) * 0.05);
    if (value >= static_cast<double>(std::numeric_limits<std::int32_t>::max())) return std::numeric_limits<std::int32_t>::max();
    if (value <= static_cast<double>(std::numeric_limits<std::int32_t>::min())) return std::numeric_limits<std::int32_t>::min();
    return static_cast<std::int32_t>(value);
}

} // namespace ssnative
