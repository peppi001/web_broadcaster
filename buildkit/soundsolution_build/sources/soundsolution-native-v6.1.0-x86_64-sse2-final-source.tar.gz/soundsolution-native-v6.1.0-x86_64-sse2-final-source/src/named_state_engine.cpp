#include "named_state_engine.hpp"
#include "native_double.hpp"
#include "named_state_layout.hpp"
#include "native_process_layout.hpp"

#include <algorithm>
#include <array>
#include <bit>
#include <cmath>
#include <cstring>
#include <limits>
#include <stdexcept>
#include <string_view>
#include <utility>


#if defined(SSNATIVE_NO_FORCE_INLINE)
#  define SSNATIVE_ALWAYS_INLINE inline
#else
#  define SSNATIVE_ALWAYS_INLINE __attribute__((always_inline)) inline
#endif

namespace ssnative::detail {
namespace {

namespace state_address = named_state::address;

constexpr std::uint32_t kGlobalBase = 0x1000c000u;
constexpr std::uint32_t kGlobalEnd = 0x10110000u;
constexpr std::uint32_t kAudioBase = 0x20000000u;

static constexpr std::uint8_t kRdata[] = {
#include "original_rdata.inc"
};
static constexpr std::uint8_t kData[] = {
#include "original_data.inc"
};

// Named-state storage foundation.  The compatibility address space remains
// contiguous on Raspberry Pi 5 so every translated hot-path access is still
// one subtraction.  Allocation is intentionally uninitialized and clear()
// touches only the three proven live regions; the 421888-byte holes therefore
// consume virtual address space but are never initialized or used by the DSP.
class NamedStateStorage final {
public:
    static constexpr std::size_t kCompatibilityVirtualBytes =
        named_state::kCompatibilityVirtualBytes;
    static constexpr std::size_t kActiveBytes = named_state::kPhysicalBytes;

    NamedStateStorage()
        : storage_(std::make_unique_for_overwrite<std::byte[]>(
              kCompatibilityVirtualBytes)) {}

    void clear() noexcept {
        clear_range(named_state::kConstantsBase, named_state::kConstantsEnd);
        clear_range(named_state::kRuntimeBase, named_state::kRuntimeEnd);
        clear_range(named_state::kConfigurationBase,
                    named_state::kConfigurationEnd);
    }

    template<std::uint32_t Address, std::size_t Size>
    [[nodiscard]] SSNATIVE_ALWAYS_INLINE std::byte* ptr_static() noexcept {
        static_assert(named_state::contains_static(Address, Size),
                      "unmapped named-state static address");
        return storage_.get() + (Address - named_state::kVirtualBase);
    }

    template<std::uint32_t Address, std::size_t Size>
    [[nodiscard]] SSNATIVE_ALWAYS_INLINE const std::byte* ptr_static() const noexcept {
        return const_cast<NamedStateStorage*>(this)->template ptr_static<Address, Size>();
    }

    template<std::uint32_t Address, std::size_t Size>
    SSNATIVE_ALWAYS_INLINE void zero_static() noexcept {
        static_assert(named_state::contains_static(Address, Size),
                      "unmapped named-state static zero range");
        std::fill_n(ptr_static<Address, Size>(), Size, std::byte{});
    }

    [[nodiscard]] SSNATIVE_ALWAYS_INLINE std::byte* ptr(
        const std::uint32_t address, const std::size_t size) {
#if !defined(NDEBUG)
        const auto end = static_cast<std::uint64_t>(address) + size;
        const bool mapped =
            (address >= named_state::kConstantsBase &&
             end <= named_state::kConstantsEnd) ||
            (address >= named_state::kRuntimeBase &&
             end <= named_state::kRuntimeEnd) ||
            (address >= named_state::kConfigurationBase &&
             end <= named_state::kConfigurationEnd);
        if (!mapped) {
            throw std::runtime_error(
                "named-state access outside the proven live regions 0x" +
                hex(address));
        }
#else
        (void)size;
#endif
        return storage_.get() + (address - named_state::kVirtualBase);
    }

    [[nodiscard]] SSNATIVE_ALWAYS_INLINE const std::byte* ptr(
        const std::uint32_t address, const std::size_t size) const {
        return const_cast<NamedStateStorage*>(this)->ptr(address, size);
    }

    void copy_from(const std::uint32_t address, const void* source,
                   const std::size_t size) {
        std::memcpy(ptr(address, size), source, size);
    }

private:
    void clear_range(const std::uint32_t begin,
                     const std::uint32_t end) noexcept {
        std::fill_n(storage_.get() + (begin - named_state::kVirtualBase),
                    static_cast<std::size_t>(end - begin), std::byte{});
    }

    [[nodiscard]] static std::string hex(std::uint32_t value) {
        constexpr char digits[] = "0123456789abcdef";
        std::string result(8, '0');
        for (int index = 7; index >= 0; --index) {
            result[static_cast<std::size_t>(index)] = digits[value & 15u];
            value >>= 4u;
        }
        return result;
    }

    std::unique_ptr<std::byte[]> storage_;
};

static_assert(NamedStateStorage::kCompatibilityVirtualBytes == 1064960u);
static_assert(NamedStateStorage::kActiveBytes == 643072u);
static_assert(native_process::kProcessFrameBytes == 512u);
static_assert(native_process::kConfigureStackPhysicalBytes == 0u);
static_assert(native_process::kPostloadStackPhysicalBytes == 0u);
static_assert(native_process::kColdStackPhysicalBytes == 0u);

struct ProcessCondition { bool carry{}, zero{}, negative{}, overflow{}; };

struct ProcessFlow final {
    std::uint32_t value_a{}, value_b{}, value_c{}, value_d{};
    std::uint32_t index{}, pointer{}, frame_cursor{}, frame_base{};
    ProcessCondition condition{};
};

struct ProcessFloatingValues final {
    std::uint16_t comparison_status{};
    std::array<NativeDouble, 8> temporary{};
};

struct ProcessCallState final {
    ProcessFlow flow{};
    ProcessFloatingValues floating{};
    alignas(64) std::array<std::byte,
        native_process::kProcessFrameBytes> frame{};
    std::span<std::byte> audio{};
    static constexpr std::uint32_t kFrameBase = native_process::kFrameCompatibilityBase;

    [[nodiscard]] static consteval std::size_t frame_size() noexcept {
        return native_process::kProcessFrameBytes;
    }
};

struct HotControlCaches final {
    static constexpr std::uint32_t kConstantF64Base = 0x1000c000u;
    static constexpr std::uint32_t kConstantF64End = 0x1000e000u;
    static constexpr std::size_t kConstantF64Count =
        (kConstantF64End - kConstantF64Base) / sizeof(std::uint64_t);
    static constexpr std::uint32_t kFilterF64Base = 0x100d7600u;
    static constexpr std::uint32_t kFilterF64End = 0x100d7800u;
    static constexpr std::size_t kFilterF64Count =
        (kFilterF64End - kFilterF64Base) / sizeof(std::uint64_t);

    std::array<NativeDouble, kConstantF64Count> constant_f64{};
    std::array<NativeDouble, kFilterF64Count> filter_f64{};
#if defined(SSNATIVE_FAST_POW_TABLE)
    static constexpr std::size_t kPowTableSize = 256u;
    std::array<double, kPowTableSize> pow_log2_center{};
    std::array<double, kPowTableSize> pow_inv_center{};
    std::array<double, kPowTableSize> pow_exp2_fraction{};
#endif
#if defined(SSNATIVE_M9_POW_CACHE_SIZE)
    static_assert(SSNATIVE_M9_POW_CACHE_SIZE == 64 ||
                  SSNATIVE_M9_POW_CACHE_SIZE == 256 ||
                  SSNATIVE_M9_POW_CACHE_SIZE == 512 ||
                  SSNATIVE_M9_POW_CACHE_SIZE == 1024 ||
                  SSNATIVE_M9_POW_CACHE_SIZE == 2048);
#if defined(SSNATIVE_COMPACT_POW_CACHE)
    struct PowCacheEntry final {
        std::uint64_t key{UINT64_MAX};
        std::uint64_t result_bits{};
    };
    static_assert(sizeof(PowCacheEntry) == 16u);
#else
    struct PowCacheEntry final {
        std::uint64_t base_bits{};
        std::uint64_t exponent_bits{UINT64_MAX};
        std::uint64_t result_bits{};
    };
    static_assert(sizeof(PowCacheEntry) == 24u);
#endif
#if SSNATIVE_POW_CACHE_BANK_ENTRIES > 0
    static constexpr std::size_t kPowBankCount = 12u;
    std::array<std::array<PowCacheEntry, SSNATIVE_POW_CACHE_BANK_ENTRIES>,
               kPowBankCount> pow_banks{};
#else
    std::array<PowCacheEntry, SSNATIVE_M9_POW_CACHE_SIZE> pow{};
#endif
#endif
};

static_assert(HotControlCaches::kConstantF64Count == 1024u);
static_assert(HotControlCaches::kFilterF64Count == 64u);

class NativeProcessExecutor {
public:
    NativeProcessExecutor(NamedStateStorage& globals,
                          HotControlCaches* hot_caches = nullptr) noexcept
        : globals_(globals), hot_caches_(hot_caches),
          global_bytes_(globals.ptr(kGlobalBase, 1u)) {
#if defined(SSNATIVE_BRANCHLESS_ADDRESS_MAP)
        address_region_ptr_[0x1u] = globals_.ptr(kGlobalBase, 1u);
        address_region_base_[0x1u] = kGlobalBase;
#endif
    }

    void run_process(const std::span<const std::uint32_t> args,
                     std::span<std::int16_t> input) {
        ProcessCallState call{};
        call.audio = std::as_writable_bytes(input);
        frame_bytes_ = call.frame.data();
        audio_bytes_ = call.audio.data();
#if !defined(NDEBUG)
        if (active_call_ != nullptr) {
            throw std::runtime_error("native process executor is not reentrant");
        }
#endif
        active_call_ = &call;
#if defined(SSNATIVE_BRANCHLESS_ADDRESS_MAP)
        prepare_address_biases(call);
#endif
        try {
            begin_native_process_call(args);
            execute_native_process();
        } catch (...) {
            active_call_ = nullptr;
            throw;
        }
        active_call_ = nullptr;
    }

    void reset_named_state() noexcept {
        globals_.template zero_static<named_state::reset::dynamics_a_base,
                                      named_state::reset::dynamics_a_bytes>();
        globals_.template zero_static<named_state::reset::dynamics_b_base,
                                      named_state::reset::dynamics_b_bytes>();
        globals_.template zero_static<named_state::reset::delay_state_base,
                                      named_state::reset::delay_state_bytes>();
    }

    std::uint32_t read_global_u32(std::uint32_t address) const { return read_u32(address); }
    void write_global_u32(std::uint32_t address, std::uint32_t value) { write_u32(address, value); }
    double read_global_f64(std::uint32_t address) const { return read_f64(address); }
    void write_global_f64(std::uint32_t address, double value) { write_f64(address, value); }

    void prepare_hot_constants() {
        if (hot_caches_ == nullptr) {
            throw std::logic_error("hot constant cache is unavailable in cold-process executor");
        }
        for (std::size_t i = 0; i < hot_caches_->constant_f64.size(); ++i) {
            const auto address = HotControlCaches::kConstantF64Base +
                static_cast<std::uint32_t>(i * sizeof(std::uint64_t));
            hot_caches_->constant_f64[i] = native_double_from_binary64_bits(read_u64(address));
        }
        for (std::size_t i = 0; i < hot_caches_->filter_f64.size(); ++i) {
            const auto address = HotControlCaches::kFilterF64Base +
                static_cast<std::uint32_t>(i * sizeof(std::uint64_t));
            hot_caches_->filter_f64[i] = native_double_from_binary64_bits(read_u64(address));
        }
#if defined(SSNATIVE_FAST_POW_TABLE)
        for (std::size_t i = 0; i < HotControlCaches::kPowTableSize; ++i) {
            const double lower = static_cast<double>(i) /
                static_cast<double>(HotControlCaches::kPowTableSize);
            const double center = 1.0 + lower +
                0.5 / static_cast<double>(HotControlCaches::kPowTableSize);
            hot_caches_->pow_log2_center[i] = std::log2(center);
            hot_caches_->pow_inv_center[i] = 1.0 / center;
            hot_caches_->pow_exp2_fraction[i] = std::exp2(lower);
        }
#endif
#if defined(SSNATIVE_M9_POW_CACHE_SIZE)
#if SSNATIVE_POW_CACHE_BANK_ENTRIES > 0
        for (auto& bank : hot_caches_->pow_banks) bank.fill({});
#else
        hot_caches_->pow.fill({});
#endif
#endif
    }

private:
    NamedStateStorage& globals_;
    HotControlCaches* hot_caches_{};
    ProcessCallState* active_call_{};
    std::byte* global_bytes_{};
    std::byte* frame_bytes_{};
    std::byte* audio_bytes_{};
#if defined(SSNATIVE_BRANCHLESS_ADDRESS_MAP)
    std::array<std::byte*, 8u> address_region_ptr_{};
    std::array<std::uint32_t, 8u> address_region_base_{};
#endif

    [[nodiscard]] SSNATIVE_ALWAYS_INLINE ProcessCallState& call_state() noexcept {
#if !defined(NDEBUG)
        if (active_call_ == nullptr) __builtin_trap();
#endif
        return *active_call_;
    }

    [[nodiscard]] SSNATIVE_ALWAYS_INLINE const ProcessCallState& call_state() const noexcept {
        return const_cast<NativeProcessExecutor*>(this)->call_state();
    }

    void begin_native_process_call(const std::span<const std::uint32_t> args = {}) {
        reset_process_frame();
        for (auto it = args.rbegin(); it != args.rend(); ++it) push32(*it);
    }

#if defined(SSNATIVE_BRANCHLESS_ADDRESS_MAP)
    SSNATIVE_ALWAYS_INLINE void prepare_address_biases(ProcessCallState& call) noexcept {
        address_region_ptr_[0x1u] = globals_.ptr(kGlobalBase, 1u);
        address_region_base_[0x1u] = kGlobalBase;
        address_region_ptr_[0x2u] = call.audio.data();
        address_region_base_[0x2u] = kAudioBase;
        address_region_ptr_[0x7u] = call.frame.data();
        address_region_base_[0x7u] = ProcessCallState::kFrameBase;
    }
#endif

    void reset_process_frame() noexcept {
        call_state().flow = ProcessFlow{};
        call_state().floating = ProcessFloatingValues{};
        call_state().flow.frame_cursor = native_process::kInitialFrameCursor;
        // The frame backing is selected by executor lifetime: 512 bytes for
        // the process executor and 1536 bytes for the ephemeral
        // configure/postload executor. Return addresses live in the typed
        // native continuation stack and do not consume process frame storage.
        std::fill(call_state().frame.begin(), call_state().frame.end(), std::byte{});
    }

    [[nodiscard]] SSNATIVE_ALWAYS_INLINE std::byte* ptr(std::uint32_t address, std::size_t size) {
#if !defined(NDEBUG)
        if (address >= kGlobalBase && static_cast<std::uint64_t>(address) + size <= kGlobalEnd)
            return globals_.ptr(address, size);
        if (address >= ProcessCallState::kFrameBase &&
            static_cast<std::uint64_t>(address) + size <= native_process::kFrameCompatibilityEnd)
            return call_state().frame.data() + (address - ProcessCallState::kFrameBase);
        if (address >= kAudioBase && static_cast<std::uint64_t>(address) + size <= static_cast<std::uint64_t>(kAudioBase) + call_state().audio.size())
            return call_state().audio.data() + (address - kAudioBase);
        throw std::runtime_error("native process invalid memory address 0x" + hex(address));
#else
        (void)size;
#if defined(SSNATIVE_BRANCHLESS_ADDRESS_MAP)
        const auto region = static_cast<std::size_t>(address >> 28u);
        return address_region_ptr_[region] +
            static_cast<std::size_t>(address - address_region_base_[region]);
#else
        switch (address >> 28u) {
        case 0x1u: return global_bytes_ +
            static_cast<std::size_t>(address - kGlobalBase);
        case 0x2u: return audio_bytes_ +
            static_cast<std::size_t>(address - kAudioBase);
        case 0x7u: return frame_bytes_ +
            static_cast<std::size_t>(address - ProcessCallState::kFrameBase);
        default: __builtin_unreachable();
        }
#endif
#endif
    }
    [[nodiscard]] SSNATIVE_ALWAYS_INLINE const std::byte* ptr(std::uint32_t address, std::size_t size) const {
        return const_cast<NativeProcessExecutor*>(this)->ptr(address, size);
    }
    static std::string hex(std::uint32_t v) {
        constexpr char digits[] = "0123456789abcdef";
        std::string s(8, '0');
        for (int i = 7; i >= 0; --i) { s[static_cast<std::size_t>(i)] = digits[v & 15u]; v >>= 4u; }
        return s;
    }
    template<class T> [[nodiscard]] SSNATIVE_ALWAYS_INLINE T read_t(std::uint32_t address) const {
        T v{}; std::memcpy(&v, ptr(address, sizeof(T)), sizeof(T)); return v;
    }
    template<class T> SSNATIVE_ALWAYS_INLINE void write_t(std::uint32_t address, T value) {
        std::memcpy(ptr(address, sizeof(T)), &value, sizeof(T));
    }
    [[nodiscard]] SSNATIVE_ALWAYS_INLINE std::uint8_t read_u8(std::uint32_t a) const { return read_t<std::uint8_t>(a); }
    [[nodiscard]] SSNATIVE_ALWAYS_INLINE std::uint16_t read_u16(std::uint32_t a) const { return read_t<std::uint16_t>(a); }
    [[nodiscard]] SSNATIVE_ALWAYS_INLINE std::uint32_t read_u32(std::uint32_t a) const { return read_t<std::uint32_t>(a); }
    [[nodiscard]] SSNATIVE_ALWAYS_INLINE std::uint64_t read_u64(std::uint32_t a) const { return read_t<std::uint64_t>(a); }
    [[nodiscard]] SSNATIVE_ALWAYS_INLINE double read_f64(std::uint32_t a) const { return std::bit_cast<double>(read_u64(a)); }
    SSNATIVE_ALWAYS_INLINE void write_u8(std::uint32_t a, std::uint8_t v) { write_t(a,v); }
    SSNATIVE_ALWAYS_INLINE void write_u16(std::uint32_t a, std::uint16_t v) { write_t(a,v); }
    SSNATIVE_ALWAYS_INLINE void write_u32(std::uint32_t a, std::uint32_t v) { write_t(a,v); }
    SSNATIVE_ALWAYS_INLINE void write_u64(std::uint32_t a, std::uint64_t v) { write_t(a,v); }
    SSNATIVE_ALWAYS_INLINE void write_f64(std::uint32_t a, double v) { write_u64(a, std::bit_cast<std::uint64_t>(v)); }

    SSNATIVE_ALWAYS_INLINE void push32(std::uint32_t v) { call_state().flow.frame_cursor-=4u; write_u32(call_state().flow.frame_cursor,v); }
    SSNATIVE_ALWAYS_INLINE std::uint32_t pop32() { const auto v=read_u32(call_state().flow.frame_cursor);call_state().flow.frame_cursor+=4u;return v; }


    __attribute__((always_inline)) static inline std::uint32_t mask(unsigned bits) { return bits==32?0xffffffffu:((1u<<bits)-1u); }
    SSNATIVE_ALWAYS_INLINE void update_logic_condition(std::uint32_t r,unsigned bits) { r&=mask(bits);call_state().flow.condition={false,r==0u,(r&(1u<<(bits-1u)))!=0u,false}; }
    SSNATIVE_ALWAYS_INLINE void update_sub_condition(std::uint32_t a,std::uint32_t b,std::uint32_t r,unsigned bits) {
        const auto m=mask(bits),s=1u<<(bits-1u);a&=m;b&=m;r&=m;call_state().flow.condition.carry=a<b;call_state().flow.condition.zero=r==0;call_state().flow.condition.negative=(r&s)!=0;call_state().flow.condition.overflow=(((a^b)&(a^r)&s)!=0);
    }
    SSNATIVE_ALWAYS_INLINE void update_add_condition(std::uint32_t a,std::uint32_t b,std::uint32_t r,unsigned bits) {
        const auto m=mask(bits),s=1u<<(bits-1u);const std::uint64_t wide=static_cast<std::uint64_t>(a&m)+(b&m);r&=m;call_state().flow.condition.carry=(wide>>bits)!=0;call_state().flow.condition.zero=r==0;call_state().flow.condition.negative=(r&s)!=0;call_state().flow.condition.overflow=(((~(a^b))&(a^r)&s)!=0);
    }
    SSNATIVE_ALWAYS_INLINE void update_float_condition(NativeDouble a,NativeDouble b) {
        call_state().floating.comparison_status &= static_cast<std::uint16_t>(~((1u<<8u)|(1u<<10u)|(1u<<14u)));
        if(native_double_isnan(a)||native_double_isnan(b))call_state().floating.comparison_status|=(1u<<8u)|(1u<<10u)|(1u<<14u);
        else if(a<b)call_state().floating.comparison_status|=(1u<<8u); else if(a==b)call_state().floating.comparison_status|=(1u<<14u);
    }

    SSNATIVE_ALWAYS_INLINE void truncate_native_double_to_i64_parts(NativeDouble value) {
        std::int64_t converted{};
        if (native_double_isnan(value)) {
            converted = std::numeric_limits<std::int64_t>::min();
        } else if (value >= static_cast<NativeDouble>(std::numeric_limits<std::int64_t>::max())) {
            converted = std::numeric_limits<std::int64_t>::max();
        } else if (value <= static_cast<NativeDouble>(std::numeric_limits<std::int64_t>::min())) {
            converted = std::numeric_limits<std::int64_t>::min();
        } else {
            converted = native_double_trunc_to_i64(value);
        }
        call_state().flow.value_a = static_cast<std::uint32_t>(converted);
        call_state().flow.value_d = static_cast<std::uint32_t>(
            static_cast<std::uint64_t>(converted) >> 32u);
    }

    SSNATIVE_ALWAYS_INLINE void copy_guest_u64(std::uint32_t destination, std::uint32_t source) {
        write_u64(destination, read_u64(source));
    }

    [[nodiscard]] SSNATIVE_ALWAYS_INLINE NativeDouble guest_f64(std::uint32_t address) const {
        return native_double_from_binary64_bits(read_u64(address));
    }

    SSNATIVE_ALWAYS_INLINE void guest_store_f64(std::uint32_t address, NativeDouble value) {
        write_u64(address, native_double_to_binary64_bits(value));
    }


#if defined(SSNATIVE_DOUBLE_PAIR_KERNELS)
    [[nodiscard]] SSNATIVE_ALWAYS_INLINE NativeDoublePair guest_f64_pair(
        std::uint32_t first, std::uint32_t second) const {
#if defined(SSNATIVE_SOFT_X87) && defined(SSNATIVE_M11_PAIR_FROM64)
        NativeDoublePair value;
        NativeDouble::from_binary64_pair_bits(
            read_u64(first), read_u64(second), value.first, value.second);
        return value;
#elif defined(SSNATIVE_EXPLICIT_SSE2_PAIR)
        if (__builtin_expect(second == first + 8u, 1)) {
            return NativeDoublePair(_mm_loadu_pd(
                reinterpret_cast<const double*>(ptr(first, 16u))));
        }
        return {guest_f64(first), guest_f64(second)};
#else
        return {guest_f64(first), guest_f64(second)};
#endif
    }

    SSNATIVE_ALWAYS_INLINE void guest_store_f64_pair(
        std::uint32_t first, std::uint32_t second,
        const NativeDoublePair& value) {
#if defined(SSNATIVE_SOFT_X87) && defined(SSNATIVE_M11_PAIR_TO64)
        std::uint64_t first_bits{};
        std::uint64_t second_bits{};
        NativeDouble::to_binary64_pair_bits(
            value.first, value.second, first_bits, second_bits);
        write_u64(first, first_bits);
        write_u64(second, second_bits);
#elif defined(SSNATIVE_EXPLICIT_SSE2_PAIR)
        if (__builtin_expect(second == first + 8u, 1)) {
            _mm_storeu_pd(reinterpret_cast<double*>(ptr(first, 16u)), value.lanes);
            return;
        }
        guest_store_f64(first, native_double_pair_first(value));
        guest_store_f64(second, native_double_pair_second(value));
#else
        guest_store_f64(first, native_double_pair_first(value));
        guest_store_f64(second, native_double_pair_second(value));
#endif
    }
#endif

    template<class T>
    [[nodiscard]] static SSNATIVE_ALWAYS_INLINE T read_global_direct(
        const std::byte* __restrict__ global_bytes, const std::uint32_t address) noexcept {
        T value{};
        std::memcpy(&value, global_bytes +
            static_cast<std::size_t>(address - kGlobalBase), sizeof(T));
        return value;
    }

    template<class T>
    static SSNATIVE_ALWAYS_INLINE void write_global_direct(
        std::byte* __restrict__ global_bytes, const std::uint32_t address, const T value) noexcept {
        std::memcpy(global_bytes +
            static_cast<std::size_t>(address - kGlobalBase), &value, sizeof(T));
    }

    template<class T>
    [[nodiscard]] static SSNATIVE_ALWAYS_INLINE T read_frame_direct(
        const std::byte* __restrict__ frame_bytes, const std::uint32_t address) noexcept {
        T value{};
        std::memcpy(&value, frame_bytes +
            static_cast<std::size_t>(address - ProcessCallState::kFrameBase),
            sizeof(T));
        return value;
    }

    template<class T>
    static SSNATIVE_ALWAYS_INLINE void write_frame_direct(
        std::byte* __restrict__ frame_bytes, const std::uint32_t address, const T value) noexcept {
        std::memcpy(frame_bytes +
            static_cast<std::size_t>(address - ProcessCallState::kFrameBase),
            &value, sizeof(T));
    }

    template<class T>
    [[nodiscard]] SSNATIVE_ALWAYS_INLINE T read_global_fast(std::uint32_t address) const {
        T value{};
        std::memcpy(&value, global_bytes_ +
            static_cast<std::size_t>(address - kGlobalBase), sizeof(T));
        return value;
    }

    template<class T>
    SSNATIVE_ALWAYS_INLINE void write_global_fast(std::uint32_t address, T value) {
        std::memcpy(global_bytes_ +
            static_cast<std::size_t>(address - kGlobalBase), &value, sizeof(T));
    }

    [[nodiscard]] SSNATIVE_ALWAYS_INLINE std::uint32_t global_u32(std::uint32_t address) const {
        return read_global_fast<std::uint32_t>(address);
    }
    SSNATIVE_ALWAYS_INLINE void global_store_u32(std::uint32_t address, std::uint32_t value) {
        write_global_fast<std::uint32_t>(address, value);
    }
    [[nodiscard]] SSNATIVE_ALWAYS_INLINE NativeDouble global_f64(std::uint32_t address) const {
        return native_double_from_binary64_bits(read_global_fast<std::uint64_t>(address));
    }
    [[nodiscard]] SSNATIVE_ALWAYS_INLINE NativeDouble constant_f64(
        std::uint32_t address) const noexcept {
#if !defined(NDEBUG)
        if (hot_caches_ == nullptr) {
            __builtin_trap();
        }
#endif
#if defined(SSNATIVE_M12_DIRECT_CONSTANT_CACHE)
        // The translated process profile overwhelmingly uses the immutable
        // 0x1000c000 table.  Preserve the second table for configuration and
        // unusual filter pointers, but give the hot branch an explicit bias.
        if (address < HotControlCaches::kConstantF64End) [[likely]] {
            return hot_caches_->constant_f64[
                static_cast<std::size_t>((address - HotControlCaches::kConstantF64Base) >> 3u)];
        }
#else
        if (address < HotControlCaches::kConstantF64End) {
            return hot_caches_->constant_f64[
                static_cast<std::size_t>((address - HotControlCaches::kConstantF64Base) >> 3u)];
        }
#endif
        return hot_caches_->filter_f64[
            static_cast<std::size_t>((address - HotControlCaches::kFilterF64Base) >> 3u)];
    }
    SSNATIVE_ALWAYS_INLINE void global_store_f64(std::uint32_t address, NativeDouble value) {
        write_global_fast<std::uint64_t>(address, native_double_to_binary64_bits(value));
    }

    [[nodiscard]] SSNATIVE_ALWAYS_INLINE NativeDouble global_round_store_f64(
        std::uint32_t address, NativeDouble value) {
#if defined(SSNATIVE_DIRECT_ROUND_STORE)
        NativeDouble rounded;
        const std::uint64_t bits = native_double_round_to_binary64_bits(value, rounded);
        write_global_fast<std::uint64_t>(address, bits);
        return rounded;
#else
        const std::uint64_t bits = native_double_to_binary64_bits(value);
        write_global_fast<std::uint64_t>(address, bits);
        return native_double_from_binary64_bits(bits);
#endif
    }

    SSNATIVE_ALWAYS_INLINE void copy_global_u64(
        std::uint32_t destination, std::uint32_t source) {
        write_global_fast<std::uint64_t>(
            destination, read_global_fast<std::uint64_t>(source));
    }

#if defined(SSNATIVE_DOUBLE_PAIR_KERNELS)
    [[nodiscard]] SSNATIVE_ALWAYS_INLINE NativeDoublePair global_f64_pair(
        std::uint32_t first, std::uint32_t second) const {
#if defined(SSNATIVE_SOFT_X87) && defined(SSNATIVE_M11_PAIR_FROM64)
        NativeDoublePair value;
        NativeDouble::from_binary64_pair_bits(
            read_global_fast<std::uint64_t>(first),
            read_global_fast<std::uint64_t>(second),
            value.first, value.second);
        return value;
#elif defined(SSNATIVE_EXPLICIT_SSE2_PAIR)
        if (__builtin_expect(second == first + 8u, 1)) {
            return NativeDoublePair(_mm_loadu_pd(
                reinterpret_cast<const double*>(global_bytes_ + static_cast<std::size_t>(first - kGlobalBase))));
        }
        return {global_f64(first), global_f64(second)};
#else
        return {global_f64(first), global_f64(second)};
#endif
    }

    SSNATIVE_ALWAYS_INLINE void global_store_f64_pair(
        std::uint32_t first, std::uint32_t second,
        const NativeDoublePair& value) {
#if defined(SSNATIVE_SOFT_X87) && defined(SSNATIVE_M11_PAIR_TO64)
        std::uint64_t first_bits{};
        std::uint64_t second_bits{};
        NativeDouble::to_binary64_pair_bits(
            value.first, value.second, first_bits, second_bits);
        write_global_fast<std::uint64_t>(first, first_bits);
        write_global_fast<std::uint64_t>(second, second_bits);
#elif defined(SSNATIVE_EXPLICIT_SSE2_PAIR)
        if (__builtin_expect(second == first + 8u, 1)) {
            _mm_storeu_pd(reinterpret_cast<double*>(global_bytes_ + static_cast<std::size_t>(first - kGlobalBase)), value.lanes);
            return;
        }
        global_store_f64(first, native_double_pair_first(value));
        global_store_f64(second, native_double_pair_second(value));
#else
        global_store_f64(first, native_double_pair_first(value));
        global_store_f64(second, native_double_pair_second(value));
#endif
    }
#endif

    SSNATIVE_ALWAYS_INLINE void fast_biquad_channel(
        std::uint32_t coefficients, std::uint32_t state,
        std::uint32_t input_output, std::uint32_t state_offset) {
        const auto w1_address = state + state_offset;
        const auto w2_address = w1_address + 8u;
        const NativeDouble w1 = guest_f64(w1_address);
        const NativeDouble w2 = guest_f64(w2_address);

        NativeDouble w0 = w1 * constant_f64(coefficients + 24u);
        w0 = guest_f64(input_output) - w0;
        NativeDouble term = constant_f64(coefficients + 32u) * w2;
        w0 = w0 - term;

        NativeDouble output = constant_f64(coefficients + 8u) * w1;
        term = w0 * constant_f64(coefficients);
        output = output + term;
        term = constant_f64(coefficients + 16u) * w2;
        output = output + term;

        guest_store_f64(input_output, output);
        copy_guest_u64(w2_address, w1_address);
        guest_store_f64(w1_address, w0);
    }



#if defined(SSNATIVE_FAST_POW_TABLE)
    [[nodiscard]] SSNATIVE_ALWAYS_INLINE double fast_pow_table(
        const double base, const double exponent) const noexcept {
        constexpr std::uint64_t kSignMask = 0x8000000000000000ull;
        constexpr std::uint64_t kExponentMask = 0x7ff0000000000000ull;
        constexpr std::uint64_t kMantissaMask = 0x000fffffffffffffull;
        constexpr double kInvLn2 = 1.44269504088896340735992468100189214;
        constexpr double kLn2 = 0.693147180559945309417232121458176568;

        const std::uint64_t bits = std::bit_cast<std::uint64_t>(base);
        const std::uint64_t exponent_field = (bits & kExponentMask) >> 52u;
        if (__builtin_expect((bits & kSignMask) != 0u || exponent_field == 0u ||
                             exponent_field == 0x7ffu || !std::isfinite(exponent), 0)) {
            return std::pow(base, exponent);
        }

        const int binary_exponent = static_cast<int>(exponent_field) - 1023;
        const std::uint64_t mantissa_bits =
            (bits & kMantissaMask) | (std::uint64_t{1023} << 52u);
        const double mantissa = std::bit_cast<double>(mantissa_bits);
        const std::size_t log_index = static_cast<std::size_t>(
            (mantissa_bits & kMantissaMask) >> 44u);
        const double z = mantissa * hot_caches_->pow_inv_center[log_index] - 1.0;
        const double log1p = z * (1.0 + z * (-0.5 + z *
            (0.333333333333333333333333333333333333 + z *
             (-0.25 + z * 0.2))));
        const double log2_base = static_cast<double>(binary_exponent) +
            hot_caches_->pow_log2_center[log_index] + log1p * kInvLn2;
        const double value = exponent * log2_base;
        if (__builtin_expect(value <= -1022.0 || value >= 1023.0 ||
                             !std::isfinite(value), 0)) {
            return std::pow(base, exponent);
        }

        int integral = static_cast<int>(value);
        if (value < static_cast<double>(integral)) --integral;
        const double fraction = value - static_cast<double>(integral);
        double scaled = fraction *
            static_cast<double>(HotControlCaches::kPowTableSize);
        std::size_t exp_index = static_cast<std::size_t>(scaled);
        if (exp_index >= HotControlCaches::kPowTableSize) {
            exp_index = HotControlCaches::kPowTableSize - 1u;
        }
        const double residual = fraction -
            static_cast<double>(exp_index) /
            static_cast<double>(HotControlCaches::kPowTableSize);
        const double a = residual * kLn2;
        const double a2 = a * a;
        const double polynomial = 1.0 + a + a2 *
            (0.5 + a * (0.166666666666666666666666666666666667 +
                        a * (0.041666666666666666666666666666666667 +
                             a * 0.008333333333333333333333333333333333)));
        const double unit = hot_caches_->pow_exp2_fraction[exp_index] * polynomial;
        std::uint64_t unit_bits = std::bit_cast<std::uint64_t>(unit);
        const int output_exponent = static_cast<int>((unit_bits >> 52u) & 0x7ffu) + integral;
        if (__builtin_expect(output_exponent <= 0 || output_exponent >= 0x7ff, 0)) {
            return std::ldexp(unit, integral);
        }
        unit_bits = (unit_bits & ~kExponentMask) |
            (static_cast<std::uint64_t>(output_exponent) << 52u);
        return std::bit_cast<double>(unit_bits);
    }
#endif

    [[nodiscard]] SSNATIVE_ALWAYS_INLINE NativeDouble reconstructed_pow(
        NativeDouble base, NativeDouble exponent, [[maybe_unused]] const std::uint32_t cache_bank) {
        const double base64 = static_cast<double>(base);
        const double exponent64 = static_cast<double>(exponent);
#if defined(SSNATIVE_M9_POW_CACHE_SIZE)
#if !defined(NDEBUG)
        if (hot_caches_ == nullptr) {
            __builtin_trap();
        }
#endif
        const std::uint64_t base_bits = std::bit_cast<std::uint64_t>(base64);
#if SSNATIVE_POW_CACHE_QUANTIZE_BITS > 0
        constexpr std::uint64_t quantize_mask =
            (std::uint64_t{1} << SSNATIVE_POW_CACHE_QUANTIZE_BITS) - 1u;
        const std::uint64_t key_base_bits = base_bits & ~quantize_mask;
        const double pow_base64 = std::bit_cast<double>(key_base_bits);
#else
        const std::uint64_t key_base_bits = base_bits;
        const double pow_base64 = base64;
#endif
        [[maybe_unused]] const std::uint64_t exponent_bits =
            std::bit_cast<std::uint64_t>(exponent64);
#if SSNATIVE_POW_CACHE_BANK_ENTRIES > 0
        static_assert((SSNATIVE_POW_CACHE_BANK_ENTRIES &
                       (SSNATIVE_POW_CACHE_BANK_ENTRIES - 1)) == 0);
        const std::uint64_t mixed = key_base_bits ^ (key_base_bits >> 32u);
        constexpr std::size_t mask = SSNATIVE_POW_CACHE_BANK_ENTRIES - 1u;
        auto& entry = hot_caches_->pow_banks[cache_bank][
            static_cast<std::size_t>(mixed) & mask];
        const std::uint64_t full_key = key_base_bits;
        if (__builtin_expect(entry.key == full_key, 1)) {
            return native_double_from_binary64_bits(entry.result_bits);
        }
#else
        const std::uint64_t mixed = key_base_bits ^ (key_base_bits >> 32u) ^
            (exponent_bits * 0x9e3779b97f4a7c15ull);
        constexpr std::size_t mask = SSNATIVE_M9_POW_CACHE_SIZE - 1u;
        auto& entry = hot_caches_->pow[static_cast<std::size_t>(mixed) & mask];
#if defined(SSNATIVE_COMPACT_POW_CACHE)
        const std::uint64_t full_key = mixed ^
            ((key_base_bits << 17u) | (key_base_bits >> 47u));
        if (__builtin_expect(entry.key == full_key, 1)) {
            return native_double_from_binary64_bits(entry.result_bits);
        }
#else
        if (__builtin_expect(entry.base_bits == key_base_bits &&
                             entry.exponent_bits == exponent_bits, 1)) {
            return native_double_from_binary64_bits(entry.result_bits);
        }
#endif
#endif
#if defined(SSNATIVE_FAST_POW_TABLE)
        const double result = fast_pow_table(pow_base64, exponent64);
#else
        const double result = std::pow(pow_base64, exponent64);
#endif
        const std::uint64_t result_bits =
            std::bit_cast<std::uint64_t>(result);
#if SSNATIVE_POW_CACHE_BANK_ENTRIES > 0
        entry = {full_key, result_bits};
#elif defined(SSNATIVE_COMPACT_POW_CACHE)
        entry = {full_key, result_bits};
#else
        entry = {key_base_bits, exponent_bits, result_bits};
#endif
        return native_double_from_binary64_bits(result_bits);
#else
        return static_cast<NativeDouble>(std::pow(base64, exponent64));
#endif
    }

#if defined(SSNATIVE_COMPACT_DYNAMICS)
#  define SSNATIVE_DYNAMICS_BAND_ATTR __attribute__((hot, noinline, noclone))
#else
#  define SSNATIVE_DYNAMICS_BAND_ATTR SSNATIVE_ALWAYS_INLINE
#endif

#if defined(SSNATIVE_M12_UNIFIED_DYNAMICS)
    SSNATIVE_DYNAMICS_BAND_ATTR void fast_dynamics_band_unified(
        std::uint32_t band, bool low_band) {
        constexpr std::uint32_t kZero = 0u;
#else
    template<bool LowBand>
    SSNATIVE_DYNAMICS_BAND_ATTR void fast_dynamics_band(
        std::uint32_t band) {
        constexpr std::uint32_t kZero = 0u;
        constexpr bool low_band = LowBand;
#endif
        const auto parameter_enable = state_address::dynamics_enable + band * 4u;
        const auto level_address = state_address::dynamics_level + band * 8u;
        const auto runtime = state_address::dynamics_runtime + band * 0xd8u;
        const auto detector_state = state_address::dynamics_detector + band * 8u;
        const auto power_state = state_address::dynamics_power + band * 8u;
        const auto output_gain = state_address::dynamics_gain + band * 8u;
        const NativeDouble one = constant_f64(state_address::unity);
        const NativeDouble level = global_f64(level_address);

        // First dynamics path: runtime[-0x38].
        if (low_band && global_u32(state_address::dynamics_low_path_enabled) != kZero) {
            const NativeDouble previous = global_f64(runtime - 0x08u);
            NativeDouble coefficient;
            if (level > previous) {
                coefficient = global_f64(runtime - 0x30u);
                global_store_u32(runtime, 500u);
            } else {
                auto counter = global_u32(runtime);
                if (counter != 0u) {
                    coefficient = one;
                    global_store_u32(runtime, counter - 1u);
                } else {
                    coefficient = global_f64(runtime - 0x28u);
                }
            }

            NativeDouble smoothed = one - coefficient;
            smoothed = smoothed * level;
            NativeDouble term = coefficient * previous;
            smoothed = smoothed + term;
            const NativeDouble smoothed_rounded =
                global_round_store_f64(runtime - 0x08u, smoothed);

            const auto threshold_i = static_cast<std::int32_t>(global_u32(runtime - 0x10u));
            const NativeDouble threshold_ext = static_cast<NativeDouble>(threshold_i);
            if (smoothed < threshold_ext) {
                NativeDouble base = smoothed_rounded / threshold_ext;
                const NativeDouble result = reconstructed_pow(base, global_f64(runtime + 0x08u), band);
                global_store_f64(runtime - 0x38u, result);
            } else {
                global_store_f64(runtime - 0x38u, one);
            }
        } else {
            global_store_f64(runtime - 0x38u, one);
        }

        if (global_u32(state_address::dynamics_global_path_bypass) == kZero && low_band) {
            global_store_f64(runtime - 0x80u, one);
        } else {
            const auto global_threshold_i = static_cast<std::int32_t>(global_u32(state_address::global_threshold));
            const NativeDouble global_threshold = static_cast<NativeDouble>(global_threshold_i);

            NativeDouble coefficient = level < global_threshold
                ? constant_f64(0x1000c750u)
                : global_f64(runtime - 0x60u);
            const NativeDouble old_detector = global_f64(detector_state);
            if (level > old_detector) coefficient = global_f64(runtime - 0x68u);

            NativeDouble detector = one - coefficient;
            detector = detector * level;
            NativeDouble term = old_detector * coefficient;
            detector = detector + term;
            NativeDouble detector_rounded =
                global_round_store_f64(detector_state, detector);

            const auto minimum_i = static_cast<std::int32_t>(global_u32(runtime - 0x58u));
            const NativeDouble minimum_ext = static_cast<NativeDouble>(minimum_i);
            if (minimum_ext > detector_rounded) {
                detector_rounded =
                    global_round_store_f64(detector_state, minimum_ext);
            }

            NativeDouble ratio = detector_rounded / minimum_ext;
            const NativeDouble power_gain = reconstructed_pow(ratio, global_f64(runtime - 0x40u), 5u + band);
            global_store_f64(power_state, power_gain);

            const NativeDouble state50_old = global_f64(runtime - 0x50u);
            NativeDouble release_coefficient;
            auto release_counter = global_u32(runtime - 0x48u);
            if (level > state50_old) {
                if (release_counter < 2u) {
                    release_coefficient = global_f64(runtime - 0x78u);
                    global_store_u32(runtime - 0x48u, global_u32(runtime - 0x44u));
                } else {
                    release_coefficient = one - global_f64(runtime - 0x78u);
                    release_coefficient = release_coefficient * constant_f64(0x1000c740u);
                    const std::uint64_t product =
                        static_cast<std::uint64_t>(0xcccccccdu) *
                        static_cast<std::uint64_t>(global_u32(runtime - 0x44u));
                    global_store_u32(runtime - 0x48u,
                              static_cast<std::uint32_t>(product >> 34u));
                    release_coefficient = one - release_coefficient;
                }
            } else if (release_counter != 0u) {
                release_coefficient = one;
                global_store_u32(runtime - 0x48u, release_counter - 1u);
            } else {
                if (global_u32(state_address::dynamics_release_program) != kZero) {
                    release_coefficient = level < global_threshold
                        ? constant_f64(0x1000c750u)
                        : global_f64(runtime - 0x70u);
                } else if (global_u32(state_address::dynamics_release_mode) != kZero) {
                    release_coefficient = constant_f64(0x1000c750u);
                } else {
                    release_coefficient = global_f64(runtime - 0x70u);
                }
            }

            NativeDouble state50 = one - release_coefficient;
            state50 = state50 * level;
            term = release_coefficient * state50_old;
            state50 = state50 + term;
            NativeDouble state50_rounded =
                global_round_store_f64(runtime - 0x50u, state50);
            if (state50 < minimum_ext) {
                state50_rounded =
                    global_round_store_f64(runtime - 0x50u, minimum_ext);
            }

            ratio = state50_rounded / minimum_ext;
            const NativeDouble release_gain = reconstructed_pow(ratio, global_f64(runtime - 0x40u), 5u + band);
            global_store_f64(runtime - 0x80u,
                            power_gain < release_gain ? power_gain : release_gain);
        }

        NativeDouble combined = global_f64(runtime - 0x38u) *
                               global_f64(runtime - 0x80u);
        const NativeDouble combined_rounded =
            global_round_store_f64(output_gain, combined);

        const NativeDouble weighted_level = level * combined_rounded;
        const NativeDouble state40_old = global_f64(runtime + 0x40u);
        NativeDouble final_coefficient;
        if (weighted_level > state40_old) {
            final_coefficient = global_f64(runtime + 0x18u);
            global_store_u32(runtime + 0x48u, 500u);
        } else {
            auto counter = global_u32(runtime + 0x48u);
            if (counter != 0u) {
                final_coefficient = one;
                global_store_u32(runtime + 0x48u, counter - 1u);
            } else {
                final_coefficient = global_f64(runtime + 0x20u);
            }
        }

        NativeDouble state40 = one - final_coefficient;
        state40 = weighted_level * state40;
        NativeDouble term = final_coefficient * state40_old;
        state40 = state40 + term;
        const NativeDouble state40_rounded =
            global_round_store_f64(runtime + 0x40u, state40);

        const auto final_threshold_i = static_cast<std::int32_t>(global_u32(runtime + 0x38u));
        const NativeDouble final_threshold = static_cast<NativeDouble>(final_threshold_i);
        NativeDouble final_factor_rounded;
        if (final_threshold < state40 && low_band && global_u32(state_address::dynamics_final_limiter) != kZero) {
            const NativeDouble factor = final_threshold / state40_rounded;
            final_factor_rounded =
                global_round_store_f64(runtime + 0x10u, factor);
        } else {
            final_factor_rounded =
                global_round_store_f64(runtime + 0x10u, one);
        }

        combined = combined_rounded * final_factor_rounded;
        global_store_f64(output_gain, combined);
        if (global_u32(parameter_enable) == kZero) {
            global_store_u32(output_gain, 0xa0b5ed8du);
            global_store_u32(output_gain + 4u, 0x3eb0c6f7u);
        }
    }

#if defined(SSNATIVE_M12_UNIFIED_DYNAMICS)
    template<bool LowBand>
    SSNATIVE_ALWAYS_INLINE void fast_dynamics_band(std::uint32_t band) {
        fast_dynamics_band_unified(band, LowBand);
    }
#endif

#if defined(SSNATIVE_INLINE_DYNAMICS_RANGE)
    SSNATIVE_ALWAYS_INLINE void fast_dynamics_range(
#else
    __attribute__((noinline)) void fast_dynamics_range(
#endif
        std::uint32_t first, std::uint32_t last) {
        if (first == 0u && last == 4u) {
            fast_dynamics_band<true>(0u);
            fast_dynamics_band<true>(1u);
            fast_dynamics_band<true>(2u);
            fast_dynamics_band<true>(3u);
            fast_dynamics_band<true>(4u);
            return;
        }
        if (first == 5u && last == 6u) {
            fast_dynamics_band<false>(5u);
            fast_dynamics_band<false>(6u);
            return;
        }
        if (first > last) return;
        for (std::uint32_t band = first; band <= last; ++band) {
            if (band < 5u) fast_dynamics_band<true>(band);
            else fast_dynamics_band<false>(band);
        }
    }

    __attribute__((noinline)) void fast_10007b90() {
        fast_dynamics_range(read_u32(call_state().flow.frame_cursor + 4u),
                            read_u32(call_state().flow.frame_cursor + 8u));
    }

#undef SSNATIVE_DYNAMICS_BAND_ATTR

#if defined(SSNATIVE_INLINE_M13_BLOCKS)
#  define SSNATIVE_M13_BLOCK_ATTR SSNATIVE_ALWAYS_INLINE
#else
#  define SSNATIVE_M13_BLOCK_ATTR __attribute__((hot, noinline, noclone))
#endif

#if defined(SSNATIVE_M13_NATIVE_STATE_OUTPUT)
    // Exact native translation of the per-sample legacy block
    // 0x10002BBF..0x10002CA8.  The original block consumes two
    // pre-existing x87 stack values, performs two independent state updates,
    // preserves four explicit QWORD rounding stores, copies the state words
    // by raw bit pattern, and leaves the integer flags from the equivalent integer comparison.
    SSNATIVE_M13_BLOCK_ATTR void fast_m13_state_output(NativeDouble first_accumulator, NativeDouble second_accumulator) {

        const std::uint32_t stack_first_low = read_u32(call_state().flow.frame_cursor + 0x6cu);
        const std::uint32_t stack_first_high = read_u32(call_state().flow.frame_cursor + 0x70u);
        global_store_u32(state_address::state_mix_b, stack_first_low);
        global_store_u32(state_address::state_mix_c, stack_first_high);
        const std::uint32_t first_old_low = global_u32(state_address::output_state_left);
        const std::uint32_t first_old_high = global_u32(0x100d6114u);
        const std::uint32_t stack_second_low = read_u32(call_state().flow.frame_cursor + 0x68u);
        const std::uint32_t stack_second_high = read_u32(call_state().flow.frame_cursor + 0x74u);
        global_store_u32(state_address::state_mix_a, stack_second_low);
        global_store_u32(state_address::state_mix_d, stack_second_high);

        NativeDouble term = global_f64(state_address::output_state_left) * global_f64(state_address::output_history_left_a);
        first_accumulator = first_accumulator - term;
        term = global_f64(state_address::output_state_left_aux) * global_f64(state_address::output_history_left_b);
        first_accumulator = first_accumulator - term;
        global_store_f64(0x100d6108u, first_accumulator);

        NativeDouble first_mix = global_f64(state_address::output_history_right_b) * global_f64(state_address::output_state_left_aux);
        term = global_f64(state_address::output_history_right_a) * global_f64(state_address::output_state_left);
        first_mix = first_mix + term;
        first_mix = first_mix + first_accumulator;
        global_store_f64(state_address::output_left, first_mix);
        global_store_f64(state_address::output_state_left, first_accumulator);
        global_store_u32(state_address::output_state_left_aux, first_old_low);
        global_store_u32(0x100d611cu, first_old_high);

        const std::uint32_t second_old_low = global_u32(state_address::output_state_right);
        const std::uint32_t second_old_high = global_u32(0x100d612cu);
        term = global_f64(state_address::output_state_right) * global_f64(state_address::output_history_left_a);
        second_accumulator = second_accumulator - term;
        term = global_f64(state_address::output_state_right_aux) * global_f64(state_address::output_history_left_b);
        second_accumulator = second_accumulator - term;
        global_store_f64(0x100d6120u, second_accumulator);

        NativeDouble second_mix = global_f64(state_address::output_history_right_b) * global_f64(state_address::output_state_right_aux);
        term = global_f64(state_address::output_history_right_a) * global_f64(state_address::output_state_right);
        second_mix = second_mix + term;

        call_state().flow.value_a = global_u32(0x10106090u);
        call_state().flow.value_c = second_old_high;
        call_state().flow.value_d = first_old_high;
        update_sub_condition(call_state().flow.value_a, call_state().flow.value_b, call_state().flow.value_a - call_state().flow.value_b, 32u);

        global_store_u32(state_address::output_state_right_aux, second_old_low);
        global_store_u32(0x100d6134u, second_old_high);
        second_mix = second_mix + second_accumulator;
        global_store_f64(state_address::output_right, second_mix);
        global_store_f64(state_address::output_state_right, second_accumulator);
    }
#endif

#if defined(SSNATIVE_M13_OUTLINE_FILTER_BANK_STAGE)
#  define SSNATIVE_FILTER_BANK_STAGE_ATTR __attribute__((hot, noinline, noclone))
#else
#  define SSNATIVE_FILTER_BANK_STAGE_ATTR SSNATIVE_ALWAYS_INLINE
#endif

    SSNATIVE_FILTER_BANK_STAGE_ATTR void fast_filter_bank_channel(
        std::uint32_t coefficients, std::uint32_t state_center,
        std::uint32_t input_address, std::uint32_t output_address,
        bool alternate_order) {
        const auto s1a = state_center - 0x190u;
        const auto s2a = state_center - 0x0c8u;
        const auto s3a = state_center;
        const auto s4a = state_center + 0x0c8u;
        const NativeDouble s1 = global_f64(s1a);
        const NativeDouble s2 = global_f64(s2a);
        const NativeDouble s3 = global_f64(s3a);
        const NativeDouble s4 = global_f64(s4a);

        NativeDouble w0;
        NativeDouble term;
        if (!alternate_order) {
            w0 = s1 * constant_f64(coefficients - 8u);
            w0 = global_f64(input_address) - w0;
            term = constant_f64(coefficients) * s2;
            w0 = w0 - term;
            term = s3 * constant_f64(coefficients + 8u);
            w0 = w0 - term;
            term = constant_f64(coefficients + 16u) * s4;
            w0 = w0 - term;
        } else {
            w0 = constant_f64(coefficients - 8u) * s1;
            w0 = global_f64(input_address) - w0;
            term = s2 * constant_f64(coefficients);
            w0 = w0 - term;
            term = constant_f64(coefficients + 8u) * s3;
            w0 = w0 - term;
            term = s4 * constant_f64(coefficients + 16u);
            w0 = w0 - term;
        }

        global_store_f64(state_center - 0x258u, w0);

        NativeDouble output;
        if (!alternate_order) {
            output = constant_f64(coefficients - 16u) * s4;
            term = w0 * constant_f64(coefficients - 48u);
            output = output + term;
            term = constant_f64(coefficients - 32u) * s2;
            output = output + term;
            term = s3 * constant_f64(coefficients - 24u);
            output = output + term;
            term = s1 * constant_f64(coefficients - 40u);
            output = output + term;
        } else {
            output = w0 * constant_f64(coefficients - 48u);
            term = constant_f64(coefficients - 16u) * s4;
            output = output + term;
            term = s3 * constant_f64(coefficients - 24u);
            output = output + term;
            term = s1 * constant_f64(coefficients - 40u);
            output = output + term;
            term = constant_f64(coefficients - 32u) * s2;
            output = output + term;
        }

        copy_global_u64(s4a, s3a);
        copy_global_u64(s3a, s2a);
        copy_global_u64(s2a, s1a);
        copy_global_u64(s1a, state_center - 0x258u);
        global_store_f64(output_address, output);
    }


#if defined(SSNATIVE_DOUBLE_PAIR_KERNELS)
    SSNATIVE_FILTER_BANK_STAGE_ATTR void fast_filter_bank_stereo_pair(
        std::uint32_t coefficients, std::uint32_t state_center,
        std::uint32_t first_input, std::uint32_t second_input,
        std::uint32_t first_output, std::uint32_t second_output,
        bool alternate_order) {
        const auto s1_left = state_center - 0x190u;
        const auto s2_left = state_center - 0x0c8u;
        const auto s3_left = state_center;
        const auto s4_left = state_center + 0x0c8u;
        const auto s1_right = s1_left + 8u;
        const auto s2_right = s2_left + 8u;
        const auto s3_right = s3_left + 8u;
        const auto s4_right = s4_left + 8u;

        const NativeDoublePair s1 = global_f64_pair(s1_left, s1_right);
        const NativeDoublePair s2 = global_f64_pair(s2_left, s2_right);
        const NativeDoublePair s3 = global_f64_pair(s3_left, s3_right);
        const NativeDoublePair s4 = global_f64_pair(s4_left, s4_right);
        const NativeDoublePair input = global_f64_pair(first_input, second_input);

        NativeDoublePair w0;
        if (!alternate_order) {
            w0 = native_double_pair_mul_acc_right<true>(
                input, s1, constant_f64(coefficients - 8u));
            w0 = native_double_pair_mul_acc_left<true>(
                w0, constant_f64(coefficients), s2);
            w0 = native_double_pair_mul_acc_right<true>(
                w0, s3, constant_f64(coefficients + 8u));
            w0 = native_double_pair_mul_acc_left<true>(
                w0, constant_f64(coefficients + 16u), s4);
        } else {
            w0 = native_double_pair_mul_acc_left<true>(
                input, constant_f64(coefficients - 8u), s1);
            w0 = native_double_pair_mul_acc_right<true>(
                w0, s2, constant_f64(coefficients));
            w0 = native_double_pair_mul_acc_left<true>(
                w0, constant_f64(coefficients + 8u), s3);
            w0 = native_double_pair_mul_acc_right<true>(
                w0, s4, constant_f64(coefficients + 16u));
        }

        global_store_f64_pair(state_center - 0x258u,
                             state_center - 0x250u, w0);

        NativeDoublePair output;
        if (!alternate_order) {
            output = native_double_pair_mul_left(constant_f64(coefficients - 16u), s4);
            output = native_double_pair_mul_acc_right<false>(
                output, w0, constant_f64(coefficients - 48u));
            output = native_double_pair_mul_acc_left<false>(
                output, constant_f64(coefficients - 32u), s2);
            output = native_double_pair_mul_acc_right<false>(
                output, s3, constant_f64(coefficients - 24u));
            output = native_double_pair_mul_acc_right<false>(
                output, s1, constant_f64(coefficients - 40u));
        } else {
            output = native_double_pair_mul_right(w0, constant_f64(coefficients - 48u));
            output = native_double_pair_mul_acc_left<false>(
                output, constant_f64(coefficients - 16u), s4);
            output = native_double_pair_mul_acc_right<false>(
                output, s3, constant_f64(coefficients - 24u));
            output = native_double_pair_mul_acc_right<false>(
                output, s1, constant_f64(coefficients - 40u));
            output = native_double_pair_mul_acc_left<false>(
                output, constant_f64(coefficients - 32u), s2);
        }

        copy_global_u64(s4_left, s3_left);
        copy_global_u64(s4_right, s3_right);
        copy_global_u64(s3_left, s2_left);
        copy_global_u64(s3_right, s2_right);
        copy_global_u64(s2_left, s1_left);
        copy_global_u64(s2_right, s1_right);
        copy_global_u64(s1_left, state_center - 0x258u);
        copy_global_u64(s1_right, state_center - 0x250u);
        global_store_f64_pair(first_output, second_output, output);
    }
#endif

    __attribute__((noinline)) void fast_10007fe0() {
        const bool alternate_order = (read_u8(state_address::mode_flags) & 0x04u) == 0u;
        std::uint32_t coefficients = alternate_order ? state_address::filter_bank_coefficients_alternate : state_address::filter_bank_coefficients_normal;
        std::uint32_t state_center = state_address::filter_bank_state;
        std::uint32_t output_index = 0u;
        for (unsigned stage = 0; stage < 5u; ++stage) {
#if defined(SSNATIVE_DOUBLE_PAIR_KERNELS)
            fast_filter_bank_stereo_pair(
                coefficients, state_center,
                state_address::input_right, state_address::input_left,
                state_address::band_outputs + output_index * 8u,
                state_address::band_outputs + (output_index + 1u) * 8u,
                alternate_order);
#else
            fast_filter_bank_channel(coefficients, state_center,
                                     state_address::input_right,
                                     state_address::band_outputs + output_index * 8u,
                                     alternate_order);
            fast_filter_bank_channel(coefficients, state_center + 8u,
                                     state_address::input_left,
                                     state_address::band_outputs + (output_index + 1u) * 8u,
                                     alternate_order);
#endif
            coefficients += 0x48u;
            state_center += 0x28u;
            output_index += 2u;
        }
    }


#if defined(SSNATIVE_DOUBLE_PAIR_KERNELS)
#undef SSNATIVE_FILTER_BANK_STAGE_ATTR

#if defined(SSNATIVE_M13_OUTLINE_BIQUAD_STAGE)
#  define SSNATIVE_BIQUAD_STAGE_ATTR __attribute__((hot, noinline, noclone))
#else
#  define SSNATIVE_BIQUAD_STAGE_ATTR SSNATIVE_ALWAYS_INLINE
#endif

    SSNATIVE_BIQUAD_STAGE_ATTR void fast_biquad_stereo_pair(
        std::uint32_t coefficients, std::uint32_t state,
        std::uint32_t first_sample, std::uint32_t second_sample) {
        const auto left_w1 = state + 8u;
        const auto right_w1 = state + 24u;
        const NativeDoublePair w1 = guest_f64_pair(left_w1, right_w1);
        const NativeDoublePair w2 = guest_f64_pair(left_w1 + 8u, right_w1 + 8u);
        const NativeDoublePair input = guest_f64_pair(first_sample, second_sample);

        NativeDoublePair w0 = native_double_pair_mul_acc_right<true>(
            input, w1, constant_f64(coefficients + 24u));
        w0 = native_double_pair_mul_acc_left<true>(
            w0, constant_f64(coefficients + 32u), w2);

        NativeDoublePair output = native_double_pair_mul_left(constant_f64(coefficients + 8u), w1);
        output = native_double_pair_mul_acc_right<false>(
            output, w0, constant_f64(coefficients));
        output = native_double_pair_mul_acc_left<false>(
            output, constant_f64(coefficients + 16u), w2);

        guest_store_f64_pair(first_sample, second_sample, output);
        copy_guest_u64(left_w1 + 8u, left_w1);
        copy_guest_u64(right_w1 + 8u, right_w1);
        guest_store_f64_pair(left_w1, right_w1, w0);
    }
#endif

    SSNATIVE_ALWAYS_INLINE void fast_biquad_stereo(
        std::uint32_t coefficients, std::uint32_t state,
        std::uint32_t first_sample, std::uint32_t second_sample) {
#if defined(SSNATIVE_DOUBLE_PAIR_KERNELS)
        fast_biquad_stereo_pair(coefficients, state,
                                first_sample, second_sample);
#else
        fast_biquad_channel(coefficients, state, first_sample, 8u);
        fast_biquad_channel(coefficients, state, second_sample, 24u);
#endif
    }

    __attribute__((noinline)) void fast_10008ac0() {
        fast_biquad_stereo(read_u32(call_state().flow.frame_cursor + 4u),
                           read_u32(call_state().flow.frame_cursor + 8u),
                           read_u32(call_state().flow.frame_cursor + 12u),
                           read_u32(call_state().flow.frame_cursor + 16u));
    }


#if defined(SSNATIVE_M13_NATIVE_BAND_POST)
    // Exact native translation of the hot per-sample chain
    // 0x10003057..0x100031E5.  It preserves the original binary80
    // arithmetic order, all four binary64 scratch rounding points, both
    // independent biquad states and the high-band dynamics call.
    SSNATIVE_M13_BLOCK_ATTR void fast_m13_band_post() {
        NativeDouble first = global_f64(state_address::delayed_bands);
        first = first - global_f64(0x100d6810u);
        first = first + global_f64(0x100d6820u);
        first = first - global_f64(0x100d6830u);
        first = first + global_f64(0x100d6840u);

        NativeDouble second = global_f64(0x100d6808u);
        second = second - global_f64(0x100d6818u);
        second = second + global_f64(0x100d6828u);
        second = second - global_f64(0x100d6838u);
        second = second + global_f64(0x100d6848u);

        // The legacy code stores the second result through the 0x80-byte frame slot and
        // copies its raw binary64 words to 0x100d6168, while the first result
        // is stored directly to 0x100d6170.  Reproduce the same rounded bits.
        guest_store_f64(call_state().flow.frame_cursor + 0x80u, second);
        copy_guest_u64(state_address::output_right, call_state().flow.frame_cursor + 0x80u);
        global_store_f64(state_address::output_left, first);

        // Two parallel biquads receive identical input samples but retain
        // independent state.  Keep their four original stack scratch slots.
        copy_guest_u64(call_state().flow.frame_cursor + 0x38u, state_address::output_left);
        copy_guest_u64(call_state().flow.frame_cursor + 0x28u, state_address::output_right);
        copy_guest_u64(call_state().flow.frame_cursor + 0x30u, state_address::output_left);
        copy_guest_u64(call_state().flow.frame_cursor + 0x20u, state_address::output_right);

        fast_biquad_stereo(state_address::high_biquad_coefficients_a, state_address::high_biquad_state_a,
                           call_state().flow.frame_cursor + 0x38u, call_state().flow.frame_cursor + 0x28u);
        fast_biquad_stereo(state_address::high_biquad_coefficients_b, state_address::high_biquad_state_b,
                           call_state().flow.frame_cursor + 0x30u, call_state().flow.frame_cursor + 0x20u);

        const NativeDouble scale = global_f64(state_address::post_scale);
        guest_store_f64(call_state().flow.frame_cursor + 0x38u,
                        guest_f64(call_state().flow.frame_cursor + 0x38u) * scale);
        guest_store_f64(call_state().flow.frame_cursor + 0x28u,
                        guest_f64(call_state().flow.frame_cursor + 0x28u) * scale);
        guest_store_f64(call_state().flow.frame_cursor + 0x30u,
                        guest_f64(call_state().flow.frame_cursor + 0x30u) * scale);
        guest_store_f64(call_state().flow.frame_cursor + 0x20u,
                        guest_f64(call_state().flow.frame_cursor + 0x20u) * scale);

        const NativeDouble first_left = native_double_abs(guest_f64(call_state().flow.frame_cursor + 0x38u));
        const NativeDouble first_right = native_double_abs(guest_f64(call_state().flow.frame_cursor + 0x28u));
        global_store_f64(state_address::first_peak,
                         first_left > first_right ? first_left : first_right);

        const NativeDouble second_left = native_double_abs(guest_f64(call_state().flow.frame_cursor + 0x30u));
        const NativeDouble second_right = native_double_abs(guest_f64(call_state().flow.frame_cursor + 0x20u));
        global_store_f64(state_address::second_peak,
                         second_left > second_right ? second_left : second_right);

        // The following VM code observes the integer-register values left by
        // the two emulated call setups.  Recreate them exactly before the
        // native dynamics body; FPU status is the result of the second max
        // comparison and FNSTSW writes it into AX without changing EAX[31:16].
        update_float_condition(second_left, second_right);
        call_state().flow.value_b = 0u;
        call_state().flow.pointer = read_u32(call_state().flow.frame_cursor + 0x10u);
        call_state().flow.value_c = call_state().flow.frame_cursor + 0x38u;
        call_state().flow.value_d = call_state().flow.frame_cursor + 0x20u;
        call_state().flow.value_a = ((call_state().flow.frame_cursor + 0x30u) & 0xffff0000u) | call_state().floating.comparison_status;

        fast_dynamics_range(5u, 6u);
    }
#endif

#if defined(SSNATIVE_M13_NATIVE_PREFILTER_SETUP)
    // Exact replacement of 0x100028B4..0x10002934.  Four raw binary64 input
    // copies feed two independent stereo one-pole sections.  The helper then
    // recreates the 32-byte emulated argument stack expected by the following
    // translated detector arithmetic.
    SSNATIVE_M13_BLOCK_ATTR void fast_m13_prefilter_setup() {
        const std::uint32_t original_esp = call_state().flow.frame_cursor;
        copy_guest_u64(original_esp + 0x40u, state_address::output_right);
        copy_guest_u64(original_esp + 0x48u, state_address::output_left);
        copy_guest_u64(original_esp + 0x58u, state_address::output_right);
        copy_guest_u64(original_esp + 0x60u, state_address::output_left);

        fast_one_pole_stereo(state_address::prefilter_coefficients_a, state_address::prefilter_state_a,
                             original_esp + 0x40u,
                             original_esp + 0x48u);
        fast_one_pole_stereo(state_address::prefilter_coefficients_b, state_address::prefilter_state_b,
                             original_esp + 0x58u,
                             original_esp + 0x60u);

        call_state().flow.value_c = original_esp + 0x40u;
        call_state().flow.value_a = original_esp + 0x58u;
        call_state().flow.value_d = original_esp + 0x60u;
        call_state().flow.frame_cursor = original_esp - 0x20u;
    }
#endif

#if defined(SSNATIVE_M13_NATIVE_DELAY_OUTPUT)
    // Exact native translation of 0x100031E8..0x1000339B.  The legacy chain
    // smooths two delay gains, rotates four raw binary64 history slots,
    // computes the two interpolated outputs with the original binary80 order,
    // writes every scratch QWORD and updates the running output peak.
    SSNATIVE_M13_BLOCK_ATTR void fast_m13_delay_output() {
        NativeDouble smooth_first = global_f64(state_address::delay_gain_left);
        smooth_first = smooth_first * global_f64(state_address::blend_current);
        NativeDouble term = global_f64(state_address::delay_mix_left);
        term = term * global_f64(state_address::blend_previous);
        smooth_first = smooth_first + term;
        global_store_f64(state_address::delay_mix_left, smooth_first);

        NativeDouble smooth_second = global_f64(state_address::delay_gain_right);
        smooth_second = smooth_second * global_f64(state_address::blend_current);
        term = global_f64(state_address::delay_mix_right);
        term = term * global_f64(state_address::blend_previous);
        smooth_second = smooth_second + term;
        global_store_f64(state_address::delay_mix_right, smooth_second);

        const std::uint32_t delay_index = global_u32(state_address::delay_index);
        const std::uint32_t delay_offset =
            static_cast<std::uint32_t>((delay_index * 7u) << 4u);

        const std::uint32_t first_history = state_address::delay_tap_left_a + delay_offset;
        const std::uint32_t second_history = state_address::delay_tap_right_a + delay_offset;
        const std::uint32_t third_history = state_address::delay_tap_left_b + delay_offset;
        const std::uint32_t fourth_history = state_address::delay_tap_right_b + delay_offset;

        NativeDouble first_product = global_f64(first_history);
        first_product = first_product * global_f64(state_address::delay_mix_left);
        copy_guest_u64(first_history, call_state().flow.frame_cursor + 0x30u);

        NativeDouble second_product = global_f64(second_history);
        second_product = global_f64(state_address::delay_mix_right) * second_product;
        copy_guest_u64(second_history, call_state().flow.frame_cursor + 0x38u);
        const NativeDouble first_difference = first_product - second_product;

        NativeDouble third_product = global_f64(third_history);
        third_product = global_f64(state_address::delay_mix_left) * third_product;
        copy_guest_u64(third_history, call_state().flow.frame_cursor + 0x20u);
        global_store_f64(state_address::output_right, third_product);

        copy_guest_u64(call_state().flow.frame_cursor + 0x50u, fourth_history);
        copy_guest_u64(fourth_history, call_state().flow.frame_cursor + 0x28u);

        const NativeDouble interpolation = static_cast<NativeDouble>(
            static_cast<std::int32_t>(global_u32(state_address::output_scale)));
        guest_store_f64(call_state().flow.frame_cursor + 0x80u, interpolation);

        NativeDouble first_output = interpolation * first_difference;
        first_output = first_output * global_f64(state_address::sample_percent_scale);
        global_store_f64(state_address::output_left, first_output);

        NativeDouble fourth_product = global_f64(state_address::delay_mix_right);
        fourth_product = fourth_product * guest_f64(call_state().flow.frame_cursor + 0x50u);
        NativeDouble second_output = global_f64(state_address::output_right) - fourth_product;
        second_output = second_output * interpolation;
        second_output = second_output * global_f64(state_address::sample_percent_scale);
        global_store_f64(state_address::output_right, second_output);

        // Preserve all output scratch copies consumed by the following native
        // and translated stages.
        copy_guest_u64(call_state().flow.frame_cursor + 0x28u, state_address::output_right);
        copy_guest_u64(call_state().flow.frame_cursor + 0x20u, state_address::output_right);
        copy_guest_u64(call_state().flow.frame_cursor + 0x38u, state_address::output_left);
        copy_guest_u64(call_state().flow.frame_cursor + 0x30u, state_address::output_left);

        const NativeDouble first_abs = native_double_abs(global_f64(state_address::output_left));
        const NativeDouble second_abs = native_double_abs(global_f64(state_address::output_right));
        guest_store_f64(call_state().flow.frame_cursor + 0x18u, second_abs);
        const NativeDouble peak = second_abs > first_abs ? second_abs : first_abs;
        const NativeDouble previous_peak = global_f64(state_address::output_peak);
        if (peak > previous_peak) global_store_f64(state_address::output_peak, peak);

        // FNSTSW from the final peak comparison is observable in AX until the
        // next LEA.  ECX/EDX retain the high output words.
        update_float_condition(peak, previous_peak);
        const std::uint32_t left_low = global_u32(state_address::output_left);
        call_state().flow.value_a = (left_low & 0xffff0000u) | call_state().floating.comparison_status;
        call_state().flow.value_c = global_u32(0x100d6174u);
        call_state().flow.value_d = global_u32(0x100d616cu);
    }

#endif

#if defined(SSNATIVE_M13_NATIVE_POSTFILTER)
    // Exact native translation of 0x1000339B..0x10003517.  Four fourth-order
    // stereo sections, both optional soft-clip pairs, the channel summation
    // and the two peak/difference meters keep every observable binary64
    // rounding point, stack scratch word, x87 comparison and integer-register
    // side effect of the original per-sample VM chain.
    SSNATIVE_M13_BLOCK_ATTR void fast_m13_postfilter() {
        const std::uint32_t stack = call_state().flow.frame_cursor;

        fast_fourth_stereo(state_address::postfilter_coefficients_a, state_address::postfilter_state_a,
                           stack + 0x38u, stack + 0x28u);
        fast_fourth_stereo(state_address::postfilter_coefficients_b, state_address::postfilter_state_b,
                           stack + 0x30u, stack + 0x20u);

        const std::uint32_t clip_bypass = global_u32(state_address::soft_clip_disabled);
        if (clip_bypass == call_state().flow.value_b) {
            const auto threshold = static_cast<std::int32_t>(
                global_u32(state_address::clip_threshold));
            fast_soft_clip_stereo(threshold, stack + 0x38u, stack + 0x28u);
            fast_soft_clip_stereo(threshold, stack + 0x30u, stack + 0x20u);
        }

        fast_fourth_stereo(state_address::postfilter_coefficients_a, state_address::postfilter_alt_state_a,
                           stack + 0x28u, stack + 0x38u);
        fast_fourth_stereo(state_address::postfilter_coefficients_b, state_address::postfilter_alt_state_b,
                           stack + 0x30u, stack + 0x20u);

        // The first sum is popped to binary64.  The second is stored without
        // popping, so its unrounded binary80 magnitude remains live until the
        // later the 0x50-byte frame slot store.
        NativeDouble right_sum = guest_f64(stack + 0x20u);
        right_sum = right_sum + guest_f64(stack + 0x28u);
        global_store_f64(state_address::output_right, right_sum);

        NativeDouble left_sum = guest_f64(stack + 0x30u);
        left_sum = left_sum + guest_f64(stack + 0x38u);
        global_store_f64(state_address::output_left, left_sum);

        const NativeDouble original_left_abs = native_double_abs(left_sum);
        const NativeDouble original_right_abs = native_double_abs(global_f64(state_address::output_right));
        guest_store_f64(stack + 0x80u, original_right_abs);
        guest_store_f64(stack + 0x18u, original_right_abs);

        const NativeDouble first_peak = original_left_abs > original_right_abs
            ? original_left_abs : original_right_abs;
        const NativeDouble previous_first_peak = global_f64(state_address::postfilter_meter_a);
        if (first_peak > previous_first_peak)
            global_store_f64(state_address::postfilter_meter_a, first_peak);

        // The remaining copy of the unrounded left magnitude is rounded only
        // here in the legacy code.
        guest_store_f64(stack + 0x50u, original_left_abs);
        const std::uint32_t right_abs_low = read_u32(stack + 0x80u);
        const std::uint32_t right_abs_high = read_u32(stack + 0x84u);
        write_u32(stack + 0x18u, right_abs_low);
        write_u32(stack + 0x1cu, right_abs_high);

        std::uint32_t eax_base = clip_bypass;
        if (clip_bypass == call_state().flow.value_b) {
            eax_base = global_u32(state_address::output_gain_selector);
            fast_soft_clip_stereo(static_cast<std::int32_t>(eax_base),
                                  state_address::output_left, state_address::output_right);
        }

        NativeDouble left_difference = guest_f64(stack + 0x50u);
        left_difference = left_difference - native_double_abs(global_f64(state_address::output_left));
        NativeDouble right_difference = guest_f64(stack + 0x18u);
        right_difference = right_difference - native_double_abs(global_f64(state_address::output_right));
        guest_store_f64(stack + 0x18u, right_difference);

        const NativeDouble difference_peak = left_difference > right_difference
            ? left_difference : right_difference;
        const NativeDouble previous_difference_peak = global_f64(state_address::postfilter_meter_b);
        if (difference_peak > previous_difference_peak)
            global_store_f64(state_address::postfilter_meter_b, difference_peak);

        // FNSTSW from the final comparison updates AX only.  ECX/EDX still
        // contain the raw rounded magnitude copied from the 0x80-byte frame slot.
        update_float_condition(difference_peak, previous_difference_peak);
        call_state().flow.value_a = (eax_base & 0xffff0000u) | call_state().floating.comparison_status;
        call_state().flow.value_c = right_abs_low;
        call_state().flow.value_d = right_abs_high;

        const std::uint32_t selector = global_u32(state_address::output_selector);
        update_sub_condition(selector, call_state().flow.value_b, selector - call_state().flow.value_b, 32u);
    }
#endif

#undef SSNATIVE_BIQUAD_STAGE_ATTR

#if defined(SSNATIVE_M13_OUTLINE_ONE_POLE_STAGE)
#  define SSNATIVE_ONE_POLE_STAGE_ATTR __attribute__((hot, noinline, noclone))
#else
#  define SSNATIVE_ONE_POLE_STAGE_ATTR SSNATIVE_ALWAYS_INLINE
#endif

    SSNATIVE_ALWAYS_INLINE void fast_one_pole_channel(
        std::uint32_t coefficients, std::uint32_t state,
        std::uint32_t input_output, std::uint32_t previous_offset,
        std::uint32_t current_offset) {
        const NativeDouble previous = guest_f64(state + current_offset);
        guest_store_f64(state + previous_offset, previous);
        NativeDouble next = previous * constant_f64(coefficients + 16u);
        next = guest_f64(input_output) - next;
        guest_store_f64(state + current_offset, next);
        NativeDouble output = next * constant_f64(coefficients + 8u);
        NativeDouble term = constant_f64(coefficients) * guest_f64(state + previous_offset);
        output = output + term;
        guest_store_f64(input_output, output);
    }


#if defined(SSNATIVE_DOUBLE_PAIR_KERNELS)
    SSNATIVE_ONE_POLE_STAGE_ATTR void fast_one_pole_stereo_pair(
        std::uint32_t coefficients, std::uint32_t state,
        std::uint32_t first_sample, std::uint32_t second_sample) {
        const NativeDoublePair previous = guest_f64_pair(state + 8u, state + 24u);
        guest_store_f64_pair(state, state + 16u, previous);

        NativeDoublePair next = native_double_pair_mul_acc_right<true>(
            guest_f64_pair(first_sample, second_sample),
            previous, constant_f64(coefficients + 16u));
        guest_store_f64_pair(state + 8u, state + 24u, next);

        NativeDoublePair output = native_double_pair_mul_right(
            next, constant_f64(coefficients + 8u));
        output = native_double_pair_mul_acc_left<false>(
            output, constant_f64(coefficients), previous);
        guest_store_f64_pair(first_sample, second_sample, output);
    }
#endif

    SSNATIVE_ALWAYS_INLINE void fast_one_pole_stereo(
        std::uint32_t coefficients, std::uint32_t state,
        std::uint32_t first_sample, std::uint32_t second_sample) {
#if defined(SSNATIVE_DOUBLE_PAIR_KERNELS)
        fast_one_pole_stereo_pair(coefficients, state,
                                  first_sample, second_sample);
#else
        fast_one_pole_channel(coefficients, state, first_sample, 0u, 8u);
        fast_one_pole_channel(coefficients, state, second_sample, 16u, 24u);
#endif
    }

    __attribute__((noinline)) void fast_10008b60() {
        fast_one_pole_stereo(read_u32(call_state().flow.frame_cursor + 4u),
                             read_u32(call_state().flow.frame_cursor + 8u),
                             read_u32(call_state().flow.frame_cursor + 12u),
                             read_u32(call_state().flow.frame_cursor + 16u));
    }

#undef SSNATIVE_ONE_POLE_STAGE_ATTR

#if defined(SSNATIVE_M13_OUTLINE_FOURTH_STAGE)
#  define SSNATIVE_FOURTH_STAGE_ATTR __attribute__((hot, noinline, noclone))
#else
#  define SSNATIVE_FOURTH_STAGE_ATTR SSNATIVE_ALWAYS_INLINE
#endif

    SSNATIVE_ALWAYS_INLINE void fast_fourth_channel(
        std::uint32_t coefficients, std::uint32_t state,
        std::uint32_t input_output, std::uint32_t state_offset) {
        const auto w1_address = state + state_offset;
        const auto w2_address = w1_address + 8u;
        const auto w3_address = w1_address + 16u;
        const auto w4_address = w1_address + 24u;
        const NativeDouble w1 = guest_f64(w1_address);
        const NativeDouble w2 = guest_f64(w2_address);
        const NativeDouble w3 = guest_f64(w3_address);
        const NativeDouble w4 = guest_f64(w4_address);

        NativeDouble w0 = w1 * constant_f64(coefficients + 40u);
        w0 = guest_f64(input_output) - w0;
        NativeDouble term = constant_f64(coefficients + 48u) * w2;
        w0 = w0 - term;
        term = w3 * constant_f64(coefficients + 56u);
        w0 = w0 - term;
        term = w4 * constant_f64(coefficients + 64u);
        w0 = w0 - term;

        NativeDouble output = w0 * constant_f64(coefficients);
        term = constant_f64(coefficients + 32u) * w4;
        output = output + term;
        term = constant_f64(coefficients + 24u) * w3;
        output = output + term;
        term = constant_f64(coefficients + 16u) * w2;
        output = output + term;
        term = constant_f64(coefficients + 8u) * w1;
        output = output + term;

        guest_store_f64(input_output, output);
        copy_guest_u64(w4_address, w3_address);
        copy_guest_u64(w3_address, w2_address);
        copy_guest_u64(w2_address, w1_address);
        guest_store_f64(w1_address, w0);
    }


#if defined(SSNATIVE_DOUBLE_PAIR_KERNELS)
    SSNATIVE_FOURTH_STAGE_ATTR void fast_fourth_stereo_pair(
        std::uint32_t coefficients, std::uint32_t state,
        std::uint32_t first_sample, std::uint32_t second_sample) {
        const auto left_w1 = state + 8u;
        const auto right_w1 = state + 40u;
        const NativeDoublePair w1 = guest_f64_pair(left_w1, right_w1);
        const NativeDoublePair w2 = guest_f64_pair(left_w1 + 8u, right_w1 + 8u);
        const NativeDoublePair w3 = guest_f64_pair(left_w1 + 16u, right_w1 + 16u);
        const NativeDoublePair w4 = guest_f64_pair(left_w1 + 24u, right_w1 + 24u);
        const NativeDoublePair input = guest_f64_pair(first_sample, second_sample);

        NativeDoublePair w0 = native_double_pair_mul_acc_right<true>(
            input, w1, constant_f64(coefficients + 40u));
        w0 = native_double_pair_mul_acc_left<true>(
            w0, constant_f64(coefficients + 48u), w2);
        w0 = native_double_pair_mul_acc_right<true>(
            w0, w3, constant_f64(coefficients + 56u));
        w0 = native_double_pair_mul_acc_right<true>(
            w0, w4, constant_f64(coefficients + 64u));

        NativeDoublePair output = native_double_pair_mul_right(w0, constant_f64(coefficients));
        output = native_double_pair_mul_acc_left<false>(
            output, constant_f64(coefficients + 32u), w4);
        output = native_double_pair_mul_acc_left<false>(
            output, constant_f64(coefficients + 24u), w3);
        output = native_double_pair_mul_acc_left<false>(
            output, constant_f64(coefficients + 16u), w2);
        output = native_double_pair_mul_acc_left<false>(
            output, constant_f64(coefficients + 8u), w1);

        guest_store_f64_pair(first_sample, second_sample, output);
        copy_guest_u64(left_w1 + 24u, left_w1 + 16u);
        copy_guest_u64(right_w1 + 24u, right_w1 + 16u);
        copy_guest_u64(left_w1 + 16u, left_w1 + 8u);
        copy_guest_u64(right_w1 + 16u, right_w1 + 8u);
        copy_guest_u64(left_w1 + 8u, left_w1);
        copy_guest_u64(right_w1 + 8u, right_w1);
        guest_store_f64_pair(left_w1, right_w1, w0);
    }
#endif

#if defined(SSNATIVE_INLINE_FOURTH_WRAPPER)
    SSNATIVE_ALWAYS_INLINE void fast_fourth_stereo(
#else
    __attribute__((noinline)) void fast_fourth_stereo(
#endif
        std::uint32_t coefficients, std::uint32_t state,
        std::uint32_t first_sample, std::uint32_t second_sample) {
#if defined(SSNATIVE_DOUBLE_PAIR_KERNELS)
        fast_fourth_stereo_pair(coefficients, state,
                                first_sample, second_sample);
#else
        fast_fourth_channel(coefficients, state, first_sample, 8u);
        fast_fourth_channel(coefficients, state, second_sample, 40u);
#endif
    }

    __attribute__((noinline)) void fast_10008bd0() {
        fast_fourth_stereo(read_u32(call_state().flow.frame_cursor + 4u),
                           read_u32(call_state().flow.frame_cursor + 8u),
                           read_u32(call_state().flow.frame_cursor + 12u),
                           read_u32(call_state().flow.frame_cursor + 16u));
    }

#undef SSNATIVE_FOURTH_STAGE_ATTR

    [[nodiscard]] SSNATIVE_ALWAYS_INLINE NativeDouble fast_rms_envelope(
        NativeDouble first, NativeDouble second, std::uint32_t state_address,
        std::uint32_t coefficient_index) {
        // Exact translation of legacy helper 0x10008D00. The original x87
        // compare chooses the first value only for first > second; equality
        // and unordered comparisons select the second value.
        const NativeDouble selected = first > second ? first : second;

#if defined(SSNATIVE_SOFT_X87)
        static constexpr std::array<NativeDouble, 5> kCoefficients = {
            NativeDouble::from_bits(0x3ffeu, 0xfd70a3d70a3d7000ull),
            NativeDouble::from_bits(0x3ffeu, 0xf333333333333000ull),
            NativeDouble::from_bits(0x3ffeu, 0xcaf2f9873ffac000ull),
            NativeDouble::from_bits(0x3ffeu, 0xb03c4b09e98dd000ull),
            NativeDouble::from_bits(0x3ffeu, 0x8000000000000000ull),
        };
        const NativeDouble coefficient = kCoefficients[coefficient_index];
        NativeDouble complement = NativeDouble::from_bits(0x3fffu, 0x8000000000000000ull);
#else
        static constexpr std::array<std::uint64_t, 5> kCoefficientBits = {
            0x3fefae147ae147aeull,
            0x3fee666666666666ull,
            0x3fe95e5f30e7ff58ull,
            0x3fe60789613d31baull,
            0x3fe0000000000000ull,
        };
        const NativeDouble coefficient = static_cast<NativeDouble>(
            std::bit_cast<double>(kCoefficientBits[coefficient_index]));
        NativeDouble complement = constant_f64(state_address::unity);
#endif

        NativeDouble output = selected * selected;
        complement = complement - coefficient;
        output = output * complement;

        NativeDouble state_term = coefficient * guest_f64(state_address);
        output = output + state_term;

        // The legacy routine performs a non-popping QWORD store before FSQRT.
        // Preserve that explicit binary64 state update while taking the square
        // root from the unrounded binary80 accumulator.
        guest_store_f64(state_address, output);
        call_state().flow.value_a = state_address;
        return native_double_sqrt(output);
    }

    __attribute__((noinline)) void fast_level_detector(bool smoothed) {
        constexpr std::uint32_t kInputBase = state_address::band_outputs;
        constexpr std::uint32_t kOutputBase = state_address::dynamics_level;
        constexpr std::uint32_t kStateBase = state_address::detector_smoothing;

        for (std::uint32_t band = 0; band < 5u; ++band) {
            const std::uint32_t input = kInputBase + band * 16u;
            const NativeDouble first = native_double_abs(global_f64(input));
            const NativeDouble second = native_double_abs(global_f64(input + 8u));

            NativeDouble level;
            if (smoothed) {
                level = fast_rms_envelope(
                    first, second, kStateBase + band * 8u, band);
            } else {
                // Same x87 FCOM/FNSTSW selection as the original loop: the
                // first operand wins only when it is strictly greater.
                level = first > second ? first : second;
            }
            global_store_f64(kOutputBase + band * 8u, level);
        }

        // Preserve loop terminal values that can be observed by the remaining
        // translated caller body before its next explicit register writes.
        call_state().flow.index = 5u;
        call_state().flow.pointer = state_address::band_output_end;
        if (smoothed) call_state().flow.value_a = kStateBase + 4u * 8u;
        else {
            call_state().flow.value_c = state_address::band_output_end;
            call_state().flow.value_d = kOutputBase + 5u * 8u;
        }
    }

    SSNATIVE_ALWAYS_INLINE void fast_soft_clip_one(
        std::int32_t threshold, std::uint32_t sample_address) {
        const NativeDouble magnitude = native_double_abs(guest_f64(sample_address));
        const NativeDouble threshold_ext = static_cast<NativeDouble>(threshold);
        if (!(magnitude > threshold_ext) || read_u32(state_address::soft_clip_disabled) != 0u) return;

        const NativeDouble excess = magnitude - threshold_ext;
        const NativeDouble knee = static_cast<NativeDouble>(static_cast<std::int32_t>(read_u32(state_address::soft_clip_knee)));
        NativeDouble clipped = knee + excess;
        clipped = knee / clipped;
        clipped = clipped * excess;
        clipped = threshold_ext + clipped;
        if (guest_f64(sample_address) < guest_f64(state_address::zero)) clipped = -clipped;
        guest_store_f64(sample_address, clipped);
    }

    SSNATIVE_ALWAYS_INLINE void fast_soft_clip_mono(
        std::int32_t threshold, std::uint32_t sample_address) {
        fast_soft_clip_one(threshold, sample_address);
    }

    __attribute__((noinline)) void fast_10008ff0() {
        fast_soft_clip_mono(static_cast<std::int32_t>(read_u32(call_state().flow.frame_cursor + 4u)),
                            read_u32(call_state().flow.frame_cursor + 8u));
    }

    SSNATIVE_ALWAYS_INLINE void fast_soft_clip_stereo_channel(
        NativeDouble threshold_ext, std::uint32_t sample_address) {
        const NativeDouble magnitude = native_double_abs(guest_f64(sample_address));
        if (!(magnitude > threshold_ext)) return;
        const NativeDouble excess = magnitude - threshold_ext;
        const NativeDouble knee = static_cast<NativeDouble>(static_cast<std::int32_t>(read_u32(state_address::soft_clip_knee)));
        NativeDouble clipped = knee + excess;
        clipped = knee / clipped;
        clipped = clipped * excess;
        clipped = threshold_ext + clipped;
        if (guest_f64(sample_address) < guest_f64(state_address::zero)) clipped = -clipped;
        guest_store_f64(sample_address, clipped);
    }

    SSNATIVE_ALWAYS_INLINE void fast_soft_clip_stereo(
        std::int32_t threshold, std::uint32_t first_sample,
        std::uint32_t second_sample) {
        const NativeDouble threshold_ext = static_cast<NativeDouble>(threshold);
        fast_soft_clip_stereo_channel(threshold_ext, first_sample);
        fast_soft_clip_stereo_channel(threshold_ext, second_sample);
    }

    __attribute__((noinline)) void fast_10009070() {
        fast_soft_clip_stereo(
            static_cast<std::int32_t>(read_u32(call_state().flow.frame_cursor + 4u)),
            read_u32(call_state().flow.frame_cursor + 8u), read_u32(call_state().flow.frame_cursor + 12u));
    }

    __attribute__((noinline)) void fast_band_delay_mix() {
        auto delay_index = static_cast<std::int32_t>(global_u32(state_address::delay_index));
        const auto delay_limit = static_cast<std::int32_t>(global_u32(state_address::delay_limit));
        if (delay_index < delay_limit) {
            ++delay_index;
        } else {
            delay_index = 0;
        }
        global_store_u32(state_address::delay_index, static_cast<std::uint32_t>(delay_index));

        NativeDouble interpolation = static_cast<NativeDouble>(
            static_cast<std::int32_t>(global_u32(state_address::interpolation_percent)));
        interpolation = interpolation * global_f64(state_address::sample_percent_scale);
        NativeDouble complement = constant_f64(state_address::unity);
        complement = complement - interpolation;

        std::uint32_t weight_address = state_address::delay_weights;
        for (std::uint32_t band = 0; band < 5u; ++band) {
            const std::uint32_t gain_address = state_address::dynamics_gain + band * 8u;

            NativeDouble gain = global_f64(gain_address);
            gain = gain * interpolation;
            gain = gain + complement;
            global_store_f64(gain_address, gain);

            NativeDouble blend_first = global_f64(gain_address);
            blend_first = blend_first * global_f64(state_address::blend_current);
            NativeDouble blend_second = global_f64(state_address::smoothed_band_gain + band * 8u);
            blend_second = blend_second * global_f64(state_address::blend_previous);
            NativeDouble blend = blend_first + blend_second;

            // Both the original temporary stack slot and the persistent state
            // are QWORD stores. Round once to binary64 before the inner loop.
            const double blend_rounded = static_cast<double>(blend);
            write_f64(call_state().flow.frame_cursor + 0x80u, blend_rounded);
            global_store_f64(state_address::smoothed_band_gain + band * 8u,
                             static_cast<NativeDouble>(blend_rounded));

            const NativeDouble weight = static_cast<NativeDouble>(
                static_cast<std::int32_t>(global_u32(weight_address)));
            std::uint32_t history_address =
                state_address::delay_history +
                static_cast<std::uint32_t>(band + 14u *
                    static_cast<std::uint32_t>(delay_index)) * 8u;
            std::uint32_t coefficient_offset = band * 16u;

            for (unsigned channel = 0; channel < 2u; ++channel) {
                const NativeDouble history = global_f64(history_address);

                NativeDouble delayed = static_cast<NativeDouble>(blend_rounded);
                delayed = delayed * global_f64(state_address::band_outputs + coefficient_offset);
                global_store_f64(history_address, delayed);

                NativeDouble output = weight * history;
                output = output * global_f64(0x1000c550u);
                global_store_f64(state_address::delayed_bands + coefficient_offset, output);

                history_address += 0x38u;
                coefficient_offset += 8u;
            }

            weight_address += 4u;
        }

        // Preserve the integer register values left by the original loops.
        call_state().flow.value_b = static_cast<std::uint32_t>(delay_index);
        call_state().flow.value_d = 5u;
        call_state().flow.pointer = state_address::clip_threshold;
        call_state().flow.index = 0u;
        call_state().flow.value_a = 80u;
        call_state().flow.value_c = state_address::delay_history +
                   static_cast<std::uint32_t>(4u + 14u *
                       static_cast<std::uint32_t>(delay_index)) * 8u + 0x70u;
    }

    SSNATIVE_ALWAYS_INLINE void fast_smooth_min(
        std::uint32_t input_address, std::uint32_t state_address,
        std::int32_t percent) {
        const NativeDouble input = guest_f64(input_address);
        const NativeDouble state = guest_f64(state_address);
        const NativeDouble target = input < state ? input : state;
        NativeDouble output = static_cast<NativeDouble>(100 - percent) * state;
        NativeDouble term = static_cast<NativeDouble>(percent) * target;
        output = output + term;
        output = output * guest_f64(state_address::sample_percent_scale);
        guest_store_f64(state_address, output);
    }

    __attribute__((noinline)) void fast_100095c0() {
        fast_smooth_min(read_u32(call_state().flow.frame_cursor + 4u),
                        read_u32(call_state().flow.frame_cursor + 8u),
                        static_cast<std::int32_t>(read_u32(call_state().flow.frame_cursor + 12u)));
    }

#undef SSNATIVE_M13_BLOCK_ATTR

    enum class ProcessStage : std::uint8_t {
            Entry,
            FlowStep00,
            FlowStep01,
            FlowStep02,
            FlowStep03,
            FlowStep04,
            FlowStep05,
            FlowStep06,
            FlowStep07,
            FlowStep08,
            FlowStep09,
            FlowStep10,
            FlowStep11,
            FlowStep12,
            FlowStep13,
            FlowStep14,
            FlowStep15,
            FlowStep16,
            FlowStep17,
            FlowStep18,
            FlowStep19,
            FlowStep20,
            FlowStep21,
            FlowStep22,
            FlowStep23,
            FlowStep24,
            FlowStep25,
            FlowStep26,
            FlowStep27,
            FlowStep28,
            FlowStep29,
            FlowStep30,
            FlowStep31,
            FlowStep32,
            FlowStep33,
            FlowStep34,
            FlowStep35,
            FlowStep36,
            FlowStep37,
            FlowStep38,
            FlowStep39,
            FlowStep40,
            FlowStep41,
            FlowStep42,
            FlowStep43,
            FlowStep44,
            FlowStep45,
            FlowStep46,
            FlowStep47,
            FlowStep48,
            FlowStep49,
            FlowStep50,
            FlowStep51,
            FlowStep52,
            FlowStep53,
            FlowStep54,
            FlowStep55,
            FlowStep56,
            FlowStep57,
            FlowStep58,
            FlowStep59,
            FlowStep60,
            FlowStep61,
            FlowStep62,
            FlowStep63,
            FlowStep64,
            FlowStep65,
            FlowStep66,
            FlowStep67,
            FlowStep68,
            FlowStep69,
            FlowStep70,
            FlowStep71,
            FlowStep72,
            FlowStep73,
            FlowStep74,
            FlowStep75,
            FlowStep76,
            FlowStep77,
            FlowStep78,
            FlowStep79,
            FlowStep80,
            FlowStep81,
            FlowStep82,
            FlowStep83,
            FlowStep84,
            FlowStep85
    };
    static_assert(static_cast<std::size_t>(ProcessStage::FlowStep85) + 1u ==
                  native_process::kStructuredProcessStageCount);

    __attribute__((hot, noinline)) void execute_native_process_direct() {
        auto& flow = call_state().flow;
        auto& floating = call_state().floating;
        std::byte* __restrict__ const frame_bytes = frame_bytes_;
        std::byte* __restrict__ const global_bytes = global_bytes_;
        goto Entry;
        Entry: {

                flow.frame_cursor -= 4u;
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.frame_base);
                flow.frame_base = flow.frame_cursor;
                { const std::uint32_t lhs = flow.frame_cursor; const std::uint32_t rhs = 0xfffffff8u; const std::uint32_t result = lhs & rhs; flow.frame_cursor = result; update_logic_condition( result, 32u); }
                { const std::uint32_t lhs = flow.frame_cursor; const std::uint32_t rhs = 0x0000007cu; const std::uint32_t result = lhs - rhs; flow.frame_cursor = result; update_sub_condition( lhs, rhs, result, 32u); }
                flow.value_a = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_base + 0x00000014u);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.value_b);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.index);
                { const std::uint32_t lhs = flow.value_a; const std::uint32_t rhs = 0x00000010u; update_sub_condition(lhs, rhs, lhs - rhs, 32u); }
                flow.value_a = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_base + 0x00000010u);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.pointer);
                if (!flow.condition.zero) {
                    goto FlowStep81;
                }
                if ((static_cast<std::int32_t>(read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_base + 0x0000001cu)) < static_cast<std::int32_t>(0x0000ac44u))) {
                    goto FlowStep81;
                }
                flow.value_d = read_global_direct<std::uint32_t>(global_bytes, 0x100d5f54u);
                flow.value_c = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_base + 0x0000000cu);
                { const std::uint32_t lhs = flow.value_d; const std::uint32_t rhs = 0x000000ffu; const std::uint32_t result = lhs & rhs; flow.value_d = result; update_logic_condition( result, 32u); }
                write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000010u, static_cast<std::uint32_t>(flow.value_c));
                write_global_direct<std::uint32_t>(global_bytes, 0x100d5f54u, static_cast<std::uint32_t>(flow.value_d));
                flow.value_d = flow.value_a + static_cast<std::uint32_t>(-1);
                update_logic_condition((flow.value_a) & (flow.value_a), 32u);
                write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000014u, static_cast<std::uint32_t>(flow.value_d));
                if (flow.condition.zero) {
                    goto FlowStep82;
                }
                { const std::uint32_t lhs = flow.value_b; const std::uint32_t rhs = flow.value_b; const std::uint32_t result = lhs ^ rhs; flow.value_b = result; update_logic_condition( result, 32u); }
                flow.pointer = flow.value_c;
                goto FlowStep00;
            }
        FlowStep00: {
                flow.value_a = static_cast<std::uint32_t>(static_cast<std::int32_t>(static_cast<std::int16_t>(read_u16(flow.pointer))));
                flow.value_c = read_global_direct<std::uint32_t>(global_bytes, 0x101060f0u);
                write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000018u, static_cast<std::uint32_t>(flow.value_a));
                floating.temporary[7u] = static_cast<NativeDouble>(static_cast<std::int32_t>(read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000018u)));
                { const std::uint32_t lhs = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_base + 0x00000018u); const std::uint32_t rhs = 0x00000002u; update_sub_condition(lhs, rhs, lhs - rhs, 32u); }
                write_global_direct<std::uint64_t>(global_bytes, 0x100d6168u, native_double_to_binary64_bits(floating.temporary[7u]));
                if (!flow.condition.zero) {
                    goto FlowStep02;
                }
                flow.value_d = static_cast<std::uint32_t>(static_cast<std::int32_t>(static_cast<std::int16_t>(read_u16(flow.pointer + 0x00000002u))));
                if (((((((flow.value_c >> 8u) & 0xffu)) & (0x00000001u)) & 0xffu) == 0u)) {
                    goto FlowStep01;
                }
                flow.value_a = static_cast<std::uint32_t>(static_cast<std::int32_t>(static_cast<std::int16_t>(read_u16(flow.pointer))));
                { const std::uint32_t lhs = flow.value_d; const std::uint32_t rhs = flow.value_a; const std::uint32_t result = lhs + rhs; flow.value_d = result; update_add_condition( lhs, rhs, result, 32u); }
                { const unsigned count = (0x00000001u) & 31u; if (count != 0u) { const std::uint32_t old_value = flow.value_d; const std::uint32_t result = static_cast<std::uint32_t>(static_cast<std::int32_t>(old_value) >> count); flow.value_d = result; update_logic_condition(result, 32u); } }
                write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000018u, static_cast<std::uint32_t>(flow.value_d));
                floating.temporary[7u] = static_cast<NativeDouble>(static_cast<std::int32_t>(read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000018u)));
                write_global_direct<std::uint64_t>(global_bytes, 0x100d6170u, native_double_to_binary64_bits(floating.temporary[7u]));
                flow.value_d = read_global_direct<std::uint32_t>(global_bytes, 0x100d6170u);
                flow.value_a = read_global_direct<std::uint32_t>(global_bytes, 0x100d6174u);
                write_global_direct<std::uint32_t>(global_bytes, 0x100d6168u, static_cast<std::uint32_t>(flow.value_d));
                write_global_direct<std::uint32_t>(global_bytes, 0x100d616cu, static_cast<std::uint32_t>(flow.value_a));
                goto FlowStep03;
            }
        FlowStep01: {
                write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000018u, static_cast<std::uint32_t>(flow.value_d));
                floating.temporary[7u] = static_cast<NativeDouble>(static_cast<std::int32_t>(read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000018u)));
                write_global_direct<std::uint64_t>(global_bytes, 0x100d6170u, native_double_to_binary64_bits(floating.temporary[7u]));
                goto FlowStep03;
            }
        FlowStep02: {
                flow.value_a = read_global_direct<std::uint32_t>(global_bytes, 0x100d6168u);
                flow.value_d = read_global_direct<std::uint32_t>(global_bytes, 0x100d616cu);
                write_global_direct<std::uint32_t>(global_bytes, 0x100d6170u, static_cast<std::uint32_t>(flow.value_a));
                write_global_direct<std::uint32_t>(global_bytes, 0x100d6174u, static_cast<std::uint32_t>(flow.value_d));
                goto FlowStep03;
            }
        FlowStep03: {
                if ((((((flow.value_c & 0xffu)) & (0x00000010u)) & 0xffu) == 0u)) {
                    goto FlowStep04;
                }
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x100d6168u);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x100d6170u);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x100d68a0u);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x1000d778u);
                fast_fourth_stereo(0x1000d778u, 0x100d68a0u, 0x100d6170u, 0x100d6168u);
                flow.value_c = read_global_direct<std::uint32_t>(global_bytes, 0x101060f0u);
                { const std::uint32_t lhs = flow.frame_cursor; const std::uint32_t rhs = 0x00000010u; const std::uint32_t result = lhs + rhs; flow.frame_cursor = result; update_add_condition( lhs, rhs, result, 32u); }
                goto FlowStep04;
            }
        FlowStep04: {
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6168u));
                floating.temporary[7u] = native_double_abs(floating.temporary[7u]);
                floating.temporary[6u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6170u));
                floating.temporary[6u] = native_double_abs(floating.temporary[6u]);
                write_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000018u, native_double_to_binary64_bits(floating.temporary[6u]));
                update_float_condition(floating.temporary[7u], native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000018u)));
                flow.value_a = (flow.value_a & 0xffff0000u) | ((floating.comparison_status) & 0xffffu);
                if (((((((flow.value_a >> 8u) & 0xffu)) & (0x00000041u)) & 0xffu) != 0u)) {
                    goto FlowStep05;
                }
                write_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000078u, native_double_to_binary64_bits(floating.temporary[7u]));
                goto FlowStep06;
            }
        FlowStep05: {
                flow.value_a = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000018u);
                flow.value_d = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x0000001cu);
                write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000078u, static_cast<std::uint32_t>(flow.value_a));
                write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x0000007cu, static_cast<std::uint32_t>(flow.value_d));
                goto FlowStep06;
            }
        FlowStep06: {
                floating.temporary[6u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d63c0u));
                update_float_condition(floating.temporary[6u], floating.temporary[7u]);
                flow.value_a = (flow.value_a & 0xffff0000u) | ((floating.comparison_status) & 0xffffu);
                if (((((((flow.value_a >> 8u) & 0xffu)) & (0x00000001u)) & 0xffu) == 0u)) {
                    goto FlowStep07;
                }
                write_global_direct<std::uint64_t>(global_bytes, 0x100d63c0u, native_double_to_binary64_bits(floating.temporary[7u]));
                goto FlowStep08;
            }
        FlowStep07: {
                floating.temporary[7u] = floating.temporary[7u];
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d63c0u));
                update_float_condition(floating.temporary[7u], native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000018u)));
                flow.value_a = (flow.value_a & 0xffff0000u) | ((floating.comparison_status) & 0xffffu);
                if (((((((flow.value_a >> 8u) & 0xffu)) & (0x00000001u)) & 0xffu) == 0u)) {
                    goto FlowStep08;
                }
                flow.value_a = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000018u);
                flow.value_d = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x0000001cu);
                write_global_direct<std::uint32_t>(global_bytes, 0x100d63c0u, static_cast<std::uint32_t>(flow.value_a));
                write_global_direct<std::uint32_t>(global_bytes, 0x100d63c4u, static_cast<std::uint32_t>(flow.value_d));
                goto FlowStep08;
            }
        FlowStep08: {
                if ((((read_global_direct<std::uint32_t>(global_bytes, 0x1010609cu)) & 0xffffffffu) != ((flow.value_b) & 0xffffffffu))) {
                    goto FlowStep10;
                }
                if ((((((flow.value_c & 0xffu)) & (0x00000001u)) & 0xffu) == 0u)) {
                    goto FlowStep10;
                }
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x00000004u);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x100d6168u);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x100d6170u);
                flow.frame_cursor -= 4u; goto FlowStep83;
            }
        FlowStep09: {
                { const std::uint32_t lhs = flow.frame_cursor; const std::uint32_t rhs = 0x0000000cu; const std::uint32_t result = lhs + rhs; flow.frame_cursor = result; update_add_condition( lhs, rhs, result, 32u); }
                goto FlowStep10;
            }
        FlowStep10: {
                flow.index = read_global_direct<std::uint32_t>(global_bytes, 0x100d6224u);
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6170u));
                floating.temporary[7u] = floating.temporary[7u] - native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6168u));
                flow.value_a = read_u32((flow.index * 4u) + 0x1000f678u);
                write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000018u, static_cast<std::uint32_t>(flow.value_a));
                truncate_native_double_to_i64_parts(floating.temporary[7u]);
                write_u32((flow.index * 4u) + 0x1000f678u, static_cast<std::uint32_t>(flow.value_a));
                flow.value_a = read_global_direct<std::uint32_t>(global_bytes, 0x100d5f10u);
                if ((static_cast<std::int32_t>(flow.index) >= static_cast<std::int32_t>(flow.value_a))) {
                    goto FlowStep11;
                }
                { const std::uint32_t old_value = flow.index; const std::uint32_t result = old_value + 1u; flow.index = result; const bool carry = flow.condition.carry; update_add_condition(old_value, 1u, result, 32u); flow.condition.carry = carry; }
                write_global_direct<std::uint32_t>(global_bytes, 0x100d6224u, static_cast<std::uint32_t>(flow.index));
                goto FlowStep12;
            }
        FlowStep11: {
                write_global_direct<std::uint32_t>(global_bytes, 0x100d6224u, static_cast<std::uint32_t>(flow.value_b));
                goto FlowStep12;
            }
        FlowStep12: {
                if ((((read_global_direct<std::uint32_t>(global_bytes, 0x101060a8u)) & 0xffffffffu) != ((flow.value_b) & 0xffffffffu))) {
                    goto FlowStep17;
                }
                if ((((read_global_direct<std::uint32_t>(global_bytes, 0x1010609cu)) & 0xffffffffu) != ((flow.value_b) & 0xffffffffu))) {
                    goto FlowStep17;
                }
                floating.temporary[7u] = static_cast<NativeDouble>(static_cast<std::int32_t>(read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000018u)));
                flow.value_c = read_global_direct<std::uint32_t>(global_bytes, 0x100d6220u);
                { const std::uint32_t lhs = flow.value_c; const std::uint32_t rhs = 0x000000ffu; const std::uint32_t result = lhs & rhs; flow.value_c = result; update_logic_condition( result, 32u); }
                floating.temporary[6u] = floating.temporary[7u];
                floating.temporary[6u] = floating.temporary[6u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c660u));
                floating.temporary[6u] = floating.temporary[6u] + native_double_from_binary64_bits(read_u64((flow.value_c * 8u) + 0x1000edc8u));
                write_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000050u, native_double_to_binary64_bits(floating.temporary[6u]));
                floating.temporary[6u] = floating.temporary[6u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c660u));
                floating.temporary[6u] = floating.temporary[7u] - floating.temporary[6u];
                write_u64((flow.value_c * 8u) + 0x1000edc8u, native_double_to_binary64_bits(floating.temporary[6u]));
                floating.temporary[7u] = floating.temporary[7u];
                floating.temporary[7u] = native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000050u));
                floating.temporary[7u] = native_double_abs(floating.temporary[7u]);
                update_float_condition(floating.temporary[7u], native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6240u)));
                flow.value_a = (flow.value_a & 0xffff0000u) | ((floating.comparison_status) & 0xffffu);
                if (((((((flow.value_a >> 8u) & 0xffu)) & (0x00000041u)) & 0xffu) != 0u)) {
                    goto FlowStep13;
                }
                floating.temporary[6u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c650u));
                goto FlowStep14;
            }
        FlowStep13: {
                floating.temporary[6u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c640u));
                goto FlowStep14;
            }
        FlowStep14: {
                floating.temporary[5u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c000u));
                floating.temporary[5u] = floating.temporary[5u] - floating.temporary[6u];
                floating.temporary[5u] = floating.temporary[5u] * floating.temporary[7u];
                floating.temporary[4u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6240u));
                floating.temporary[4u] = floating.temporary[4u] * floating.temporary[6u];
                floating.temporary[5u] = floating.temporary[5u] + floating.temporary[4u];
                write_global_direct<std::uint64_t>(global_bytes, 0x100d6240u, native_double_to_binary64_bits(floating.temporary[5u]));
                floating.temporary[6u] = floating.temporary[6u];
                floating.temporary[7u] = floating.temporary[7u];
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6240u));
                update_float_condition(floating.temporary[7u], native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c630u)));
                flow.value_a = (flow.value_a & 0xffff0000u) | ((floating.comparison_status) & 0xffffu);
                if (((((((flow.value_a >> 8u) & 0xffu)) & (0x00000041u)) & 0xffu) != 0u)) {
                    goto FlowStep15;
                }
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c630u));
                floating.temporary[7u] = floating.temporary[7u] / native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6240u));
                goto FlowStep16;
            }
        FlowStep15: {
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c000u));
                goto FlowStep16;
            }
        FlowStep16: {
                floating.temporary[6u] = floating.temporary[7u];
                floating.temporary[6u] = floating.temporary[6u] * native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000050u));
                { const std::uint32_t old_value = flow.value_c; const std::uint32_t result = old_value + 1u; flow.value_c = result; const bool carry = flow.condition.carry; update_add_condition(old_value, 1u, result, 32u); flow.condition.carry = carry; }
                write_global_direct<std::uint32_t>(global_bytes, 0x100d6220u, static_cast<std::uint32_t>(flow.value_c));
                write_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000050u, native_double_to_binary64_bits(floating.temporary[6u]));
                write_global_direct<std::uint64_t>(global_bytes, 0x100d63d8u, native_double_to_binary64_bits(floating.temporary[7u]));
                floating.temporary[7u] = static_cast<NativeDouble>(static_cast<std::int32_t>(read_global_direct<std::uint32_t>(global_bytes, 0x10106094u)));
                floating.temporary[7u] = floating.temporary[7u] * native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000050u));
                floating.temporary[7u] = floating.temporary[7u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c4e0u));
                floating.temporary[6u] = floating.temporary[7u];
                floating.temporary[6u] = floating.temporary[6u] + native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6170u));
                write_global_direct<std::uint64_t>(global_bytes, 0x100d6170u, native_double_to_binary64_bits(floating.temporary[6u]));
                floating.temporary[6u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6168u));
                floating.temporary[6u] = floating.temporary[6u] - floating.temporary[7u];
                write_global_direct<std::uint64_t>(global_bytes, 0x100d6168u, native_double_to_binary64_bits(floating.temporary[6u]));
                floating.temporary[7u] = floating.temporary[7u];
                goto FlowStep17;
            }
        FlowStep17: {
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6170u));
                floating.temporary[7u] = floating.temporary[7u] - native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6168u));
                floating.temporary[7u] = native_double_abs(floating.temporary[7u]);
                update_float_condition(floating.temporary[7u], native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d63d0u)));
                flow.value_a = (flow.value_a & 0xffff0000u) | ((floating.comparison_status) & 0xffffu);
                if (((((((flow.value_a >> 8u) & 0xffu)) & (0x00000041u)) & 0xffu) != 0u)) {
                    goto FlowStep18;
                }
                write_global_direct<std::uint64_t>(global_bytes, 0x100d63d0u, native_double_to_binary64_bits(floating.temporary[7u]));
                goto FlowStep19;
            }
        FlowStep18: {
                floating.temporary[7u] = floating.temporary[7u];
                goto FlowStep19;
            }
        FlowStep19: {
                #if defined(SSNATIVE_M13_NATIVE_PREFILTER_SETUP)
                fast_m13_prefilter_setup(); goto FlowStep20;
                #else
                flow.value_c = read_global_direct<std::uint32_t>(global_bytes, 0x100d6168u);
                flow.value_a = read_global_direct<std::uint32_t>(global_bytes, 0x100d6170u);
                flow.value_d = read_global_direct<std::uint32_t>(global_bytes, 0x100d616cu);
                write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000058u, static_cast<std::uint32_t>(flow.value_c));
                flow.value_c = read_global_direct<std::uint32_t>(global_bytes, 0x100d6174u);
                write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000060u, static_cast<std::uint32_t>(flow.value_a));
                flow.value_a = read_global_direct<std::uint32_t>(global_bytes, 0x100d616cu);
                write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000064u, static_cast<std::uint32_t>(flow.value_c));
                flow.value_c = read_global_direct<std::uint32_t>(global_bytes, 0x100d6170u);
                write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000044u, static_cast<std::uint32_t>(flow.value_a));
                write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x0000005cu, static_cast<std::uint32_t>(flow.value_d));
                flow.value_d = read_global_direct<std::uint32_t>(global_bytes, 0x100d6168u);
                write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000048u, static_cast<std::uint32_t>(flow.value_c));
                flow.value_a = flow.frame_cursor + 0x00000048u;
                flow.value_c = flow.frame_cursor + 0x00000040u;
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.value_a);
                write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000044u, static_cast<std::uint32_t>(flow.value_d));
                flow.value_d = read_global_direct<std::uint32_t>(global_bytes, 0x100d6174u);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.value_c);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x100d5fb8u);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x1000d760u);
                write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x0000005cu, static_cast<std::uint32_t>(flow.value_d));
                fast_one_pole_stereo(0x1000d760u, 0x100d5fb8u, flow.value_c, flow.value_a);
                flow.value_d = flow.frame_cursor + 0x00000070u;
                flow.value_a = flow.frame_cursor + 0x00000068u;
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.value_d);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.value_a);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x100d5ff8u);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x1000d748u);
                fast_one_pole_stereo(0x1000d748u, 0x100d5ff8u, flow.value_a, flow.value_d); goto FlowStep20;
                #endif
                goto FlowStep20;
            }
        FlowStep20: {
                floating.temporary[7u] = native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000080u));
                floating.temporary[7u] = floating.temporary[7u] + native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000078u));
                { const std::uint32_t lhs = flow.frame_cursor; const std::uint32_t rhs = 0x00000020u; const std::uint32_t result = lhs + rhs; flow.frame_cursor = result; update_add_condition( lhs, rhs, result, 32u); }
                floating.temporary[7u] = native_double_abs(floating.temporary[7u]);
                floating.temporary[7u] = floating.temporary[7u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c620u));
                floating.temporary[6u] = native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000048u));
                floating.temporary[6u] = floating.temporary[6u] + native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000040u));
                floating.temporary[6u] = native_double_abs(floating.temporary[6u]);
                floating.temporary[6u] = floating.temporary[6u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c620u));
                write_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000070u, native_double_to_binary64_bits(floating.temporary[6u]));
                update_float_condition(floating.temporary[7u], native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1010ed58u)));
                flow.value_a = (flow.value_a & 0xffff0000u) | ((floating.comparison_status) & 0xffffu);
                if (((((((flow.value_a >> 8u) & 0xffu)) & (0x00000041u)) & 0xffu) != 0u)) {
                    goto FlowStep21;
                }
                floating.temporary[6u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1010ed30u));
                write_global_direct<std::uint32_t>(global_bytes, 0x100d5f58u, static_cast<std::uint32_t>(flow.value_b));
                goto FlowStep23;
            }
        FlowStep21: {
                floating.temporary[6u] = static_cast<NativeDouble>(static_cast<std::int32_t>(read_global_direct<std::uint32_t>(global_bytes, 0x100d635cu)));
                update_float_condition(floating.temporary[6u], native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000078u)));
                flow.value_a = (flow.value_a & 0xffff0000u) | ((floating.comparison_status) & 0xffffu);
                if (((((((flow.value_a >> 8u) & 0xffu)) & (0x00000041u)) & 0xffu) != 0u)) {
                    goto FlowStep22;
                }
                floating.temporary[6u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c610u));
                write_global_direct<std::uint32_t>(global_bytes, 0x100d5f58u, static_cast<std::uint32_t>(0x00000001u));
                goto FlowStep23;
            }
        FlowStep22: {
                floating.temporary[6u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1010ed38u));
                goto FlowStep23;
            }
        FlowStep23: {
                floating.temporary[5u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c000u));
                floating.temporary[5u] = floating.temporary[5u] - floating.temporary[6u];
                floating.temporary[5u] = floating.temporary[5u] * floating.temporary[7u];
                floating.temporary[4u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1010ed58u));
                floating.temporary[4u] = floating.temporary[4u] * floating.temporary[6u];
                floating.temporary[5u] = floating.temporary[5u] + floating.temporary[4u];
                write_global_direct<std::uint64_t>(global_bytes, 0x1010ed58u, native_double_to_binary64_bits(floating.temporary[5u]));
                floating.temporary[6u] = floating.temporary[6u];
                floating.temporary[7u] = floating.temporary[7u];
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1010ed58u));
                update_float_condition(floating.temporary[7u], native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6350u)));
                flow.value_a = (flow.value_a & 0xffff0000u) | ((floating.comparison_status) & 0xffffu);
                if (((((((flow.value_a >> 8u) & 0xffu)) & (0x00000001u)) & 0xffu) == 0u)) {
                    goto FlowStep24;
                }
                flow.value_c = read_global_direct<std::uint32_t>(global_bytes, 0x100d6350u);
                flow.value_d = read_global_direct<std::uint32_t>(global_bytes, 0x100d6354u);
                write_global_direct<std::uint32_t>(global_bytes, 0x1010ed58u, static_cast<std::uint32_t>(flow.value_c));
                write_global_direct<std::uint32_t>(global_bytes, 0x1010ed5cu, static_cast<std::uint32_t>(flow.value_d));
                goto FlowStep24;
            }
        FlowStep24: {
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c600u));
                floating.temporary[7u] = floating.temporary[7u] / native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1010ed58u));
                write_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000068u, native_double_to_binary64_bits(floating.temporary[7u]));
                floating.temporary[7u] = native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000070u));
                update_float_condition(floating.temporary[7u], native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1010ed10u)));
                flow.value_a = (flow.value_a & 0xffff0000u) | ((floating.comparison_status) & 0xffffu);
                if (((((((flow.value_a >> 8u) & 0xffu)) & (0x00000041u)) & 0xffu) != 0u)) {
                    goto FlowStep25;
                }
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1010ece8u));
                write_global_direct<std::uint32_t>(global_bytes, 0x100d5f58u, static_cast<std::uint32_t>(flow.value_b));
                goto FlowStep27;
            }
        FlowStep25: {
                floating.temporary[7u] = static_cast<NativeDouble>(static_cast<std::int32_t>(read_global_direct<std::uint32_t>(global_bytes, 0x100d635cu)));
                update_float_condition(floating.temporary[7u], native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000078u)));
                flow.value_a = (flow.value_a & 0xffff0000u) | ((floating.comparison_status) & 0xffffu);
                if (((((((flow.value_a >> 8u) & 0xffu)) & (0x00000041u)) & 0xffu) != 0u)) {
                    goto FlowStep26;
                }
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c610u));
                write_global_direct<std::uint32_t>(global_bytes, 0x100d5f58u, static_cast<std::uint32_t>(0x00000001u));
                goto FlowStep27;
            }
        FlowStep26: {
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1010ecf0u));
                goto FlowStep27;
            }
        FlowStep27: {
                floating.temporary[6u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c000u));
                floating.temporary[6u] = floating.temporary[6u] - floating.temporary[7u];
                floating.temporary[6u] = floating.temporary[6u] * native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000070u));
                floating.temporary[5u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1010ed10u));
                floating.temporary[5u] = floating.temporary[5u] * floating.temporary[7u];
                floating.temporary[6u] = floating.temporary[6u] + floating.temporary[5u];
                write_global_direct<std::uint64_t>(global_bytes, 0x1010ed10u, native_double_to_binary64_bits(floating.temporary[6u]));
                floating.temporary[7u] = floating.temporary[7u];
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1010ed10u));
                update_float_condition(floating.temporary[7u], native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6350u)));
                flow.value_a = (flow.value_a & 0xffff0000u) | ((floating.comparison_status) & 0xffffu);
                if (((((((flow.value_a >> 8u) & 0xffu)) & (0x00000001u)) & 0xffu) == 0u)) {
                    goto FlowStep28;
                }
                flow.value_a = read_global_direct<std::uint32_t>(global_bytes, 0x100d6350u);
                flow.value_c = read_global_direct<std::uint32_t>(global_bytes, 0x100d6354u);
                write_global_direct<std::uint32_t>(global_bytes, 0x1010ed10u, static_cast<std::uint32_t>(flow.value_a));
                write_global_direct<std::uint32_t>(global_bytes, 0x1010ed14u, static_cast<std::uint32_t>(flow.value_c));
                goto FlowStep28;
            }
        FlowStep28: {
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c600u));
                floating.temporary[7u] = floating.temporary[7u] / native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1010ed10u));
                flow.value_d = read_global_direct<std::uint32_t>(global_bytes, 0x101060f4u);
                flow.value_a = flow.frame_cursor + 0x00000070u;
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.value_d);
                flow.value_c = flow.frame_cursor + 0x0000006cu;
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.value_a);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.value_c);
                write_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x0000007cu, native_double_to_binary64_bits(floating.temporary[7u]));
                flow.frame_cursor -= 4u; fast_100095c0(); flow.frame_cursor += 4u;
                floating.temporary[7u] = native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000074u));
                floating.temporary[7u] = floating.temporary[7u] * native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000064u));
                flow.value_c = read_global_direct<std::uint32_t>(global_bytes, 0x100d688cu);
                flow.value_d = flow.frame_cursor + 0x00000054u;
                flow.value_a = flow.frame_cursor + 0x0000004cu;
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.value_d);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.value_a);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.value_c);
                write_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000070u, native_double_to_binary64_bits(floating.temporary[7u]));
                floating.temporary[7u] = native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000080u));
                floating.temporary[7u] = floating.temporary[7u] * native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000078u));
                write_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000078u, native_double_to_binary64_bits(floating.temporary[7u]));
                floating.temporary[7u] = native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000088u));
                floating.temporary[7u] = floating.temporary[7u] * native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000058u));
                write_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000058u, native_double_to_binary64_bits(floating.temporary[7u]));
                floating.temporary[7u] = native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000088u));
                floating.temporary[7u] = floating.temporary[7u] * native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000060u));
                write_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000060u, native_double_to_binary64_bits(floating.temporary[7u]));
                flow.frame_cursor -= 4u; fast_10009070(); flow.frame_cursor += 4u;
                flow.value_d = flow.frame_cursor + 0x00000060u;
                flow.value_a = flow.frame_cursor + 0x00000058u;
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.value_d);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.value_a);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x100d5fd8u);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x1000d760u);
                fast_one_pole_stereo(0x1000d760u, 0x100d5fd8u, flow.value_a, flow.value_d);
                flow.value_c = flow.frame_cursor + 0x00000088u;
                flow.value_d = flow.frame_cursor + 0x00000080u;
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.value_c);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.value_d);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x100d6018u);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x1000d748u);
                fast_one_pole_stereo(0x1000d748u, 0x100d6018u, flow.value_d, flow.value_c);
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1010ece0u));
                floating.temporary[7u] = floating.temporary[7u] * native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000078u));
                flow.value_a = read_global_direct<std::uint32_t>(global_bytes, 0x1010609cu);
                { const std::uint32_t lhs = flow.frame_cursor; const std::uint32_t rhs = 0x00000038u; const std::uint32_t result = lhs + rhs; flow.frame_cursor = result; update_add_condition( lhs, rhs, result, 32u); }
                { const std::uint32_t lhs = flow.value_a; const std::uint32_t rhs = flow.value_b; update_sub_condition(lhs, rhs, lhs - rhs, 32u); }
                write_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000040u, native_double_to_binary64_bits(floating.temporary[7u]));
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1010ece0u));
                floating.temporary[7u] = floating.temporary[7u] * native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000048u));
                write_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000048u, native_double_to_binary64_bits(floating.temporary[7u]));
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1010ed28u));
                floating.temporary[7u] = floating.temporary[7u] * native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000058u));
                write_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000058u, native_double_to_binary64_bits(floating.temporary[7u]));
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1010ed28u));
                floating.temporary[7u] = floating.temporary[7u] * native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000060u));
                write_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000060u, native_double_to_binary64_bits(floating.temporary[7u]));
                if (!flow.condition.zero) {
                    goto FlowStep34;
                }
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6170u));
                floating.temporary[7u] = floating.temporary[7u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c5f0u));
                { const std::uint32_t lhs = read_global_direct<std::uint32_t>(global_bytes, 0x1010607cu); const std::uint32_t rhs = flow.value_b; update_sub_condition(lhs, rhs, lhs - rhs, 32u); }
                write_global_direct<std::uint64_t>(global_bytes, 0x100d6170u, native_double_to_binary64_bits(floating.temporary[7u]));
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6168u));
                floating.temporary[7u] = floating.temporary[7u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c5f0u));
                if (flow.condition.zero) {
                    goto FlowStep29;
                }
                floating.temporary[7u] = floating.temporary[7u];
                floating.temporary[7u] = native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000040u));
                floating.temporary[7u] = floating.temporary[7u] - native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000058u));
                floating.temporary[6u] = native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000048u));
                floating.temporary[6u] = floating.temporary[6u] - native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000060u));
                goto FlowStep30;
            }
        FlowStep29: {
                floating.temporary[6u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6170u));
                goto FlowStep30;
            }
        FlowStep30: {
                #if defined(SSNATIVE_M13_NATIVE_STATE_OUTPUT)
                fast_m13_state_output(floating.temporary[6u], floating.temporary[7u]); goto FlowStep31;
                #else
                floating.temporary[5u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6110u));
                floating.temporary[5u] = floating.temporary[5u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1004af78u));
                flow.value_c = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x0000006cu);
                flow.value_d = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000070u);
                write_global_direct<std::uint32_t>(global_bytes, 0x100d6854u, static_cast<std::uint32_t>(flow.value_c));
                flow.value_c = read_global_direct<std::uint32_t>(global_bytes, 0x100d6110u);
                floating.temporary[6u] = floating.temporary[6u] - floating.temporary[5u];
                floating.temporary[5u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6118u));
                floating.temporary[5u] = floating.temporary[5u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1004af80u));
                write_global_direct<std::uint32_t>(global_bytes, 0x100d6858u, static_cast<std::uint32_t>(flow.value_d));
                flow.value_d = read_global_direct<std::uint32_t>(global_bytes, 0x100d6114u);
                flow.value_a = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000068u);
                floating.temporary[6u] = floating.temporary[6u] - floating.temporary[5u];
                write_global_direct<std::uint32_t>(global_bytes, 0x100d6850u, static_cast<std::uint32_t>(flow.value_a));
                flow.value_a = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000074u);
                write_global_direct<std::uint32_t>(global_bytes, 0x100d685cu, static_cast<std::uint32_t>(flow.value_a));
                flow.value_a = read_global_direct<std::uint32_t>(global_bytes, 0x100d6128u);
                write_global_direct<std::uint64_t>(global_bytes, 0x100d6108u, native_double_to_binary64_bits(floating.temporary[6u]));
                floating.temporary[5u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1004af90u));
                floating.temporary[5u] = floating.temporary[5u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6118u));
                floating.temporary[4u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1004af88u));
                floating.temporary[4u] = floating.temporary[4u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6110u));
                write_global_direct<std::uint32_t>(global_bytes, 0x100d6118u, static_cast<std::uint32_t>(flow.value_c));
                flow.value_c = read_global_direct<std::uint32_t>(global_bytes, 0x100d612cu);
                floating.temporary[5u] = floating.temporary[5u] + floating.temporary[4u];
                write_global_direct<std::uint32_t>(global_bytes, 0x100d611cu, static_cast<std::uint32_t>(flow.value_d));
                floating.temporary[5u] = floating.temporary[5u] + floating.temporary[6u];
                write_global_direct<std::uint64_t>(global_bytes, 0x100d6170u, native_double_to_binary64_bits(floating.temporary[5u]));
                write_global_direct<std::uint64_t>(global_bytes, 0x100d6110u, native_double_to_binary64_bits(floating.temporary[6u]));
                floating.temporary[6u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6128u));
                floating.temporary[6u] = floating.temporary[6u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1004af78u));
                floating.temporary[7u] = floating.temporary[7u] - floating.temporary[6u];
                floating.temporary[6u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6130u));
                floating.temporary[6u] = floating.temporary[6u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1004af80u));
                floating.temporary[7u] = floating.temporary[7u] - floating.temporary[6u];
                write_global_direct<std::uint64_t>(global_bytes, 0x100d6120u, native_double_to_binary64_bits(floating.temporary[7u]));
                floating.temporary[6u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6130u));
                floating.temporary[6u] = floating.temporary[6u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1004af90u));
                floating.temporary[5u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6128u));
                floating.temporary[5u] = floating.temporary[5u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1004af88u));
                write_global_direct<std::uint32_t>(global_bytes, 0x100d6130u, static_cast<std::uint32_t>(flow.value_a));
                flow.value_a = read_global_direct<std::uint32_t>(global_bytes, 0x10106090u);
                floating.temporary[6u] = floating.temporary[6u] + floating.temporary[5u];
                { const std::uint32_t lhs = flow.value_a; const std::uint32_t rhs = flow.value_b; update_sub_condition(lhs, rhs, lhs - rhs, 32u); }
                write_global_direct<std::uint32_t>(global_bytes, 0x100d6134u, static_cast<std::uint32_t>(flow.value_c));
                floating.temporary[6u] = floating.temporary[6u] + floating.temporary[7u];
                write_global_direct<std::uint64_t>(global_bytes, 0x100d6168u, native_double_to_binary64_bits(floating.temporary[6u]));
                write_global_direct<std::uint64_t>(global_bytes, 0x100d6128u, native_double_to_binary64_bits(floating.temporary[7u])); goto FlowStep31;
                #endif
                goto FlowStep31;
            }
        FlowStep31: {
                if ((flow.condition.zero || flow.condition.negative != flow.condition.overflow)) {
                    goto FlowStep33;
                }
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x00000002u);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x100d6170u);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x100d6168u);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x100d7660u);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x100d76a0u);
                fast_biquad_stereo(0x100d76a0u, 0x100d7660u, 0x100d6168u, 0x100d6170u);
                flow.value_a = (flow.value_a & 0xffffff00u) | ((read_global_direct<std::uint32_t>(global_bytes, 0x101060f0u)) & 0xffu);
                { const std::uint32_t lhs = flow.frame_cursor; const std::uint32_t rhs = 0x00000014u; const std::uint32_t result = lhs + rhs; flow.frame_cursor = result; update_add_condition( lhs, rhs, result, 32u); }
                if ((((((flow.value_a & 0xffu)) & (0x00000040u)) & 0xffu) == 0u)) {
                    goto FlowStep33;
                }
                flow.index = 0x1000d5b8u;
                goto FlowStep32;
            }
        FlowStep32: {
                flow.value_d = read_u32(flow.index);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x00000002u);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x100d6170u);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x100d6168u);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.value_d);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x100d76a0u);
                fast_biquad_stereo(0x100d76a0u, flow.value_d, 0x100d6168u, 0x100d6170u);
                { const std::uint32_t lhs = flow.index; const std::uint32_t rhs = 0x00000004u; const std::uint32_t result = lhs + rhs; flow.index = result; update_add_condition( lhs, rhs, result, 32u); }
                { const std::uint32_t lhs = flow.frame_cursor; const std::uint32_t rhs = 0x00000014u; const std::uint32_t result = lhs + rhs; flow.frame_cursor = result; update_add_condition( lhs, rhs, result, 32u); }
                if ((static_cast<std::int32_t>(flow.index) < static_cast<std::int32_t>(0x1000d5c4u))) {
                    goto FlowStep32;
                }
                goto FlowStep33;
            }
        FlowStep33: {
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d63b0u));
                floating.temporary[7u] = floating.temporary[7u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6170u));
                flow.value_a = read_global_direct<std::uint32_t>(global_bytes, 0x1010609cu);
                write_global_direct<std::uint64_t>(global_bytes, 0x100d6170u, native_double_to_binary64_bits(floating.temporary[7u]));
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d63b0u));
                floating.temporary[7u] = floating.temporary[7u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6168u));
                write_global_direct<std::uint64_t>(global_bytes, 0x100d6168u, native_double_to_binary64_bits(floating.temporary[7u]));
                goto FlowStep35;
            }
        FlowStep34: {
                write_global_direct<std::uint32_t>(global_bytes, 0x100d6850u, static_cast<std::uint32_t>(0x00000000u));
                write_global_direct<std::uint32_t>(global_bytes, 0x100d6854u, static_cast<std::uint32_t>(0x00000000u));
                write_global_direct<std::uint32_t>(global_bytes, 0x100d6858u, static_cast<std::uint32_t>(0x00000000u));
                write_global_direct<std::uint32_t>(global_bytes, 0x100d685cu, static_cast<std::uint32_t>(0x00000000u));
                goto FlowStep35;
            }
        FlowStep35: {
                if ((((flow.value_a) & 0xffffffffu) != ((flow.value_b) & 0xffffffffu))) {
                    goto FlowStep38;
                }
                flow.value_c = read_global_direct<std::uint32_t>(global_bytes, 0x101060b8u);
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d60d0u));
                if ((((flow.value_c) & 0xffffffffu) == ((flow.value_b) & 0xffffffffu))) {
                    goto FlowStep36;
                }
                floating.temporary[7u] = floating.temporary[7u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c5e0u));
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6170u)) - floating.temporary[7u];
                write_global_direct<std::uint64_t>(global_bytes, 0x100d60c8u, native_double_to_binary64_bits(floating.temporary[7u]));
                floating.temporary[6u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d60d0u));
                floating.temporary[6u] = floating.temporary[6u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c5d0u));
                floating.temporary[5u] = floating.temporary[7u];
                floating.temporary[5u] = floating.temporary[5u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c5c0u));
                floating.temporary[6u] = floating.temporary[6u] + floating.temporary[5u];
                write_global_direct<std::uint64_t>(global_bytes, 0x100d6170u, native_double_to_binary64_bits(floating.temporary[6u]));
                write_global_direct<std::uint64_t>(global_bytes, 0x100d60d0u, native_double_to_binary64_bits(floating.temporary[7u]));
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d60e0u));
                floating.temporary[7u] = floating.temporary[7u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c5e0u));
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6168u)) - floating.temporary[7u];
                write_global_direct<std::uint64_t>(global_bytes, 0x100d60d8u, native_double_to_binary64_bits(floating.temporary[7u]));
                floating.temporary[6u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d60e0u));
                floating.temporary[6u] = floating.temporary[6u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c5d0u));
                floating.temporary[5u] = floating.temporary[7u];
                floating.temporary[5u] = floating.temporary[5u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c5c0u));
                goto FlowStep37;
            }
        FlowStep36: {
                floating.temporary[7u] = floating.temporary[7u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c5b0u));
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6170u)) - floating.temporary[7u];
                write_global_direct<std::uint64_t>(global_bytes, 0x100d60c8u, native_double_to_binary64_bits(floating.temporary[7u]));
                floating.temporary[6u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d60d0u));
                floating.temporary[6u] = floating.temporary[6u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c5a0u));
                floating.temporary[5u] = floating.temporary[7u];
                floating.temporary[5u] = floating.temporary[5u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c590u));
                floating.temporary[6u] = floating.temporary[6u] + floating.temporary[5u];
                write_global_direct<std::uint64_t>(global_bytes, 0x100d6170u, native_double_to_binary64_bits(floating.temporary[6u]));
                write_global_direct<std::uint64_t>(global_bytes, 0x100d60d0u, native_double_to_binary64_bits(floating.temporary[7u]));
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d60e0u));
                floating.temporary[7u] = floating.temporary[7u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c5b0u));
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6168u)) - floating.temporary[7u];
                write_global_direct<std::uint64_t>(global_bytes, 0x100d60d8u, native_double_to_binary64_bits(floating.temporary[7u]));
                floating.temporary[6u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d60e0u));
                floating.temporary[6u] = floating.temporary[6u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c5a0u));
                floating.temporary[5u] = floating.temporary[7u];
                floating.temporary[5u] = floating.temporary[5u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c590u));
                goto FlowStep37;
            }
        FlowStep37: {
                floating.temporary[6u] = floating.temporary[6u] + floating.temporary[5u];
                write_global_direct<std::uint64_t>(global_bytes, 0x100d6168u, native_double_to_binary64_bits(floating.temporary[6u]));
                write_global_direct<std::uint64_t>(global_bytes, 0x100d60e0u, native_double_to_binary64_bits(floating.temporary[7u]));
                goto FlowStep38;
            }
        FlowStep38: {
                flow.value_c = read_global_direct<std::uint32_t>(global_bytes, 0x101060f0u);
                if (((((((flow.value_c >> 8u) & 0xffu)) & (0x00000002u)) & 0xffu) == 0u)) {
                    goto FlowStep39;
                }
                if ((((flow.value_a) & 0xffffffffu) == ((flow.value_b) & 0xffffffffu))) {
                    goto FlowStep45;
                }
                goto FlowStep39;
            }
        FlowStep39: {
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6168u));
                floating.temporary[7u] = floating.temporary[7u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c580u));
                write_global_direct<std::uint64_t>(global_bytes, 0x100d6a68u, native_double_to_binary64_bits(floating.temporary[7u]));
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6170u));
                floating.temporary[7u] = floating.temporary[7u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c580u));
                write_global_direct<std::uint64_t>(global_bytes, 0x100d6a60u, native_double_to_binary64_bits(floating.temporary[7u]));
                flow.frame_cursor -= 4u; fast_10007fe0(); flow.frame_cursor += 4u;
                fast_level_detector((read_global_direct<std::uint8_t>(global_bytes, 0x101060f0u) & 8u) != 0u);
                goto FlowStep44;
                if (((((read_global_direct<std::uint8_t>(global_bytes, 0x101060f0u)) & (0x00000008u)) & 0xffu) == 0u)) {
                    goto FlowStep41;
                }
                { const std::uint32_t lhs = flow.index; const std::uint32_t rhs = flow.index; const std::uint32_t result = lhs ^ rhs; flow.index = result; update_logic_condition( result, 32u); }
                flow.pointer = 0x100d6368u;
                goto FlowStep40;
            }
        FlowStep40: {
                floating.temporary[7u] = native_double_from_binary64_bits(read_u64(flow.pointer + static_cast<std::uint32_t>(-8)));
                floating.temporary[7u] = native_double_abs(floating.temporary[7u]);
                write_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000080u, native_double_to_binary64_bits(floating.temporary[7u]));
                floating.temporary[7u] = native_double_from_binary64_bits(read_u64(flow.pointer));
                floating.temporary[7u] = native_double_abs(floating.temporary[7u]);
                write_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000018u, native_double_to_binary64_bits(floating.temporary[7u]));
                flow.value_c = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x0000001cu);
                flow.value_d = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000018u);
                flow.value_a = (flow.index * 8u) + 0x100d5f28u;
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.index);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.value_a);
                flow.value_a = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x0000008cu);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.value_c);
                flow.value_c = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x0000008cu);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.value_d);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.value_a);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.value_c);
                floating.temporary[7u] = fast_rms_envelope(
                    guest_f64(flow.frame_cursor), guest_f64(flow.frame_cursor + 8u),
                    read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 16u), read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 20u));

                { const std::uint32_t lhs = flow.frame_cursor; const std::uint32_t rhs = 0x00000018u; const std::uint32_t result = lhs + rhs; flow.frame_cursor = result; update_add_condition( lhs, rhs, result, 32u); }
                write_u64((flow.index * 8u) + 0x100d5ec8u, native_double_to_binary64_bits(floating.temporary[7u]));
                { const std::uint32_t lhs = flow.pointer; const std::uint32_t rhs = 0x00000010u; const std::uint32_t result = lhs + rhs; flow.pointer = result; update_add_condition( lhs, rhs, result, 32u); }
                { const std::uint32_t old_value = flow.index; const std::uint32_t result = old_value + 1u; flow.index = result; const bool carry = flow.condition.carry; update_add_condition(old_value, 1u, result, 32u); flow.condition.carry = carry; }
                if ((static_cast<std::int32_t>(flow.pointer) < static_cast<std::int32_t>(0x100d63b8u))) {
                    goto FlowStep40;
                }
                goto FlowStep44;
            }
        FlowStep41: {
                flow.value_d = 0x100d5ec8u;
                flow.value_c = 0x100d6368u;
                goto FlowStep42;
            }
        FlowStep42: {
                floating.temporary[7u] = native_double_from_binary64_bits(read_u64(flow.value_c + static_cast<std::uint32_t>(-8)));
                floating.temporary[7u] = native_double_abs(floating.temporary[7u]);
                floating.temporary[6u] = native_double_from_binary64_bits(read_u64(flow.value_c));
                floating.temporary[6u] = native_double_abs(floating.temporary[6u]);
                write_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000018u, native_double_to_binary64_bits(floating.temporary[6u]));
                update_float_condition(floating.temporary[7u], native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000018u)));
                flow.value_a = (flow.value_a & 0xffff0000u) | ((floating.comparison_status) & 0xffffu);
                if (((((((flow.value_a >> 8u) & 0xffu)) & (0x00000041u)) & 0xffu) == 0u)) {
                    goto FlowStep43;
                }
                floating.temporary[7u] = floating.temporary[7u];
                floating.temporary[7u] = native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000018u));
                goto FlowStep43;
            }
        FlowStep43: {
                write_u64(flow.value_d, native_double_to_binary64_bits(floating.temporary[7u]));
                { const std::uint32_t lhs = flow.value_c; const std::uint32_t rhs = 0x00000010u; const std::uint32_t result = lhs + rhs; flow.value_c = result; update_add_condition( lhs, rhs, result, 32u); }
                { const std::uint32_t lhs = flow.value_d; const std::uint32_t rhs = 0x00000008u; const std::uint32_t result = lhs + rhs; flow.value_d = result; update_add_condition( lhs, rhs, result, 32u); }
                if ((static_cast<std::int32_t>(flow.value_c) < static_cast<std::int32_t>(0x100d63b8u))) {
                    goto FlowStep42;
                }
                goto FlowStep44;
            }
        FlowStep44: {
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x00000004u);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.value_b);
                fast_dynamics_range(flow.value_b, 4u);
                flow.value_d = read_global_direct<std::uint32_t>(global_bytes, 0x10106088u);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.value_d);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x1000ed80u);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x1000ed88u);
                fast_smooth_min(0x1000ed88u, 0x1000ed80u, static_cast<std::int32_t>(flow.value_d));
                flow.value_a = read_global_direct<std::uint32_t>(global_bytes, 0x101060ecu);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.value_a);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x1000ed90u);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x1000ed88u);
                fast_smooth_min(0x1000ed88u, 0x1000ed90u, static_cast<std::int32_t>(flow.value_a));
                flow.value_c = read_global_direct<std::uint32_t>(global_bytes, 0x101060e8u);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.value_c);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x1000ed98u);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x1000ed90u);
                fast_smooth_min(0x1000ed90u, 0x1000ed98u, static_cast<std::int32_t>(flow.value_c));
                flow.value_d = read_global_direct<std::uint32_t>(global_bytes, 0x101060e4u);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.value_d);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x1000eda0u);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x1000ed98u);
                fast_smooth_min(0x1000ed98u, 0x1000eda0u, static_cast<std::int32_t>(flow.value_d));
                flow.value_a = read_global_direct<std::uint32_t>(global_bytes, 0x1010609cu);
                { const std::uint32_t lhs = flow.frame_cursor; const std::uint32_t rhs = 0x00000038u; const std::uint32_t result = lhs + rhs; flow.frame_cursor = result; update_add_condition( lhs, rhs, result, 32u); }
                if ((((flow.value_a) & 0xffffffffu) != ((flow.value_b) & 0xffffffffu))) {
                    goto FlowStep64;
                }
                fast_band_delay_mix();
                #if defined(SSNATIVE_M13_NATIVE_BAND_POST)
                fast_m13_band_post(); goto FlowStep48;
                #else
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6800u));
                floating.temporary[7u] = floating.temporary[7u] - native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6810u));
                floating.temporary[7u] = floating.temporary[7u] + native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6820u));
                floating.temporary[7u] = floating.temporary[7u] - native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6830u));
                floating.temporary[7u] = floating.temporary[7u] + native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6840u));
                floating.temporary[6u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6808u));
                floating.temporary[6u] = floating.temporary[6u] - native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6818u));
                floating.temporary[6u] = floating.temporary[6u] + native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6828u));
                floating.temporary[6u] = floating.temporary[6u] - native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6838u));
                floating.temporary[6u] = floating.temporary[6u] + native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6848u));
                write_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000080u, native_double_to_binary64_bits(floating.temporary[6u]));
                flow.value_d = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000080u);
                flow.value_a = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000084u);
                write_global_direct<std::uint64_t>(global_bytes, 0x100d6170u, native_double_to_binary64_bits(floating.temporary[7u]));
                flow.pointer = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000010u);
                write_global_direct<std::uint32_t>(global_bytes, 0x100d6168u, static_cast<std::uint32_t>(flow.value_d));
                write_global_direct<std::uint32_t>(global_bytes, 0x100d616cu, static_cast<std::uint32_t>(flow.value_a));
                { const std::uint32_t lhs = flow.value_b; const std::uint32_t rhs = flow.value_b; const std::uint32_t result = lhs ^ rhs; flow.value_b = result; update_logic_condition( result, 32u); } goto FlowStep45;
                #endif
                goto FlowStep45;
            }
        FlowStep45: {
                flow.value_c = read_global_direct<std::uint32_t>(global_bytes, 0x100d6168u);
                flow.value_a = read_global_direct<std::uint32_t>(global_bytes, 0x100d6170u);
                flow.value_d = read_global_direct<std::uint32_t>(global_bytes, 0x100d616cu);
                write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000028u, static_cast<std::uint32_t>(flow.value_c));
                flow.value_c = read_global_direct<std::uint32_t>(global_bytes, 0x100d6174u);
                write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000038u, static_cast<std::uint32_t>(flow.value_a));
                flow.value_a = read_global_direct<std::uint32_t>(global_bytes, 0x100d616cu);
                write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x0000003cu, static_cast<std::uint32_t>(flow.value_c));
                flow.value_c = read_global_direct<std::uint32_t>(global_bytes, 0x100d6170u);
                write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000024u, static_cast<std::uint32_t>(flow.value_a));
                write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x0000002cu, static_cast<std::uint32_t>(flow.value_d));
                flow.value_d = read_global_direct<std::uint32_t>(global_bytes, 0x100d6168u);
                write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000030u, static_cast<std::uint32_t>(flow.value_c));
                flow.value_a = flow.frame_cursor + 0x00000028u;
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x00000002u);
                flow.value_c = flow.frame_cursor + 0x0000003cu;
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.value_a);
                write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000028u, static_cast<std::uint32_t>(flow.value_d));
                flow.value_d = read_global_direct<std::uint32_t>(global_bytes, 0x100d6174u);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.value_c);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x100d7840u);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x1000d590u);
                write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000048u, static_cast<std::uint32_t>(flow.value_d));
                flow.frame_cursor -= 4u; fast_10008ac0(); flow.frame_cursor += 4u;
                flow.value_d = flow.frame_cursor + 0x00000034u;
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x00000002u);
                flow.value_a = flow.frame_cursor + 0x00000048u;
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.value_d);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.value_a);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x100d7880u);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x1000d568u);
                fast_biquad_stereo(0x1000d568u, 0x100d7880u, flow.value_a, flow.value_d);
                floating.temporary[7u] = native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000060u));
                floating.temporary[7u] = floating.temporary[7u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d67e8u));
                { const std::uint32_t lhs = flow.frame_cursor; const std::uint32_t rhs = 0x00000028u; const std::uint32_t result = lhs + rhs; flow.frame_cursor = result; update_add_condition( lhs, rhs, result, 32u); }
                write_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000038u, native_double_to_binary64_bits(floating.temporary[7u]));
                floating.temporary[7u] = native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000028u));
                floating.temporary[7u] = floating.temporary[7u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d67e8u));
                write_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000028u, native_double_to_binary64_bits(floating.temporary[7u]));
                floating.temporary[7u] = native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000030u));
                floating.temporary[7u] = floating.temporary[7u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d67e8u));
                write_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000030u, native_double_to_binary64_bits(floating.temporary[7u]));
                floating.temporary[7u] = native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000020u));
                floating.temporary[7u] = floating.temporary[7u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d67e8u));
                write_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000020u, native_double_to_binary64_bits(floating.temporary[7u]));
                floating.temporary[7u] = native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000038u));
                floating.temporary[7u] = native_double_abs(floating.temporary[7u]);
                write_global_direct<std::uint64_t>(global_bytes, 0x100d5ef0u, native_double_to_binary64_bits(floating.temporary[7u]));
                floating.temporary[7u] = native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000028u));
                floating.temporary[7u] = native_double_abs(floating.temporary[7u]);
                floating.temporary[6u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d5ef0u));
                update_float_condition(floating.temporary[6u], floating.temporary[7u]);
                flow.value_a = (flow.value_a & 0xffff0000u) | ((floating.comparison_status) & 0xffffu);
                if (((((((flow.value_a >> 8u) & 0xffu)) & (0x00000041u)) & 0xffu) != 0u)) {
                    goto FlowStep46;
                }
                floating.temporary[7u] = floating.temporary[7u];
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d5ef0u));
                goto FlowStep46;
            }
        FlowStep46: {
                write_global_direct<std::uint64_t>(global_bytes, 0x100d5ef0u, native_double_to_binary64_bits(floating.temporary[7u]));
                floating.temporary[7u] = native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000030u));
                floating.temporary[7u] = native_double_abs(floating.temporary[7u]);
                write_global_direct<std::uint64_t>(global_bytes, 0x100d5ef8u, native_double_to_binary64_bits(floating.temporary[7u]));
                floating.temporary[7u] = native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000020u));
                floating.temporary[7u] = native_double_abs(floating.temporary[7u]);
                floating.temporary[6u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d5ef8u));
                update_float_condition(floating.temporary[6u], floating.temporary[7u]);
                flow.value_a = (flow.value_a & 0xffff0000u) | ((floating.comparison_status) & 0xffffu);
                if (((((((flow.value_a >> 8u) & 0xffu)) & (0x00000041u)) & 0xffu) != 0u)) {
                    goto FlowStep47;
                }
                floating.temporary[7u] = floating.temporary[7u];
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d5ef8u));
                goto FlowStep47;
            }
        FlowStep47: {
                write_global_direct<std::uint64_t>(global_bytes, 0x100d5ef8u, native_double_to_binary64_bits(floating.temporary[7u]));
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x00000006u);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x00000005u);
                fast_dynamics_range(5u, 6u);
                { const std::uint32_t lhs = flow.frame_cursor; const std::uint32_t rhs = 0x00000008u; const std::uint32_t result = lhs + rhs; flow.frame_cursor = result; update_add_condition( lhs, rhs, result, 32u); }
                goto FlowStep48;
            }
        FlowStep48: {
                #if defined(SSNATIVE_M13_NATIVE_DELAY_OUTPUT)
                fast_m13_delay_output(); goto FlowStep51;
                #else
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000edb0u));
                floating.temporary[7u] = floating.temporary[7u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c570u));
                floating.temporary[6u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1004af00u));
                floating.temporary[6u] = floating.temporary[6u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c560u));
                floating.temporary[7u] = floating.temporary[7u] + floating.temporary[6u];
                write_global_direct<std::uint64_t>(global_bytes, 0x1004af00u, native_double_to_binary64_bits(floating.temporary[7u]));
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000eda8u));
                floating.temporary[7u] = floating.temporary[7u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c570u));
                floating.temporary[6u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1004aef8u));
                floating.temporary[6u] = floating.temporary[6u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c560u));
                flow.value_c = read_global_direct<std::uint32_t>(global_bytes, 0x100d5f20u);
                flow.value_d = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000034u);
                flow.value_a = (flow.value_c * 8u);
                floating.temporary[7u] = floating.temporary[7u] + floating.temporary[6u];
                { const std::uint32_t lhs = flow.value_a; const std::uint32_t rhs = flow.value_c; const std::uint32_t result = lhs - rhs; flow.value_a = result; update_sub_condition( lhs, rhs, result, 32u); }
                flow.value_c = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000030u);
                { const unsigned count = (0x00000004u) & 31u; if (count != 0u) { const std::uint32_t old_value = flow.value_a; const std::uint32_t result = old_value << count; flow.value_a = result; update_logic_condition(result, 32u); } }
                write_global_direct<std::uint64_t>(global_bytes, 0x1004aef8u, native_double_to_binary64_bits(floating.temporary[7u]));
                floating.temporary[7u] = native_double_from_binary64_bits(read_u64(flow.value_a + 0x1004d318u));
                floating.temporary[7u] = floating.temporary[7u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1004af00u));
                write_u32(flow.value_a + 0x1004d318u, static_cast<std::uint32_t>(flow.value_c));
                write_u32(flow.value_a + 0x1004d31cu, static_cast<std::uint32_t>(flow.value_d));
                floating.temporary[6u] = native_double_from_binary64_bits(read_u64(flow.value_a + 0x1004d310u));
                floating.temporary[5u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1004aef8u));
                flow.value_c = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000038u);
                flow.value_d = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x0000003cu);
                floating.temporary[5u] = floating.temporary[5u] * floating.temporary[6u];
                write_u32(flow.value_a + 0x1004d310u, static_cast<std::uint32_t>(flow.value_c));
                write_u32(flow.value_a + 0x1004d314u, static_cast<std::uint32_t>(flow.value_d));
                flow.value_c = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000020u);
                flow.value_d = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000024u);
                floating.temporary[7u] = floating.temporary[7u] - floating.temporary[5u];
                floating.temporary[6u] = floating.temporary[6u];
                floating.temporary[6u] = native_double_from_binary64_bits(read_u64(flow.value_a + 0x1004d350u));
                floating.temporary[5u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1004af00u));
                floating.temporary[5u] = floating.temporary[5u] * floating.temporary[6u];
                write_u32(flow.value_a + 0x1004d350u, static_cast<std::uint32_t>(flow.value_c));
                write_u32(flow.value_a + 0x1004d354u, static_cast<std::uint32_t>(flow.value_d));
                flow.value_c = read_u32(flow.value_a + 0x1004d348u);
                flow.value_d = read_u32(flow.value_a + 0x1004d34cu);
                write_global_direct<std::uint64_t>(global_bytes, 0x100d6168u, native_double_to_binary64_bits(floating.temporary[5u]));
                write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000050u, static_cast<std::uint32_t>(flow.value_c));
                write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000054u, static_cast<std::uint32_t>(flow.value_d));
                floating.temporary[6u] = floating.temporary[6u];
                floating.temporary[6u] = static_cast<NativeDouble>(static_cast<std::int32_t>(read_global_direct<std::uint32_t>(global_bytes, 0x101060f8u)));
                flow.value_c = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000028u);
                flow.value_d = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x0000002cu);
                write_u32(flow.value_a + 0x1004d348u, static_cast<std::uint32_t>(flow.value_c));
                write_u32(flow.value_a + 0x1004d34cu, static_cast<std::uint32_t>(flow.value_d));
                write_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000080u, native_double_to_binary64_bits(floating.temporary[6u]));
                floating.temporary[6u] = floating.temporary[6u] * floating.temporary[7u];
                floating.temporary[6u] = floating.temporary[6u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c4e0u));
                write_global_direct<std::uint64_t>(global_bytes, 0x100d6170u, native_double_to_binary64_bits(floating.temporary[6u]));
                flow.value_d = read_global_direct<std::uint32_t>(global_bytes, 0x100d6170u);
                floating.temporary[7u] = floating.temporary[7u];
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1004aef8u));
                floating.temporary[7u] = floating.temporary[7u] * native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000050u));
                write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000038u, static_cast<std::uint32_t>(flow.value_d));
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6168u)) - floating.temporary[7u];
                floating.temporary[7u] = floating.temporary[7u] * native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000080u));
                floating.temporary[7u] = floating.temporary[7u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c4e0u));
                write_global_direct<std::uint64_t>(global_bytes, 0x100d6168u, native_double_to_binary64_bits(floating.temporary[7u]));
                flow.value_a = read_global_direct<std::uint32_t>(global_bytes, 0x100d6168u);
                flow.value_c = read_global_direct<std::uint32_t>(global_bytes, 0x100d616cu);
                write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000028u, static_cast<std::uint32_t>(flow.value_a));
                flow.value_a = read_global_direct<std::uint32_t>(global_bytes, 0x100d6174u);
                write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x0000002cu, static_cast<std::uint32_t>(flow.value_c));
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6170u));
                floating.temporary[7u] = native_double_abs(floating.temporary[7u]);
                floating.temporary[6u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6168u));
                flow.value_c = read_global_direct<std::uint32_t>(global_bytes, 0x100d6168u);
                flow.value_d = read_global_direct<std::uint32_t>(global_bytes, 0x100d616cu);
                floating.temporary[6u] = native_double_abs(floating.temporary[6u]);
                write_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000018u, native_double_to_binary64_bits(floating.temporary[6u]));
                update_float_condition(floating.temporary[7u], native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000018u)));
                write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x0000003cu, static_cast<std::uint32_t>(flow.value_a));
                flow.value_a = read_global_direct<std::uint32_t>(global_bytes, 0x100d6170u);
                write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000030u, static_cast<std::uint32_t>(flow.value_a));
                write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000020u, static_cast<std::uint32_t>(flow.value_c));
                flow.value_c = read_global_direct<std::uint32_t>(global_bytes, 0x100d6174u);
                write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000024u, static_cast<std::uint32_t>(flow.value_d));
                flow.value_a = (flow.value_a & 0xffff0000u) | ((floating.comparison_status) & 0xffffu);
                write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000034u, static_cast<std::uint32_t>(flow.value_c));
                if (((((((flow.value_a >> 8u) & 0xffu)) & (0x00000041u)) & 0xffu) == 0u)) {
                    goto FlowStep49;
                }
                floating.temporary[7u] = floating.temporary[7u];
                floating.temporary[7u] = native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000018u));
                goto FlowStep49;
            }
        FlowStep49: {
                update_float_condition(floating.temporary[7u], native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d63f0u)));
                flow.value_a = (flow.value_a & 0xffff0000u) | ((floating.comparison_status) & 0xffffu);
                if (((((((flow.value_a >> 8u) & 0xffu)) & (0x00000041u)) & 0xffu) != 0u)) {
                    goto FlowStep50;
                }
                write_global_direct<std::uint64_t>(global_bytes, 0x100d63f0u, native_double_to_binary64_bits(floating.temporary[7u]));
                goto FlowStep51;
            }
        FlowStep50: {
                floating.temporary[7u] = floating.temporary[7u]; goto FlowStep51;
                #endif
                goto FlowStep51;
            }
        FlowStep51: {
                #if defined(SSNATIVE_M13_NATIVE_POSTFILTER)
                fast_m13_postfilter(); goto FlowStep59;
                #else
                flow.value_d = flow.frame_cursor + 0x00000028u;
                flow.value_a = flow.frame_cursor + 0x00000038u;
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.value_d);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.value_a);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x100d6960u);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x1000d5c8u);
                fast_fourth_stereo(0x1000d5c8u, 0x100d6960u, flow.value_a, flow.value_d);
                flow.value_c = flow.frame_cursor + 0x00000030u;
                flow.value_d = flow.frame_cursor + 0x00000040u;
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.value_c);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.value_d);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x100d75a0u);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x1000d610u);
                fast_fourth_stereo(0x1000d610u, 0x100d75a0u, flow.value_d, flow.value_c);
                flow.value_a = read_global_direct<std::uint32_t>(global_bytes, 0x101060a4u);
                { const std::uint32_t lhs = flow.frame_cursor; const std::uint32_t rhs = 0x00000020u; const std::uint32_t result = lhs + rhs; flow.frame_cursor = result; update_add_condition( lhs, rhs, result, 32u); }
                if ((((flow.value_a) & 0xffffffffu) != ((flow.value_b) & 0xffffffffu))) {
                    goto FlowStep52;
                }
                flow.value_d = read_global_direct<std::uint32_t>(global_bytes, 0x1010f4b4u);
                flow.value_a = flow.frame_cursor + 0x00000028u;
                flow.value_c = flow.frame_cursor + 0x00000038u;
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.value_a);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.value_c);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.value_d);
                fast_soft_clip_stereo(static_cast<std::int32_t>(flow.value_d), flow.value_c, flow.value_a);
                flow.value_d = read_global_direct<std::uint32_t>(global_bytes, 0x1010f4b4u);
                flow.value_a = flow.frame_cursor + 0x0000002cu;
                flow.value_c = flow.frame_cursor + 0x0000003cu;
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.value_a);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.value_c);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.value_d);
                fast_soft_clip_stereo(static_cast<std::int32_t>(flow.value_d), flow.value_c, flow.value_a);
                { const std::uint32_t lhs = flow.frame_cursor; const std::uint32_t rhs = 0x00000018u; const std::uint32_t result = lhs + rhs; flow.frame_cursor = result; update_add_condition( lhs, rhs, result, 32u); }
                goto FlowStep52;
            }
        FlowStep52: {
                flow.value_a = flow.frame_cursor + 0x00000028u;
                flow.value_c = flow.frame_cursor + 0x00000038u;
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.value_a);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.value_c);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x100d6900u);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x1000d5c8u);
                fast_fourth_stereo(0x1000d5c8u, 0x100d6900u, flow.value_c, flow.value_a);
                flow.value_d = flow.frame_cursor + 0x00000030u;
                flow.value_a = flow.frame_cursor + 0x00000040u;
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.value_d);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.value_a);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x100d7600u);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x1000d610u);
                fast_fourth_stereo(0x1000d610u, 0x100d7600u, flow.value_a, flow.value_d);
                floating.temporary[7u] = native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000040u));
                floating.temporary[7u] = floating.temporary[7u] + native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000048u));
                { const std::uint32_t lhs = flow.frame_cursor; const std::uint32_t rhs = 0x00000020u; const std::uint32_t result = lhs + rhs; flow.frame_cursor = result; update_add_condition( lhs, rhs, result, 32u); }
                write_global_direct<std::uint64_t>(global_bytes, 0x100d6168u, native_double_to_binary64_bits(floating.temporary[7u]));
                floating.temporary[7u] = native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000030u));
                floating.temporary[7u] = floating.temporary[7u] + native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000038u));
                write_global_direct<std::uint64_t>(global_bytes, 0x100d6170u, native_double_to_binary64_bits(floating.temporary[7u]));
                floating.temporary[7u] = native_double_abs(floating.temporary[7u]);
                floating.temporary[6u] = floating.temporary[7u];
                floating.temporary[5u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6168u));
                floating.temporary[5u] = native_double_abs(floating.temporary[5u]);
                write_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000080u, native_double_to_binary64_bits(floating.temporary[5u]));
                write_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000018u, native_double_to_binary64_bits(floating.temporary[5u]));
                update_float_condition(floating.temporary[6u], native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000018u)));
                flow.value_a = (flow.value_a & 0xffff0000u) | ((floating.comparison_status) & 0xffffu);
                if (((((((flow.value_a >> 8u) & 0xffu)) & (0x00000041u)) & 0xffu) == 0u)) {
                    goto FlowStep53;
                }
                floating.temporary[6u] = floating.temporary[6u];
                floating.temporary[6u] = native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000018u));
                goto FlowStep53;
            }
        FlowStep53: {
                update_float_condition(floating.temporary[6u], native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d63e0u)));
                flow.value_a = (flow.value_a & 0xffff0000u) | ((floating.comparison_status) & 0xffffu);
                if (((((((flow.value_a >> 8u) & 0xffu)) & (0x00000041u)) & 0xffu) != 0u)) {
                    goto FlowStep54;
                }
                write_global_direct<std::uint64_t>(global_bytes, 0x100d63e0u, native_double_to_binary64_bits(floating.temporary[6u]));
                goto FlowStep55;
            }
        FlowStep54: {
                floating.temporary[6u] = floating.temporary[6u];
                goto FlowStep55;
            }
        FlowStep55: {
                flow.value_a = read_global_direct<std::uint32_t>(global_bytes, 0x101060a4u);
                flow.value_c = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000080u);
                flow.value_d = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000084u);
                { const std::uint32_t lhs = flow.value_a; const std::uint32_t rhs = flow.value_b; update_sub_condition(lhs, rhs, lhs - rhs, 32u); }
                write_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000050u, native_double_to_binary64_bits(floating.temporary[7u]));
                write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000018u, static_cast<std::uint32_t>(flow.value_c));
                write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x0000001cu, static_cast<std::uint32_t>(flow.value_d));
                if (!flow.condition.zero) {
                    goto FlowStep56;
                }
                flow.value_a = read_global_direct<std::uint32_t>(global_bytes, 0x1010f4b8u);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x100d6170u);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x100d6168u);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.value_a);
                fast_soft_clip_stereo(static_cast<std::int32_t>(flow.value_a), 0x100d6168u, 0x100d6170u);
                { const std::uint32_t lhs = flow.frame_cursor; const std::uint32_t rhs = 0x0000000cu; const std::uint32_t result = lhs + rhs; flow.frame_cursor = result; update_add_condition( lhs, rhs, result, 32u); }
                goto FlowStep56;
            }
        FlowStep56: {
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6170u));
                floating.temporary[7u] = native_double_abs(floating.temporary[7u]);
                floating.temporary[7u] = native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000050u)) - floating.temporary[7u];
                floating.temporary[6u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6168u));
                floating.temporary[6u] = native_double_abs(floating.temporary[6u]);
                floating.temporary[6u] = native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000018u)) - floating.temporary[6u];
                write_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000018u, native_double_to_binary64_bits(floating.temporary[6u]));
                update_float_condition(floating.temporary[7u], native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000018u)));
                flow.value_a = (flow.value_a & 0xffff0000u) | ((floating.comparison_status) & 0xffffu);
                if (((((((flow.value_a >> 8u) & 0xffu)) & (0x00000041u)) & 0xffu) == 0u)) {
                    goto FlowStep57;
                }
                floating.temporary[7u] = floating.temporary[7u];
                floating.temporary[7u] = native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000018u));
                goto FlowStep57;
            }
        FlowStep57: {
                update_float_condition(floating.temporary[7u], native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d63e8u)));
                flow.value_a = (flow.value_a & 0xffff0000u) | ((floating.comparison_status) & 0xffffu);
                if (((((((flow.value_a >> 8u) & 0xffu)) & (0x00000041u)) & 0xffu) != 0u)) {
                    goto FlowStep58;
                }
                write_global_direct<std::uint64_t>(global_bytes, 0x100d63e8u, native_double_to_binary64_bits(floating.temporary[7u]));
                goto FlowStep59;
            }
        FlowStep58: {
                floating.temporary[7u] = floating.temporary[7u]; goto FlowStep59;
                #endif
                goto FlowStep59;
            }
        FlowStep59: {
                if ((((read_global_direct<std::uint32_t>(global_bytes, 0x101060c8u)) & 0xffffffffu) != ((flow.value_b) & 0xffffffffu))) {
                    goto FlowStep61;
                }
                flow.value_a = read_global_direct<std::uint32_t>(global_bytes, 0x101060b8u);
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d60f0u));
                if ((((flow.value_a) & 0xffffffffu) == ((flow.value_b) & 0xffffffffu))) {
                    goto FlowStep60;
                }
                floating.temporary[7u] = floating.temporary[7u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c540u));
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6170u)) - floating.temporary[7u];
                write_global_direct<std::uint64_t>(global_bytes, 0x100d60e8u, native_double_to_binary64_bits(floating.temporary[7u]));
                floating.temporary[6u] = floating.temporary[7u];
                floating.temporary[6u] = floating.temporary[6u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c530u));
                write_global_direct<std::uint64_t>(global_bytes, 0x100d6170u, native_double_to_binary64_bits(floating.temporary[6u]));
                write_global_direct<std::uint64_t>(global_bytes, 0x100d60f0u, native_double_to_binary64_bits(floating.temporary[7u]));
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6100u));
                floating.temporary[7u] = floating.temporary[7u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c540u));
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6168u)) - floating.temporary[7u];
                write_global_direct<std::uint64_t>(global_bytes, 0x100d60f8u, native_double_to_binary64_bits(floating.temporary[7u]));
                floating.temporary[7u] = floating.temporary[7u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c530u));
                flow.value_c = read_global_direct<std::uint32_t>(global_bytes, 0x100d60f8u);
                flow.value_d = read_global_direct<std::uint32_t>(global_bytes, 0x100d60fcu);
                write_global_direct<std::uint32_t>(global_bytes, 0x100d6100u, static_cast<std::uint32_t>(flow.value_c));
                write_global_direct<std::uint32_t>(global_bytes, 0x100d6104u, static_cast<std::uint32_t>(flow.value_d));
                goto FlowStep66;
            }
        FlowStep60: {
                floating.temporary[7u] = floating.temporary[7u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c520u));
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6170u)) - floating.temporary[7u];
                write_global_direct<std::uint64_t>(global_bytes, 0x100d60e8u, native_double_to_binary64_bits(floating.temporary[7u]));
                floating.temporary[6u] = floating.temporary[7u];
                floating.temporary[6u] = floating.temporary[6u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c510u));
                write_global_direct<std::uint64_t>(global_bytes, 0x100d6170u, native_double_to_binary64_bits(floating.temporary[6u]));
                write_global_direct<std::uint64_t>(global_bytes, 0x100d60f0u, native_double_to_binary64_bits(floating.temporary[7u]));
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6100u));
                floating.temporary[7u] = floating.temporary[7u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c520u));
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6168u)) - floating.temporary[7u];
                write_global_direct<std::uint64_t>(global_bytes, 0x100d60f8u, native_double_to_binary64_bits(floating.temporary[7u]));
                floating.temporary[7u] = floating.temporary[7u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c510u));
                flow.value_a = read_global_direct<std::uint32_t>(global_bytes, 0x100d60f8u);
                flow.value_c = read_global_direct<std::uint32_t>(global_bytes, 0x100d60fcu);
                write_global_direct<std::uint32_t>(global_bytes, 0x100d6100u, static_cast<std::uint32_t>(flow.value_a));
                write_global_direct<std::uint32_t>(global_bytes, 0x100d6104u, static_cast<std::uint32_t>(flow.value_c));
                goto FlowStep66;
            }
        FlowStep61: {
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6170u));
                truncate_native_double_to_i64_parts(floating.temporary[7u]);
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6168u));
                write_global_direct<std::uint32_t>(global_bytes, 0x1000f5c8u, static_cast<std::uint32_t>(flow.value_a));
                truncate_native_double_to_i64_parts(floating.temporary[7u]);
                write_global_direct<std::uint32_t>(global_bytes, 0x1000ed10u, static_cast<std::uint32_t>(flow.value_a));
                { const std::uint32_t lhs = flow.value_d; const std::uint32_t rhs = flow.value_d; const std::uint32_t result = lhs ^ rhs; flow.value_d = result; update_logic_condition( result, 32u); }
                { const std::uint32_t lhs = flow.index; const std::uint32_t rhs = flow.index; const std::uint32_t result = lhs ^ rhs; flow.index = result; update_logic_condition( result, 32u); }
                { const std::uint32_t lhs = flow.value_a; const std::uint32_t rhs = flow.value_a; const std::uint32_t result = lhs ^ rhs; flow.value_a = result; update_logic_condition( result, 32u); }
                goto FlowStep62;
            }
        FlowStep62: {
                flow.value_c = read_u32(flow.value_a + 0x1004af0cu);
                flow.pointer = read_u32(flow.value_a + 0x1000f5ccu);
                { const std::int64_t product = static_cast<std::int64_t>(static_cast<std::int32_t>(flow.pointer)) * static_cast<std::int64_t>(static_cast<std::int32_t>(flow.value_c)); flow.pointer = static_cast<std::uint32_t>(product); flow.condition.carry = flow.condition.overflow = (product > INT32_MAX || product < INT32_MIN); }
                { const std::uint32_t lhs = flow.value_d; const std::uint32_t rhs = flow.pointer; const std::uint32_t result = lhs + rhs; flow.value_d = result; update_add_condition( lhs, rhs, result, 32u); }
                flow.pointer = read_u32(flow.value_a + 0x1000ed14u);
                { const std::int64_t product = static_cast<std::int64_t>(static_cast<std::int32_t>(flow.pointer)) * static_cast<std::int64_t>(static_cast<std::int32_t>(flow.value_c)); flow.pointer = static_cast<std::uint32_t>(product); flow.condition.carry = flow.condition.overflow = (product > INT32_MAX || product < INT32_MIN); }
                { const std::uint32_t lhs = flow.value_a; const std::uint32_t rhs = 0x00000004u; const std::uint32_t result = lhs + rhs; flow.value_a = result; update_add_condition( lhs, rhs, result, 32u); }
                { const std::uint32_t lhs = flow.index; const std::uint32_t rhs = flow.pointer; const std::uint32_t result = lhs + rhs; flow.index = result; update_add_condition( lhs, rhs, result, 32u); }
                if ((static_cast<std::int32_t>(flow.value_a) < static_cast<std::int32_t>(0x00000068u))) {
                    goto FlowStep62;
                }
                flow.value_a = 0x00000004u;
                goto FlowStep63;
            }
        FlowStep63: {
                flow.value_c = read_u32(flow.value_a + 0x1000f628u);
                write_u32(flow.value_a + 0x1000f62cu, static_cast<std::uint32_t>(flow.value_c));
                flow.value_c = read_u32(flow.value_a + 0x1000ed70u);
                write_u32(flow.value_a + 0x1000ed74u, static_cast<std::uint32_t>(flow.value_c));
                { const std::uint32_t lhs = flow.value_a; const std::uint32_t rhs = 0x00000004u; const std::uint32_t result = lhs - rhs; flow.value_a = result; update_sub_condition( lhs, rhs, result, 32u); }
                if ((static_cast<std::int32_t>(flow.value_a) >= static_cast<std::int32_t>(0xffffffa0u))) {
                    goto FlowStep63;
                }
                { const unsigned count = (0x0000000du) & 31u; if (count != 0u) { const std::uint32_t old_value = flow.value_d; const std::uint32_t result = static_cast<std::uint32_t>(static_cast<std::int32_t>(old_value) >> count); flow.value_d = result; update_logic_condition(result, 32u); } }
                write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000018u, static_cast<std::uint32_t>(flow.value_d));
                floating.temporary[7u] = static_cast<NativeDouble>(static_cast<std::int32_t>(read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000018u)));
                { const unsigned count = (0x0000000du) & 31u; if (count != 0u) { const std::uint32_t old_value = flow.index; const std::uint32_t result = static_cast<std::uint32_t>(static_cast<std::int32_t>(old_value) >> count); flow.index = result; update_logic_condition(result, 32u); } }
                write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000018u, static_cast<std::uint32_t>(flow.index));
                floating.temporary[7u] = floating.temporary[7u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c580u));
                write_global_direct<std::uint64_t>(global_bytes, 0x100d6170u, native_double_to_binary64_bits(floating.temporary[7u]));
                floating.temporary[7u] = static_cast<NativeDouble>(static_cast<std::int32_t>(read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000018u)));
                floating.temporary[7u] = floating.temporary[7u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c580u));
                goto FlowStep65;
            }
        FlowStep64: {
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6168u));
                write_global_direct<std::uint32_t>(global_bytes, 0x100d6888u, static_cast<std::uint32_t>(flow.value_b));
                write_global_direct<std::uint32_t>(global_bytes, 0x100d689cu, static_cast<std::uint32_t>(flow.value_b));
                write_global_direct<std::uint32_t>(global_bytes, 0x100d5f58u, static_cast<std::uint32_t>(flow.value_b));
                goto FlowStep65;
            }
        FlowStep65: {
                flow.pointer = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000010u);
                goto FlowStep66;
            }
        FlowStep66: {
                flow.value_a = read_global_direct<std::uint32_t>(global_bytes, 0x100d6894u);
                { const std::uint32_t lhs = flow.value_a; const std::uint32_t rhs = flow.value_b; update_sub_condition(lhs, rhs, lhs - rhs, 32u); }
                flow.value_a = read_global_direct<std::uint32_t>(global_bytes, 0x100d61c8u);
                if (flow.condition.zero) {
                    goto FlowStep67;
                }
                { const std::uint32_t old_value = flow.value_a; const std::uint32_t result = old_value + 1u; flow.value_a = result; const bool carry = flow.condition.carry; update_add_condition(old_value, 1u, result, 32u); flow.condition.carry = carry; }
                { const std::uint32_t lhs = flow.value_a; const std::uint32_t rhs = 0x000003e8u; update_sub_condition(lhs, rhs, lhs - rhs, 32u); }
                write_global_direct<std::uint32_t>(global_bytes, 0x100d61c8u, static_cast<std::uint32_t>(flow.value_a));
                if ((flow.condition.zero || flow.condition.negative != flow.condition.overflow)) {
                    goto FlowStep68;
                }
                write_global_direct<std::uint32_t>(global_bytes, 0x100d61c8u, static_cast<std::uint32_t>(0x000003e8u));
                goto FlowStep68;
            }
        FlowStep67: {
                { const std::uint32_t old_value = flow.value_a; const std::uint32_t result = old_value - 1u; flow.value_a = result; const bool carry = flow.condition.carry; update_sub_condition(old_value, 1u, result, 32u); flow.condition.carry = carry; }
                write_global_direct<std::uint32_t>(global_bytes, 0x100d61c8u, static_cast<std::uint32_t>(flow.value_a));
                if (!flow.condition.negative) {
                    goto FlowStep68;
                }
                write_global_direct<std::uint32_t>(global_bytes, 0x100d61c8u, static_cast<std::uint32_t>(flow.value_b));
                goto FlowStep68;
            }
        FlowStep68: {
                flow.value_a = read_global_direct<std::uint32_t>(global_bytes, 0x100d61ccu);
                if ((static_cast<std::int32_t>(flow.value_a) < static_cast<std::int32_t>(0x00000273u))) {
                    goto FlowStep69;
                }
                { const std::uint32_t lhs = flow.value_a; const std::uint32_t rhs = flow.value_a; const std::uint32_t result = lhs ^ rhs; flow.value_a = result; update_logic_condition( result, 32u); }
                goto FlowStep69;
            }
        FlowStep69: {
                flow.index = read_global_direct<std::uint32_t>(global_bytes, 0x100d61c8u);
                flow.value_d = 0x000003e8u;
                floating.temporary[6u] = static_cast<NativeDouble>(static_cast<std::int32_t>(read_u32((flow.value_a * 4u) + 0x100d6b60u)));
                { const std::uint32_t lhs = flow.value_d; const std::uint32_t rhs = flow.index; const std::uint32_t result = lhs - rhs; flow.value_d = result; update_sub_condition( lhs, rhs, result, 32u); }
                { const std::uint32_t lhs = flow.value_a; const std::uint32_t rhs = 0x00000002u; const std::uint32_t result = lhs + rhs; flow.value_a = result; update_add_condition( lhs, rhs, result, 32u); }
                write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000018u, static_cast<std::uint32_t>(flow.value_d));
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x100d6170u);
                floating.temporary[5u] = static_cast<NativeDouble>(static_cast<std::int32_t>(read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x0000001cu)));
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x00007ff8u);
                write_global_direct<std::uint32_t>(global_bytes, 0x100d61ccu, static_cast<std::uint32_t>(flow.value_a));
                write_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000088u, native_double_to_binary64_bits(floating.temporary[5u]));
                floating.temporary[6u] *= static_cast<NativeDouble>(static_cast<std::int32_t>(read_global_direct<std::uint32_t>(global_bytes, 0x100d61c8u)));
                floating.temporary[5u] = native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000088u));
                floating.temporary[5u] = floating.temporary[5u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6170u));
                floating.temporary[5u] = floating.temporary[5u] + floating.temporary[6u];
                floating.temporary[5u] = floating.temporary[5u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c500u));
                write_global_direct<std::uint64_t>(global_bytes, 0x100d6170u, native_double_to_binary64_bits(floating.temporary[5u]));
                floating.temporary[5u] = native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000088u));
                floating.temporary[5u] = floating.temporary[5u] * floating.temporary[7u];
                floating.temporary[5u] = floating.temporary[5u] + floating.temporary[6u];
                floating.temporary[5u] = floating.temporary[5u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c500u));
                write_global_direct<std::uint64_t>(global_bytes, 0x100d6168u, native_double_to_binary64_bits(floating.temporary[5u]));
                floating.temporary[6u] = floating.temporary[6u];
                floating.temporary[7u] = floating.temporary[7u];
                flow.frame_cursor -= 4u; fast_10008ff0(); flow.frame_cursor += 4u;
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x100d6168u);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, 0x00007ff8u);
                fast_soft_clip_mono(0x7ff8, 0x100d6168u);
                flow.value_a = read_global_direct<std::uint32_t>(global_bytes, 0x1010609cu);
                { const std::uint32_t lhs = flow.frame_cursor; const std::uint32_t rhs = 0x00000010u; const std::uint32_t result = lhs + rhs; flow.frame_cursor = result; update_add_condition( lhs, rhs, result, 32u); }
                if ((((flow.value_a) & 0xffffffffu) != ((flow.value_b) & 0xffffffffu))) {
                    goto FlowStep73;
                }
                { const std::uint32_t lhs = read_global_direct<std::uint32_t>(global_bytes, 0x100d5f60u); const std::uint32_t rhs = flow.value_b; update_sub_condition(lhs, rhs, lhs - rhs, 32u); }
                goto FlowStep72;
            }
        FlowStep70: {
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6168u));
                goto FlowStep71;
            }
        FlowStep71: {
                truncate_native_double_to_i64_parts(floating.temporary[7u]);
                flow.index = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_base + 0x00000018u);
                write_u16(flow.pointer, static_cast<std::uint16_t>((flow.value_a & 0xffffu)));
                if ((((flow.index) & 0xffffffffu) != ((0x00000002u) & 0xffffffffu))) {
                    goto FlowStep78;
                }
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6170u));
                update_float_condition(floating.temporary[7u], native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c4d0u)));
                flow.value_a = (flow.value_a & 0xffff0000u) | ((floating.comparison_status) & 0xffffu);
                if (((((((flow.value_a >> 8u) & 0xffu)) & (0x00000041u)) & 0xffu) != 0u)) {
                    goto FlowStep75;
                }
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c4d0u));
                goto FlowStep77;
            }
        FlowStep72: {
                floating.temporary[7u] = static_cast<NativeDouble>(static_cast<std::int32_t>(read_global_direct<std::uint32_t>(global_bytes, 0x101060d4u)));
                floating.temporary[6u] = floating.temporary[7u];
                floating.temporary[6u] = floating.temporary[6u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6168u));
                floating.temporary[6u] = floating.temporary[6u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c4e0u));
                write_global_direct<std::uint64_t>(global_bytes, 0x100d6168u, native_double_to_binary64_bits(floating.temporary[6u]));
                floating.temporary[7u] = floating.temporary[7u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6170u));
                floating.temporary[7u] = floating.temporary[7u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c4e0u));
                write_global_direct<std::uint64_t>(global_bytes, 0x100d6170u, native_double_to_binary64_bits(floating.temporary[7u]));
                goto FlowStep73;
            }
        FlowStep73: {
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6168u));
                update_float_condition(floating.temporary[7u], native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c4d0u)));
                flow.value_a = (flow.value_a & 0xffff0000u) | ((floating.comparison_status) & 0xffffu);
                if (((((((flow.value_a >> 8u) & 0xffu)) & (0x00000041u)) & 0xffu) != 0u)) {
                    goto FlowStep74;
                }
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c4d0u));
                goto FlowStep71;
            }
        FlowStep74: {
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6168u));
                update_float_condition(floating.temporary[7u], native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c4f0u)));
                flow.value_a = (flow.value_a & 0xffff0000u) | ((floating.comparison_status) & 0xffffu);
                if (((((((flow.value_a >> 8u) & 0xffu)) & (0x00000001u)) & 0xffu) == 0u)) {
                    goto FlowStep70;
                }
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c4f0u));
                goto FlowStep71;
            }
        FlowStep75: {
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6170u));
                update_float_condition(floating.temporary[7u], native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c4f0u)));
                flow.value_a = (flow.value_a & 0xffff0000u) | ((floating.comparison_status) & 0xffffu);
                if (((((((flow.value_a >> 8u) & 0xffu)) & (0x00000001u)) & 0xffu) == 0u)) {
                    goto FlowStep76;
                }
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c4f0u));
                goto FlowStep77;
            }
        FlowStep76: {
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d6170u));
                goto FlowStep77;
            }
        FlowStep77: {
                truncate_native_double_to_i64_parts(floating.temporary[7u]);
                write_u16(flow.pointer + 0x00000002u, static_cast<std::uint16_t>((flow.value_a & 0xffffu)));
                goto FlowStep78;
            }
        FlowStep78: {
                flow.value_a = static_cast<std::uint32_t>(static_cast<std::int32_t>(static_cast<std::int16_t>(read_u16(flow.pointer))));
                flow.value_d = static_cast<std::int32_t>(flow.value_a) < 0 ? 0xffffffffu : 0u;
                { const std::uint32_t lhs = flow.value_a; const std::uint32_t rhs = flow.value_d; const std::uint32_t result = lhs ^ rhs; flow.value_a = result; update_logic_condition( result, 32u); }
                { const std::uint32_t lhs = flow.value_a; const std::uint32_t rhs = flow.value_d; const std::uint32_t result = lhs - rhs; flow.value_a = result; update_sub_condition( lhs, rhs, result, 32u); }
                write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000018u, static_cast<std::uint32_t>(flow.value_a));
                flow.value_a = static_cast<std::uint32_t>(static_cast<std::int32_t>(static_cast<std::int16_t>(read_u16(flow.pointer + 0x00000002u))));
                floating.temporary[7u] = static_cast<NativeDouble>(static_cast<std::int32_t>(read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000018u)));
                flow.value_d = static_cast<std::int32_t>(flow.value_a) < 0 ? 0xffffffffu : 0u;
                { const std::uint32_t lhs = flow.value_a; const std::uint32_t rhs = flow.value_d; const std::uint32_t result = lhs ^ rhs; flow.value_a = result; update_logic_condition( result, 32u); }
                { const std::uint32_t lhs = flow.value_a; const std::uint32_t rhs = flow.value_d; const std::uint32_t result = lhs - rhs; flow.value_a = result; update_sub_condition( lhs, rhs, result, 32u); }
                write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000018u, static_cast<std::uint32_t>(flow.value_a));
                floating.temporary[6u] = static_cast<NativeDouble>(static_cast<std::int32_t>(read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000018u)));
                write_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000018u, native_double_to_binary64_bits(floating.temporary[6u]));
                floating.temporary[6u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d63c8u));
                update_float_condition(floating.temporary[6u], floating.temporary[7u]);
                flow.value_a = (flow.value_a & 0xffff0000u) | ((floating.comparison_status) & 0xffffu);
                if (((((((flow.value_a >> 8u) & 0xffu)) & (0x00000001u)) & 0xffu) == 0u)) {
                    goto FlowStep79;
                }
                write_global_direct<std::uint64_t>(global_bytes, 0x100d63c8u, native_double_to_binary64_bits(floating.temporary[7u]));
                goto FlowStep80;
            }
        FlowStep79: {
                floating.temporary[7u] = floating.temporary[7u];
                floating.temporary[7u] = native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x100d63c8u));
                update_float_condition(floating.temporary[7u], native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000018u)));
                flow.value_a = (flow.value_a & 0xffff0000u) | ((floating.comparison_status) & 0xffffu);
                if (((((((flow.value_a >> 8u) & 0xffu)) & (0x00000001u)) & 0xffu) == 0u)) {
                    goto FlowStep80;
                }
                flow.value_a = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000018u);
                flow.value_c = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x0000001cu);
                write_global_direct<std::uint32_t>(global_bytes, 0x100d63c8u, static_cast<std::uint32_t>(flow.value_a));
                write_global_direct<std::uint32_t>(global_bytes, 0x100d63ccu, static_cast<std::uint32_t>(flow.value_c));
                goto FlowStep80;
            }
        FlowStep80: {
                flow.value_a = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000014u);
                flow.pointer = flow.pointer + (flow.index * 2u);
                flow.value_d = flow.value_a;
                { const std::uint32_t old_value = flow.value_a; const std::uint32_t result = old_value - 1u; flow.value_a = result; const bool carry = flow.condition.carry; update_sub_condition(old_value, 1u, result, 32u); flow.condition.carry = carry; }
                update_logic_condition((flow.value_d) & (flow.value_d), 32u);
                write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000010u, static_cast<std::uint32_t>(flow.pointer));
                write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000014u, static_cast<std::uint32_t>(flow.value_a));
                if (!flow.condition.zero) {
                    goto FlowStep00;
                }
                goto FlowStep82;
            }
        FlowStep81: {
                { const std::uint32_t lhs = flow.value_a; const std::uint32_t rhs = flow.value_a; const std::uint32_t result = lhs ^ rhs; flow.value_a = result; update_logic_condition( result, 32u); }
                write_global_direct<std::uint32_t>(global_bytes, 0x100d5f58u, static_cast<std::uint32_t>(flow.value_a));
                write_global_direct<std::uint32_t>(global_bytes, 0x100d6888u, static_cast<std::uint32_t>(flow.value_a));
                write_global_direct<std::uint32_t>(global_bytes, 0x100d689cu, static_cast<std::uint32_t>(flow.value_a));
                write_global_direct<std::uint32_t>(global_bytes, 0x100d6850u, static_cast<std::uint32_t>(flow.value_a));
                write_global_direct<std::uint32_t>(global_bytes, 0x100d6854u, static_cast<std::uint32_t>(flow.value_a));
                write_global_direct<std::uint32_t>(global_bytes, 0x100d6858u, static_cast<std::uint32_t>(flow.value_a));
                write_global_direct<std::uint32_t>(global_bytes, 0x100d685cu, static_cast<std::uint32_t>(flow.value_a));
                flow.value_a = read_global_direct<std::uint32_t>(global_bytes, 0x100d5f54u);
                { const std::uint32_t lhs = ((flow.value_a >> 8u) & 0xffu); const std::uint32_t rhs = 0x000000ffu; const std::uint32_t result = lhs | rhs; flow.value_a = (flow.value_a & 0xffff00ffu) | (((result) & 0xffu) << 8u); update_logic_condition( result, 8u); }
                write_global_direct<std::uint32_t>(global_bytes, 0x100d5f54u, static_cast<std::uint32_t>(flow.value_a));
                goto FlowStep82;
            }
        FlowStep82: {
                // The supplied DLL contains a dormant evaluation timer at
                // 0x1000392a..0x10003996. Its audio-muting branch is unreachable in the
                // original binary. Preserve the observable ModifySamples return value,
                // but do not execute or maintain the dead counters.
                flow.value_a = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_base + 0x10u);

                flow.pointer = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor); flow.frame_cursor += 4u;
                flow.index = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor); flow.frame_cursor += 4u;
                flow.value_b = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor); flow.frame_cursor += 4u;
                flow.frame_cursor = flow.frame_base;
                flow.frame_base = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor); flow.frame_cursor += 4u;
                flow.frame_cursor += 4u; return;
            }
        FlowStep83: {
                { const std::uint32_t lhs = flow.frame_cursor; const std::uint32_t rhs = 0x00000008u; const std::uint32_t result = lhs - rhs; flow.frame_cursor = result; update_sub_condition( lhs, rhs, result, 32u); }
                flow.value_d = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x0000000cu);
                flow.value_c = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000014u);
                flow.frame_cursor -= 4u; write_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor, flow.index);
                flow.index = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000014u);
                { const std::uint32_t lhs = flow.value_a; const std::uint32_t rhs = flow.value_a; const std::uint32_t result = lhs ^ rhs; flow.value_a = result; update_logic_condition( result, 32u); }
                { const std::uint32_t old_value = flow.value_c; const std::uint32_t result = old_value - 1u; flow.value_c = result; const bool carry = flow.condition.carry; update_sub_condition(old_value, 1u, result, 32u); flow.condition.carry = carry; }
                floating.temporary[7u] = native_double_from_binary64_bits(read_u64(flow.index));
                floating.temporary[6u] = native_double_from_binary64_bits(read_u64(flow.value_d));
                update_logic_condition((flow.value_c) & (flow.value_c), 32u);
                write_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000004u, native_double_to_binary64_bits(floating.temporary[6u]));
                if ((flow.condition.zero || flow.condition.negative != flow.condition.overflow)) {
                    goto FlowStep85;
                }
                goto FlowStep84;
            }
        FlowStep84: {
                floating.temporary[5u] = floating.temporary[7u];
                floating.temporary[5u] = floating.temporary[5u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c7d0u));
                floating.temporary[4u] = native_double_from_binary64_bits(read_u64((flow.value_a * 8u) + 0x100104e0u));
                floating.temporary[4u] = floating.temporary[4u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c680u));
                { const std::uint32_t old_value = flow.value_a; const std::uint32_t result = old_value + 1u; flow.value_a = result; const bool carry = flow.condition.carry; update_add_condition(old_value, 1u, result, 32u); flow.condition.carry = carry; }
                floating.temporary[5u] = floating.temporary[5u] + floating.temporary[4u];
                { const std::uint32_t lhs = flow.value_a; const std::uint32_t rhs = flow.value_c; update_sub_condition(lhs, rhs, lhs - rhs, 32u); }
                write_u64((flow.value_a * 8u) + 0x100104d8u, native_double_to_binary64_bits(floating.temporary[5u]));
                floating.temporary[4u] = floating.temporary[6u];
                floating.temporary[4u] = floating.temporary[4u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c7d0u));
                floating.temporary[3u] = native_double_from_binary64_bits(read_u64((flow.value_a * 8u) + 0x100d5e68u));
                floating.temporary[3u] = floating.temporary[3u] * native_double_from_binary64_bits(read_global_direct<std::uint64_t>(global_bytes, 0x1000c680u));
                floating.temporary[4u] = floating.temporary[4u] + floating.temporary[3u];
                write_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000004u, native_double_to_binary64_bits(floating.temporary[4u]));
                write_u64((flow.value_a * 8u) + 0x100d5e68u, native_double_to_binary64_bits(floating.temporary[4u]));
                floating.temporary[5u] = floating.temporary[5u] + floating.temporary[5u];
                floating.temporary[7u] = floating.temporary[5u] - floating.temporary[7u];
                floating.temporary[5u] = native_double_from_binary64_bits(read_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000004u));
                floating.temporary[5u] = floating.temporary[5u] + floating.temporary[5u];
                floating.temporary[6u] = floating.temporary[5u] - floating.temporary[6u];
                if ((flow.condition.negative != flow.condition.overflow)) {
                    goto FlowStep84;
                }
                write_frame_direct<std::uint64_t>(frame_bytes, flow.frame_cursor + 0x00000004u, native_double_to_binary64_bits(floating.temporary[6u]));
                flow.value_a = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000004u);
                flow.value_c = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000008u);
                write_u64(flow.index, native_double_to_binary64_bits(floating.temporary[7u]));
                write_u32(flow.value_d, static_cast<std::uint32_t>(flow.value_a));
                write_u32(flow.value_d + 0x00000004u, static_cast<std::uint32_t>(flow.value_c));
                flow.index = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor); flow.frame_cursor += 4u;
                { const std::uint32_t lhs = flow.frame_cursor; const std::uint32_t rhs = 0x00000008u; const std::uint32_t result = lhs + rhs; flow.frame_cursor = result; update_add_condition( lhs, rhs, result, 32u); }
                flow.frame_cursor += 4u; goto FlowStep09;
            }
        FlowStep85: {
                flow.value_a = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000004u);
                flow.value_c = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor + 0x00000008u);
                floating.temporary[6u] = floating.temporary[6u];
                write_u64(flow.index, native_double_to_binary64_bits(floating.temporary[7u]));
                write_u32(flow.value_d, static_cast<std::uint32_t>(flow.value_a));
                write_u32(flow.value_d + 0x00000004u, static_cast<std::uint32_t>(flow.value_c));
                flow.index = read_frame_direct<std::uint32_t>(frame_bytes, flow.frame_cursor); flow.frame_cursor += 4u;
                { const std::uint32_t lhs = flow.frame_cursor; const std::uint32_t rhs = 0x00000008u; const std::uint32_t result = lhs + rhs; flow.frame_cursor = result; update_add_condition( lhs, rhs, result, 32u); }
                flow.frame_cursor += 4u; goto FlowStep09;

            }
    }

    __attribute__((hot, noinline)) void execute_native_process() {
#if defined(SSNATIVE_DIRECT_GOTO_FLOW)
        execute_native_process_direct();
#else

        ProcessStage stage = ProcessStage::Entry;
        for (;;) {
            switch (stage) {
            case ProcessStage::Entry: {

                call_state().flow.frame_cursor -= 4u;
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.frame_base);
                call_state().flow.frame_base = call_state().flow.frame_cursor;
                { const std::uint32_t lhs = call_state().flow.frame_cursor; const std::uint32_t rhs = 0xfffffff8u; const std::uint32_t result = lhs & rhs; call_state().flow.frame_cursor = result; update_logic_condition( result, 32u); }
                { const std::uint32_t lhs = call_state().flow.frame_cursor; const std::uint32_t rhs = 0x0000007cu; const std::uint32_t result = lhs - rhs; call_state().flow.frame_cursor = result; update_sub_condition( lhs, rhs, result, 32u); }
                call_state().flow.value_a = read_u32(call_state().flow.frame_base + 0x00000014u);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.value_b);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.index);
                { const std::uint32_t lhs = call_state().flow.value_a; const std::uint32_t rhs = 0x00000010u; update_sub_condition(lhs, rhs, lhs - rhs, 32u); }
                call_state().flow.value_a = read_u32(call_state().flow.frame_base + 0x00000010u);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.pointer);
                if (!call_state().flow.condition.zero) {
                    stage = ProcessStage::FlowStep81;
                    continue;
                }
                if ((static_cast<std::int32_t>(read_u32(call_state().flow.frame_base + 0x0000001cu)) < static_cast<std::int32_t>(0x0000ac44u))) {
                    stage = ProcessStage::FlowStep81;
                    continue;
                }
                call_state().flow.value_d = read_u32(0x100d5f54u);
                call_state().flow.value_c = read_u32(call_state().flow.frame_base + 0x0000000cu);
                { const std::uint32_t lhs = call_state().flow.value_d; const std::uint32_t rhs = 0x000000ffu; const std::uint32_t result = lhs & rhs; call_state().flow.value_d = result; update_logic_condition( result, 32u); }
                write_u32(call_state().flow.frame_cursor + 0x00000010u, static_cast<std::uint32_t>(call_state().flow.value_c));
                write_u32(0x100d5f54u, static_cast<std::uint32_t>(call_state().flow.value_d));
                call_state().flow.value_d = call_state().flow.value_a + static_cast<std::uint32_t>(-1);
                update_logic_condition((call_state().flow.value_a) & (call_state().flow.value_a), 32u);
                write_u32(call_state().flow.frame_cursor + 0x00000014u, static_cast<std::uint32_t>(call_state().flow.value_d));
                if (call_state().flow.condition.zero) {
                    stage = ProcessStage::FlowStep82;
                    continue;
                }
                { const std::uint32_t lhs = call_state().flow.value_b; const std::uint32_t rhs = call_state().flow.value_b; const std::uint32_t result = lhs ^ rhs; call_state().flow.value_b = result; update_logic_condition( result, 32u); }
                call_state().flow.pointer = call_state().flow.value_c;
                stage = ProcessStage::FlowStep00;
                continue;
            }
            case ProcessStage::FlowStep00: {
                call_state().flow.value_a = static_cast<std::uint32_t>(static_cast<std::int32_t>(static_cast<std::int16_t>(read_u16(call_state().flow.pointer))));
                call_state().flow.value_c = read_u32(0x101060f0u);
                write_u32(call_state().flow.frame_cursor + 0x00000018u, static_cast<std::uint32_t>(call_state().flow.value_a));
                call_state().floating.temporary[7u] = static_cast<NativeDouble>(static_cast<std::int32_t>(read_u32(call_state().flow.frame_cursor + 0x00000018u)));
                { const std::uint32_t lhs = read_u32(call_state().flow.frame_base + 0x00000018u); const std::uint32_t rhs = 0x00000002u; update_sub_condition(lhs, rhs, lhs - rhs, 32u); }
                write_u64(0x100d6168u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                if (!call_state().flow.condition.zero) {
                    stage = ProcessStage::FlowStep02;
                    continue;
                }
                call_state().flow.value_d = static_cast<std::uint32_t>(static_cast<std::int32_t>(static_cast<std::int16_t>(read_u16(call_state().flow.pointer + 0x00000002u))));
                if (((((((call_state().flow.value_c >> 8u) & 0xffu)) & (0x00000001u)) & 0xffu) == 0u)) {
                    stage = ProcessStage::FlowStep01;
                    continue;
                }
                call_state().flow.value_a = static_cast<std::uint32_t>(static_cast<std::int32_t>(static_cast<std::int16_t>(read_u16(call_state().flow.pointer))));
                { const std::uint32_t lhs = call_state().flow.value_d; const std::uint32_t rhs = call_state().flow.value_a; const std::uint32_t result = lhs + rhs; call_state().flow.value_d = result; update_add_condition( lhs, rhs, result, 32u); }
                { const unsigned count = (0x00000001u) & 31u; if (count != 0u) { const std::uint32_t old_value = call_state().flow.value_d; const std::uint32_t result = static_cast<std::uint32_t>(static_cast<std::int32_t>(old_value) >> count); call_state().flow.value_d = result; update_logic_condition(result, 32u); } }
                write_u32(call_state().flow.frame_cursor + 0x00000018u, static_cast<std::uint32_t>(call_state().flow.value_d));
                call_state().floating.temporary[7u] = static_cast<NativeDouble>(static_cast<std::int32_t>(read_u32(call_state().flow.frame_cursor + 0x00000018u)));
                write_u64(0x100d6170u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                call_state().flow.value_d = read_u32(0x100d6170u);
                call_state().flow.value_a = read_u32(0x100d6174u);
                write_u32(0x100d6168u, static_cast<std::uint32_t>(call_state().flow.value_d));
                write_u32(0x100d616cu, static_cast<std::uint32_t>(call_state().flow.value_a));
                stage = ProcessStage::FlowStep03; continue;
            }
            case ProcessStage::FlowStep01: {
                write_u32(call_state().flow.frame_cursor + 0x00000018u, static_cast<std::uint32_t>(call_state().flow.value_d));
                call_state().floating.temporary[7u] = static_cast<NativeDouble>(static_cast<std::int32_t>(read_u32(call_state().flow.frame_cursor + 0x00000018u)));
                write_u64(0x100d6170u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                stage = ProcessStage::FlowStep03; continue;
            }
            case ProcessStage::FlowStep02: {
                call_state().flow.value_a = read_u32(0x100d6168u);
                call_state().flow.value_d = read_u32(0x100d616cu);
                write_u32(0x100d6170u, static_cast<std::uint32_t>(call_state().flow.value_a));
                write_u32(0x100d6174u, static_cast<std::uint32_t>(call_state().flow.value_d));
                stage = ProcessStage::FlowStep03;
                continue;
            }
            case ProcessStage::FlowStep03: {
                if ((((((call_state().flow.value_c & 0xffu)) & (0x00000010u)) & 0xffu) == 0u)) {
                    stage = ProcessStage::FlowStep04;
                    continue;
                }
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x100d6168u);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x100d6170u);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x100d68a0u);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x1000d778u);
                fast_fourth_stereo(0x1000d778u, 0x100d68a0u, 0x100d6170u, 0x100d6168u);
                call_state().flow.value_c = read_u32(0x101060f0u);
                { const std::uint32_t lhs = call_state().flow.frame_cursor; const std::uint32_t rhs = 0x00000010u; const std::uint32_t result = lhs + rhs; call_state().flow.frame_cursor = result; update_add_condition( lhs, rhs, result, 32u); }
                stage = ProcessStage::FlowStep04;
                continue;
            }
            case ProcessStage::FlowStep04: {
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x100d6168u));
                call_state().floating.temporary[7u] = native_double_abs(call_state().floating.temporary[7u]);
                call_state().floating.temporary[6u] = native_double_from_binary64_bits(read_u64(0x100d6170u));
                call_state().floating.temporary[6u] = native_double_abs(call_state().floating.temporary[6u]);
                write_u64(call_state().flow.frame_cursor + 0x00000018u, native_double_to_binary64_bits(call_state().floating.temporary[6u]));
                update_float_condition(call_state().floating.temporary[7u], native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000018u)));
                call_state().flow.value_a = (call_state().flow.value_a & 0xffff0000u) | ((call_state().floating.comparison_status) & 0xffffu);
                if (((((((call_state().flow.value_a >> 8u) & 0xffu)) & (0x00000041u)) & 0xffu) != 0u)) {
                    stage = ProcessStage::FlowStep05;
                    continue;
                }
                write_u64(call_state().flow.frame_cursor + 0x00000078u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                stage = ProcessStage::FlowStep06; continue;
            }
            case ProcessStage::FlowStep05: {
                call_state().flow.value_a = read_u32(call_state().flow.frame_cursor + 0x00000018u);
                call_state().flow.value_d = read_u32(call_state().flow.frame_cursor + 0x0000001cu);
                write_u32(call_state().flow.frame_cursor + 0x00000078u, static_cast<std::uint32_t>(call_state().flow.value_a));
                write_u32(call_state().flow.frame_cursor + 0x0000007cu, static_cast<std::uint32_t>(call_state().flow.value_d));
                stage = ProcessStage::FlowStep06;
                continue;
            }
            case ProcessStage::FlowStep06: {
                call_state().floating.temporary[6u] = native_double_from_binary64_bits(read_u64(0x100d63c0u));
                update_float_condition(call_state().floating.temporary[6u], call_state().floating.temporary[7u]);
                call_state().flow.value_a = (call_state().flow.value_a & 0xffff0000u) | ((call_state().floating.comparison_status) & 0xffffu);
                if (((((((call_state().flow.value_a >> 8u) & 0xffu)) & (0x00000001u)) & 0xffu) == 0u)) {
                    stage = ProcessStage::FlowStep07;
                    continue;
                }
                write_u64(0x100d63c0u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                stage = ProcessStage::FlowStep08; continue;
            }
            case ProcessStage::FlowStep07: {
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u];
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x100d63c0u));
                update_float_condition(call_state().floating.temporary[7u], native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000018u)));
                call_state().flow.value_a = (call_state().flow.value_a & 0xffff0000u) | ((call_state().floating.comparison_status) & 0xffffu);
                if (((((((call_state().flow.value_a >> 8u) & 0xffu)) & (0x00000001u)) & 0xffu) == 0u)) {
                    stage = ProcessStage::FlowStep08;
                    continue;
                }
                call_state().flow.value_a = read_u32(call_state().flow.frame_cursor + 0x00000018u);
                call_state().flow.value_d = read_u32(call_state().flow.frame_cursor + 0x0000001cu);
                write_u32(0x100d63c0u, static_cast<std::uint32_t>(call_state().flow.value_a));
                write_u32(0x100d63c4u, static_cast<std::uint32_t>(call_state().flow.value_d));
                stage = ProcessStage::FlowStep08;
                continue;
            }
            case ProcessStage::FlowStep08: {
                if ((((read_u32(0x1010609cu)) & 0xffffffffu) != ((call_state().flow.value_b) & 0xffffffffu))) {
                    stage = ProcessStage::FlowStep10;
                    continue;
                }
                if ((((((call_state().flow.value_c & 0xffu)) & (0x00000001u)) & 0xffu) == 0u)) {
                    stage = ProcessStage::FlowStep10;
                    continue;
                }
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x00000004u);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x100d6168u);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x100d6170u);
                call_state().flow.frame_cursor -= 4u; stage = ProcessStage::FlowStep83; continue;
            }
            case ProcessStage::FlowStep09: {
                { const std::uint32_t lhs = call_state().flow.frame_cursor; const std::uint32_t rhs = 0x0000000cu; const std::uint32_t result = lhs + rhs; call_state().flow.frame_cursor = result; update_add_condition( lhs, rhs, result, 32u); }
                stage = ProcessStage::FlowStep10;
                continue;
            }
            case ProcessStage::FlowStep10: {
                call_state().flow.index = read_u32(0x100d6224u);
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x100d6170u));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] - native_double_from_binary64_bits(read_u64(0x100d6168u));
                call_state().flow.value_a = read_u32((call_state().flow.index * 4u) + 0x1000f678u);
                write_u32(call_state().flow.frame_cursor + 0x00000018u, static_cast<std::uint32_t>(call_state().flow.value_a));
                truncate_native_double_to_i64_parts(call_state().floating.temporary[7u]);
                write_u32((call_state().flow.index * 4u) + 0x1000f678u, static_cast<std::uint32_t>(call_state().flow.value_a));
                call_state().flow.value_a = read_u32(0x100d5f10u);
                if ((static_cast<std::int32_t>(call_state().flow.index) >= static_cast<std::int32_t>(call_state().flow.value_a))) {
                    stage = ProcessStage::FlowStep11;
                    continue;
                }
                { const std::uint32_t old_value = call_state().flow.index; const std::uint32_t result = old_value + 1u; call_state().flow.index = result; const bool carry = call_state().flow.condition.carry; update_add_condition(old_value, 1u, result, 32u); call_state().flow.condition.carry = carry; }
                write_u32(0x100d6224u, static_cast<std::uint32_t>(call_state().flow.index));
                stage = ProcessStage::FlowStep12; continue;
            }
            case ProcessStage::FlowStep11: {
                write_u32(0x100d6224u, static_cast<std::uint32_t>(call_state().flow.value_b));
                stage = ProcessStage::FlowStep12;
                continue;
            }
            case ProcessStage::FlowStep12: {
                if ((((read_u32(0x101060a8u)) & 0xffffffffu) != ((call_state().flow.value_b) & 0xffffffffu))) {
                    stage = ProcessStage::FlowStep17;
                    continue;
                }
                if ((((read_u32(0x1010609cu)) & 0xffffffffu) != ((call_state().flow.value_b) & 0xffffffffu))) {
                    stage = ProcessStage::FlowStep17;
                    continue;
                }
                call_state().floating.temporary[7u] = static_cast<NativeDouble>(static_cast<std::int32_t>(read_u32(call_state().flow.frame_cursor + 0x00000018u)));
                call_state().flow.value_c = read_u32(0x100d6220u);
                { const std::uint32_t lhs = call_state().flow.value_c; const std::uint32_t rhs = 0x000000ffu; const std::uint32_t result = lhs & rhs; call_state().flow.value_c = result; update_logic_condition( result, 32u); }
                call_state().floating.temporary[6u] = call_state().floating.temporary[7u];
                call_state().floating.temporary[6u] = call_state().floating.temporary[6u] * native_double_from_binary64_bits(read_u64(0x1000c660u));
                call_state().floating.temporary[6u] = call_state().floating.temporary[6u] + native_double_from_binary64_bits(read_u64((call_state().flow.value_c * 8u) + 0x1000edc8u));
                write_u64(call_state().flow.frame_cursor + 0x00000050u, native_double_to_binary64_bits(call_state().floating.temporary[6u]));
                call_state().floating.temporary[6u] = call_state().floating.temporary[6u] * native_double_from_binary64_bits(read_u64(0x1000c660u));
                call_state().floating.temporary[6u] = call_state().floating.temporary[7u] - call_state().floating.temporary[6u];
                write_u64((call_state().flow.value_c * 8u) + 0x1000edc8u, native_double_to_binary64_bits(call_state().floating.temporary[6u]));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u];
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000050u));
                call_state().floating.temporary[7u] = native_double_abs(call_state().floating.temporary[7u]);
                update_float_condition(call_state().floating.temporary[7u], native_double_from_binary64_bits(read_u64(0x100d6240u)));
                call_state().flow.value_a = (call_state().flow.value_a & 0xffff0000u) | ((call_state().floating.comparison_status) & 0xffffu);
                if (((((((call_state().flow.value_a >> 8u) & 0xffu)) & (0x00000041u)) & 0xffu) != 0u)) {
                    stage = ProcessStage::FlowStep13;
                    continue;
                }
                call_state().floating.temporary[6u] = native_double_from_binary64_bits(read_u64(0x1000c650u));
                stage = ProcessStage::FlowStep14; continue;
            }
            case ProcessStage::FlowStep13: {
                call_state().floating.temporary[6u] = native_double_from_binary64_bits(read_u64(0x1000c640u));
                stage = ProcessStage::FlowStep14;
                continue;
            }
            case ProcessStage::FlowStep14: {
                call_state().floating.temporary[5u] = native_double_from_binary64_bits(read_u64(0x1000c000u));
                call_state().floating.temporary[5u] = call_state().floating.temporary[5u] - call_state().floating.temporary[6u];
                call_state().floating.temporary[5u] = call_state().floating.temporary[5u] * call_state().floating.temporary[7u];
                call_state().floating.temporary[4u] = native_double_from_binary64_bits(read_u64(0x100d6240u));
                call_state().floating.temporary[4u] = call_state().floating.temporary[4u] * call_state().floating.temporary[6u];
                call_state().floating.temporary[5u] = call_state().floating.temporary[5u] + call_state().floating.temporary[4u];
                write_u64(0x100d6240u, native_double_to_binary64_bits(call_state().floating.temporary[5u]));
                call_state().floating.temporary[6u] = call_state().floating.temporary[6u];
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u];
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x100d6240u));
                update_float_condition(call_state().floating.temporary[7u], native_double_from_binary64_bits(read_u64(0x1000c630u)));
                call_state().flow.value_a = (call_state().flow.value_a & 0xffff0000u) | ((call_state().floating.comparison_status) & 0xffffu);
                if (((((((call_state().flow.value_a >> 8u) & 0xffu)) & (0x00000041u)) & 0xffu) != 0u)) {
                    stage = ProcessStage::FlowStep15;
                    continue;
                }
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x1000c630u));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] / native_double_from_binary64_bits(read_u64(0x100d6240u));
                stage = ProcessStage::FlowStep16; continue;
            }
            case ProcessStage::FlowStep15: {
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x1000c000u));
                stage = ProcessStage::FlowStep16;
                continue;
            }
            case ProcessStage::FlowStep16: {
                call_state().floating.temporary[6u] = call_state().floating.temporary[7u];
                call_state().floating.temporary[6u] = call_state().floating.temporary[6u] * native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000050u));
                { const std::uint32_t old_value = call_state().flow.value_c; const std::uint32_t result = old_value + 1u; call_state().flow.value_c = result; const bool carry = call_state().flow.condition.carry; update_add_condition(old_value, 1u, result, 32u); call_state().flow.condition.carry = carry; }
                write_u32(0x100d6220u, static_cast<std::uint32_t>(call_state().flow.value_c));
                write_u64(call_state().flow.frame_cursor + 0x00000050u, native_double_to_binary64_bits(call_state().floating.temporary[6u]));
                write_u64(0x100d63d8u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                call_state().floating.temporary[7u] = static_cast<NativeDouble>(static_cast<std::int32_t>(read_u32(0x10106094u)));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] * native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000050u));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] * native_double_from_binary64_bits(read_u64(0x1000c4e0u));
                call_state().floating.temporary[6u] = call_state().floating.temporary[7u];
                call_state().floating.temporary[6u] = call_state().floating.temporary[6u] + native_double_from_binary64_bits(read_u64(0x100d6170u));
                write_u64(0x100d6170u, native_double_to_binary64_bits(call_state().floating.temporary[6u]));
                call_state().floating.temporary[6u] = native_double_from_binary64_bits(read_u64(0x100d6168u));
                call_state().floating.temporary[6u] = call_state().floating.temporary[6u] - call_state().floating.temporary[7u];
                write_u64(0x100d6168u, native_double_to_binary64_bits(call_state().floating.temporary[6u]));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u];
                stage = ProcessStage::FlowStep17;
                continue;
            }
            case ProcessStage::FlowStep17: {
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x100d6170u));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] - native_double_from_binary64_bits(read_u64(0x100d6168u));
                call_state().floating.temporary[7u] = native_double_abs(call_state().floating.temporary[7u]);
                update_float_condition(call_state().floating.temporary[7u], native_double_from_binary64_bits(read_u64(0x100d63d0u)));
                call_state().flow.value_a = (call_state().flow.value_a & 0xffff0000u) | ((call_state().floating.comparison_status) & 0xffffu);
                if (((((((call_state().flow.value_a >> 8u) & 0xffu)) & (0x00000041u)) & 0xffu) != 0u)) {
                    stage = ProcessStage::FlowStep18;
                    continue;
                }
                write_u64(0x100d63d0u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                stage = ProcessStage::FlowStep19; continue;
            }
            case ProcessStage::FlowStep18: {
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u];
                stage = ProcessStage::FlowStep19;
                continue;
            }
            case ProcessStage::FlowStep19: {
                #if defined(SSNATIVE_M13_NATIVE_PREFILTER_SETUP)
                fast_m13_prefilter_setup(); stage = ProcessStage::FlowStep20; continue;
                #else
                call_state().flow.value_c = read_u32(0x100d6168u);
                call_state().flow.value_a = read_u32(0x100d6170u);
                call_state().flow.value_d = read_u32(0x100d616cu);
                write_u32(call_state().flow.frame_cursor + 0x00000058u, static_cast<std::uint32_t>(call_state().flow.value_c));
                call_state().flow.value_c = read_u32(0x100d6174u);
                write_u32(call_state().flow.frame_cursor + 0x00000060u, static_cast<std::uint32_t>(call_state().flow.value_a));
                call_state().flow.value_a = read_u32(0x100d616cu);
                write_u32(call_state().flow.frame_cursor + 0x00000064u, static_cast<std::uint32_t>(call_state().flow.value_c));
                call_state().flow.value_c = read_u32(0x100d6170u);
                write_u32(call_state().flow.frame_cursor + 0x00000044u, static_cast<std::uint32_t>(call_state().flow.value_a));
                write_u32(call_state().flow.frame_cursor + 0x0000005cu, static_cast<std::uint32_t>(call_state().flow.value_d));
                call_state().flow.value_d = read_u32(0x100d6168u);
                write_u32(call_state().flow.frame_cursor + 0x00000048u, static_cast<std::uint32_t>(call_state().flow.value_c));
                call_state().flow.value_a = call_state().flow.frame_cursor + 0x00000048u;
                call_state().flow.value_c = call_state().flow.frame_cursor + 0x00000040u;
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.value_a);
                write_u32(call_state().flow.frame_cursor + 0x00000044u, static_cast<std::uint32_t>(call_state().flow.value_d));
                call_state().flow.value_d = read_u32(0x100d6174u);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.value_c);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x100d5fb8u);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x1000d760u);
                write_u32(call_state().flow.frame_cursor + 0x0000005cu, static_cast<std::uint32_t>(call_state().flow.value_d));
                fast_one_pole_stereo(0x1000d760u, 0x100d5fb8u, call_state().flow.value_c, call_state().flow.value_a);
                call_state().flow.value_d = call_state().flow.frame_cursor + 0x00000070u;
                call_state().flow.value_a = call_state().flow.frame_cursor + 0x00000068u;
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.value_d);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.value_a);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x100d5ff8u);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x1000d748u);
                fast_one_pole_stereo(0x1000d748u, 0x100d5ff8u, call_state().flow.value_a, call_state().flow.value_d); stage = ProcessStage::FlowStep20; continue;
                #endif
                stage = ProcessStage::FlowStep20;
                continue;
            }
            case ProcessStage::FlowStep20: {
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000080u));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] + native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000078u));
                { const std::uint32_t lhs = call_state().flow.frame_cursor; const std::uint32_t rhs = 0x00000020u; const std::uint32_t result = lhs + rhs; call_state().flow.frame_cursor = result; update_add_condition( lhs, rhs, result, 32u); }
                call_state().floating.temporary[7u] = native_double_abs(call_state().floating.temporary[7u]);
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] * native_double_from_binary64_bits(read_u64(0x1000c620u));
                call_state().floating.temporary[6u] = native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000048u));
                call_state().floating.temporary[6u] = call_state().floating.temporary[6u] + native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000040u));
                call_state().floating.temporary[6u] = native_double_abs(call_state().floating.temporary[6u]);
                call_state().floating.temporary[6u] = call_state().floating.temporary[6u] * native_double_from_binary64_bits(read_u64(0x1000c620u));
                write_u64(call_state().flow.frame_cursor + 0x00000070u, native_double_to_binary64_bits(call_state().floating.temporary[6u]));
                update_float_condition(call_state().floating.temporary[7u], native_double_from_binary64_bits(read_u64(0x1010ed58u)));
                call_state().flow.value_a = (call_state().flow.value_a & 0xffff0000u) | ((call_state().floating.comparison_status) & 0xffffu);
                if (((((((call_state().flow.value_a >> 8u) & 0xffu)) & (0x00000041u)) & 0xffu) != 0u)) {
                    stage = ProcessStage::FlowStep21;
                    continue;
                }
                call_state().floating.temporary[6u] = native_double_from_binary64_bits(read_u64(0x1010ed30u));
                write_u32(0x100d5f58u, static_cast<std::uint32_t>(call_state().flow.value_b));
                stage = ProcessStage::FlowStep23; continue;
            }
            case ProcessStage::FlowStep21: {
                call_state().floating.temporary[6u] = static_cast<NativeDouble>(static_cast<std::int32_t>(read_u32(0x100d635cu)));
                update_float_condition(call_state().floating.temporary[6u], native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000078u)));
                call_state().flow.value_a = (call_state().flow.value_a & 0xffff0000u) | ((call_state().floating.comparison_status) & 0xffffu);
                if (((((((call_state().flow.value_a >> 8u) & 0xffu)) & (0x00000041u)) & 0xffu) != 0u)) {
                    stage = ProcessStage::FlowStep22;
                    continue;
                }
                call_state().floating.temporary[6u] = native_double_from_binary64_bits(read_u64(0x1000c610u));
                write_u32(0x100d5f58u, static_cast<std::uint32_t>(0x00000001u));
                stage = ProcessStage::FlowStep23; continue;
            }
            case ProcessStage::FlowStep22: {
                call_state().floating.temporary[6u] = native_double_from_binary64_bits(read_u64(0x1010ed38u));
                stage = ProcessStage::FlowStep23;
                continue;
            }
            case ProcessStage::FlowStep23: {
                call_state().floating.temporary[5u] = native_double_from_binary64_bits(read_u64(0x1000c000u));
                call_state().floating.temporary[5u] = call_state().floating.temporary[5u] - call_state().floating.temporary[6u];
                call_state().floating.temporary[5u] = call_state().floating.temporary[5u] * call_state().floating.temporary[7u];
                call_state().floating.temporary[4u] = native_double_from_binary64_bits(read_u64(0x1010ed58u));
                call_state().floating.temporary[4u] = call_state().floating.temporary[4u] * call_state().floating.temporary[6u];
                call_state().floating.temporary[5u] = call_state().floating.temporary[5u] + call_state().floating.temporary[4u];
                write_u64(0x1010ed58u, native_double_to_binary64_bits(call_state().floating.temporary[5u]));
                call_state().floating.temporary[6u] = call_state().floating.temporary[6u];
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u];
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x1010ed58u));
                update_float_condition(call_state().floating.temporary[7u], native_double_from_binary64_bits(read_u64(0x100d6350u)));
                call_state().flow.value_a = (call_state().flow.value_a & 0xffff0000u) | ((call_state().floating.comparison_status) & 0xffffu);
                if (((((((call_state().flow.value_a >> 8u) & 0xffu)) & (0x00000001u)) & 0xffu) == 0u)) {
                    stage = ProcessStage::FlowStep24;
                    continue;
                }
                call_state().flow.value_c = read_u32(0x100d6350u);
                call_state().flow.value_d = read_u32(0x100d6354u);
                write_u32(0x1010ed58u, static_cast<std::uint32_t>(call_state().flow.value_c));
                write_u32(0x1010ed5cu, static_cast<std::uint32_t>(call_state().flow.value_d));
                stage = ProcessStage::FlowStep24;
                continue;
            }
            case ProcessStage::FlowStep24: {
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x1000c600u));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] / native_double_from_binary64_bits(read_u64(0x1010ed58u));
                write_u64(call_state().flow.frame_cursor + 0x00000068u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000070u));
                update_float_condition(call_state().floating.temporary[7u], native_double_from_binary64_bits(read_u64(0x1010ed10u)));
                call_state().flow.value_a = (call_state().flow.value_a & 0xffff0000u) | ((call_state().floating.comparison_status) & 0xffffu);
                if (((((((call_state().flow.value_a >> 8u) & 0xffu)) & (0x00000041u)) & 0xffu) != 0u)) {
                    stage = ProcessStage::FlowStep25;
                    continue;
                }
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x1010ece8u));
                write_u32(0x100d5f58u, static_cast<std::uint32_t>(call_state().flow.value_b));
                stage = ProcessStage::FlowStep27; continue;
            }
            case ProcessStage::FlowStep25: {
                call_state().floating.temporary[7u] = static_cast<NativeDouble>(static_cast<std::int32_t>(read_u32(0x100d635cu)));
                update_float_condition(call_state().floating.temporary[7u], native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000078u)));
                call_state().flow.value_a = (call_state().flow.value_a & 0xffff0000u) | ((call_state().floating.comparison_status) & 0xffffu);
                if (((((((call_state().flow.value_a >> 8u) & 0xffu)) & (0x00000041u)) & 0xffu) != 0u)) {
                    stage = ProcessStage::FlowStep26;
                    continue;
                }
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x1000c610u));
                write_u32(0x100d5f58u, static_cast<std::uint32_t>(0x00000001u));
                stage = ProcessStage::FlowStep27; continue;
            }
            case ProcessStage::FlowStep26: {
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x1010ecf0u));
                stage = ProcessStage::FlowStep27;
                continue;
            }
            case ProcessStage::FlowStep27: {
                call_state().floating.temporary[6u] = native_double_from_binary64_bits(read_u64(0x1000c000u));
                call_state().floating.temporary[6u] = call_state().floating.temporary[6u] - call_state().floating.temporary[7u];
                call_state().floating.temporary[6u] = call_state().floating.temporary[6u] * native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000070u));
                call_state().floating.temporary[5u] = native_double_from_binary64_bits(read_u64(0x1010ed10u));
                call_state().floating.temporary[5u] = call_state().floating.temporary[5u] * call_state().floating.temporary[7u];
                call_state().floating.temporary[6u] = call_state().floating.temporary[6u] + call_state().floating.temporary[5u];
                write_u64(0x1010ed10u, native_double_to_binary64_bits(call_state().floating.temporary[6u]));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u];
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x1010ed10u));
                update_float_condition(call_state().floating.temporary[7u], native_double_from_binary64_bits(read_u64(0x100d6350u)));
                call_state().flow.value_a = (call_state().flow.value_a & 0xffff0000u) | ((call_state().floating.comparison_status) & 0xffffu);
                if (((((((call_state().flow.value_a >> 8u) & 0xffu)) & (0x00000001u)) & 0xffu) == 0u)) {
                    stage = ProcessStage::FlowStep28;
                    continue;
                }
                call_state().flow.value_a = read_u32(0x100d6350u);
                call_state().flow.value_c = read_u32(0x100d6354u);
                write_u32(0x1010ed10u, static_cast<std::uint32_t>(call_state().flow.value_a));
                write_u32(0x1010ed14u, static_cast<std::uint32_t>(call_state().flow.value_c));
                stage = ProcessStage::FlowStep28;
                continue;
            }
            case ProcessStage::FlowStep28: {
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x1000c600u));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] / native_double_from_binary64_bits(read_u64(0x1010ed10u));
                call_state().flow.value_d = read_u32(0x101060f4u);
                call_state().flow.value_a = call_state().flow.frame_cursor + 0x00000070u;
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.value_d);
                call_state().flow.value_c = call_state().flow.frame_cursor + 0x0000006cu;
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.value_a);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.value_c);
                write_u64(call_state().flow.frame_cursor + 0x0000007cu, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                call_state().flow.frame_cursor -= 4u; fast_100095c0(); call_state().flow.frame_cursor += 4u;
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000074u));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] * native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000064u));
                call_state().flow.value_c = read_u32(0x100d688cu);
                call_state().flow.value_d = call_state().flow.frame_cursor + 0x00000054u;
                call_state().flow.value_a = call_state().flow.frame_cursor + 0x0000004cu;
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.value_d);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.value_a);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.value_c);
                write_u64(call_state().flow.frame_cursor + 0x00000070u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000080u));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] * native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000078u));
                write_u64(call_state().flow.frame_cursor + 0x00000078u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000088u));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] * native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000058u));
                write_u64(call_state().flow.frame_cursor + 0x00000058u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000088u));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] * native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000060u));
                write_u64(call_state().flow.frame_cursor + 0x00000060u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                call_state().flow.frame_cursor -= 4u; fast_10009070(); call_state().flow.frame_cursor += 4u;
                call_state().flow.value_d = call_state().flow.frame_cursor + 0x00000060u;
                call_state().flow.value_a = call_state().flow.frame_cursor + 0x00000058u;
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.value_d);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.value_a);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x100d5fd8u);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x1000d760u);
                fast_one_pole_stereo(0x1000d760u, 0x100d5fd8u, call_state().flow.value_a, call_state().flow.value_d);
                call_state().flow.value_c = call_state().flow.frame_cursor + 0x00000088u;
                call_state().flow.value_d = call_state().flow.frame_cursor + 0x00000080u;
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.value_c);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.value_d);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x100d6018u);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x1000d748u);
                fast_one_pole_stereo(0x1000d748u, 0x100d6018u, call_state().flow.value_d, call_state().flow.value_c);
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x1010ece0u));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] * native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000078u));
                call_state().flow.value_a = read_u32(0x1010609cu);
                { const std::uint32_t lhs = call_state().flow.frame_cursor; const std::uint32_t rhs = 0x00000038u; const std::uint32_t result = lhs + rhs; call_state().flow.frame_cursor = result; update_add_condition( lhs, rhs, result, 32u); }
                { const std::uint32_t lhs = call_state().flow.value_a; const std::uint32_t rhs = call_state().flow.value_b; update_sub_condition(lhs, rhs, lhs - rhs, 32u); }
                write_u64(call_state().flow.frame_cursor + 0x00000040u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x1010ece0u));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] * native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000048u));
                write_u64(call_state().flow.frame_cursor + 0x00000048u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x1010ed28u));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] * native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000058u));
                write_u64(call_state().flow.frame_cursor + 0x00000058u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x1010ed28u));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] * native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000060u));
                write_u64(call_state().flow.frame_cursor + 0x00000060u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                if (!call_state().flow.condition.zero) {
                    stage = ProcessStage::FlowStep34;
                    continue;
                }
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x100d6170u));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] * native_double_from_binary64_bits(read_u64(0x1000c5f0u));
                { const std::uint32_t lhs = read_u32(0x1010607cu); const std::uint32_t rhs = call_state().flow.value_b; update_sub_condition(lhs, rhs, lhs - rhs, 32u); }
                write_u64(0x100d6170u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x100d6168u));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] * native_double_from_binary64_bits(read_u64(0x1000c5f0u));
                if (call_state().flow.condition.zero) {
                    stage = ProcessStage::FlowStep29;
                    continue;
                }
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u];
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000040u));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] - native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000058u));
                call_state().floating.temporary[6u] = native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000048u));
                call_state().floating.temporary[6u] = call_state().floating.temporary[6u] - native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000060u));
                stage = ProcessStage::FlowStep30; continue;
            }
            case ProcessStage::FlowStep29: {
                call_state().floating.temporary[6u] = native_double_from_binary64_bits(read_u64(0x100d6170u));
                stage = ProcessStage::FlowStep30;
                continue;
            }
            case ProcessStage::FlowStep30: {
                #if defined(SSNATIVE_M13_NATIVE_STATE_OUTPUT)
                fast_m13_state_output(call_state().floating.temporary[6u], call_state().floating.temporary[7u]); stage = ProcessStage::FlowStep31; continue;
                #else
                call_state().floating.temporary[5u] = native_double_from_binary64_bits(read_u64(0x100d6110u));
                call_state().floating.temporary[5u] = call_state().floating.temporary[5u] * native_double_from_binary64_bits(read_u64(0x1004af78u));
                call_state().flow.value_c = read_u32(call_state().flow.frame_cursor + 0x0000006cu);
                call_state().flow.value_d = read_u32(call_state().flow.frame_cursor + 0x00000070u);
                write_u32(0x100d6854u, static_cast<std::uint32_t>(call_state().flow.value_c));
                call_state().flow.value_c = read_u32(0x100d6110u);
                call_state().floating.temporary[6u] = call_state().floating.temporary[6u] - call_state().floating.temporary[5u];
                call_state().floating.temporary[5u] = native_double_from_binary64_bits(read_u64(0x100d6118u));
                call_state().floating.temporary[5u] = call_state().floating.temporary[5u] * native_double_from_binary64_bits(read_u64(0x1004af80u));
                write_u32(0x100d6858u, static_cast<std::uint32_t>(call_state().flow.value_d));
                call_state().flow.value_d = read_u32(0x100d6114u);
                call_state().flow.value_a = read_u32(call_state().flow.frame_cursor + 0x00000068u);
                call_state().floating.temporary[6u] = call_state().floating.temporary[6u] - call_state().floating.temporary[5u];
                write_u32(0x100d6850u, static_cast<std::uint32_t>(call_state().flow.value_a));
                call_state().flow.value_a = read_u32(call_state().flow.frame_cursor + 0x00000074u);
                write_u32(0x100d685cu, static_cast<std::uint32_t>(call_state().flow.value_a));
                call_state().flow.value_a = read_u32(0x100d6128u);
                write_u64(0x100d6108u, native_double_to_binary64_bits(call_state().floating.temporary[6u]));
                call_state().floating.temporary[5u] = native_double_from_binary64_bits(read_u64(0x1004af90u));
                call_state().floating.temporary[5u] = call_state().floating.temporary[5u] * native_double_from_binary64_bits(read_u64(0x100d6118u));
                call_state().floating.temporary[4u] = native_double_from_binary64_bits(read_u64(0x1004af88u));
                call_state().floating.temporary[4u] = call_state().floating.temporary[4u] * native_double_from_binary64_bits(read_u64(0x100d6110u));
                write_u32(0x100d6118u, static_cast<std::uint32_t>(call_state().flow.value_c));
                call_state().flow.value_c = read_u32(0x100d612cu);
                call_state().floating.temporary[5u] = call_state().floating.temporary[5u] + call_state().floating.temporary[4u];
                write_u32(0x100d611cu, static_cast<std::uint32_t>(call_state().flow.value_d));
                call_state().floating.temporary[5u] = call_state().floating.temporary[5u] + call_state().floating.temporary[6u];
                write_u64(0x100d6170u, native_double_to_binary64_bits(call_state().floating.temporary[5u]));
                write_u64(0x100d6110u, native_double_to_binary64_bits(call_state().floating.temporary[6u]));
                call_state().floating.temporary[6u] = native_double_from_binary64_bits(read_u64(0x100d6128u));
                call_state().floating.temporary[6u] = call_state().floating.temporary[6u] * native_double_from_binary64_bits(read_u64(0x1004af78u));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] - call_state().floating.temporary[6u];
                call_state().floating.temporary[6u] = native_double_from_binary64_bits(read_u64(0x100d6130u));
                call_state().floating.temporary[6u] = call_state().floating.temporary[6u] * native_double_from_binary64_bits(read_u64(0x1004af80u));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] - call_state().floating.temporary[6u];
                write_u64(0x100d6120u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                call_state().floating.temporary[6u] = native_double_from_binary64_bits(read_u64(0x100d6130u));
                call_state().floating.temporary[6u] = call_state().floating.temporary[6u] * native_double_from_binary64_bits(read_u64(0x1004af90u));
                call_state().floating.temporary[5u] = native_double_from_binary64_bits(read_u64(0x100d6128u));
                call_state().floating.temporary[5u] = call_state().floating.temporary[5u] * native_double_from_binary64_bits(read_u64(0x1004af88u));
                write_u32(0x100d6130u, static_cast<std::uint32_t>(call_state().flow.value_a));
                call_state().flow.value_a = read_u32(0x10106090u);
                call_state().floating.temporary[6u] = call_state().floating.temporary[6u] + call_state().floating.temporary[5u];
                { const std::uint32_t lhs = call_state().flow.value_a; const std::uint32_t rhs = call_state().flow.value_b; update_sub_condition(lhs, rhs, lhs - rhs, 32u); }
                write_u32(0x100d6134u, static_cast<std::uint32_t>(call_state().flow.value_c));
                call_state().floating.temporary[6u] = call_state().floating.temporary[6u] + call_state().floating.temporary[7u];
                write_u64(0x100d6168u, native_double_to_binary64_bits(call_state().floating.temporary[6u]));
                write_u64(0x100d6128u, native_double_to_binary64_bits(call_state().floating.temporary[7u])); stage = ProcessStage::FlowStep31; continue;
                #endif
                stage = ProcessStage::FlowStep31;
                continue;
            }
            case ProcessStage::FlowStep31: {
                if ((call_state().flow.condition.zero || call_state().flow.condition.negative != call_state().flow.condition.overflow)) {
                    stage = ProcessStage::FlowStep33;
                    continue;
                }
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x00000002u);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x100d6170u);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x100d6168u);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x100d7660u);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x100d76a0u);
                fast_biquad_stereo(0x100d76a0u, 0x100d7660u, 0x100d6168u, 0x100d6170u);
                call_state().flow.value_a = (call_state().flow.value_a & 0xffffff00u) | ((read_u32(0x101060f0u)) & 0xffu);
                { const std::uint32_t lhs = call_state().flow.frame_cursor; const std::uint32_t rhs = 0x00000014u; const std::uint32_t result = lhs + rhs; call_state().flow.frame_cursor = result; update_add_condition( lhs, rhs, result, 32u); }
                if ((((((call_state().flow.value_a & 0xffu)) & (0x00000040u)) & 0xffu) == 0u)) {
                    stage = ProcessStage::FlowStep33;
                    continue;
                }
                call_state().flow.index = 0x1000d5b8u;
                stage = ProcessStage::FlowStep32;
                continue;
            }
            case ProcessStage::FlowStep32: {
                call_state().flow.value_d = read_u32(call_state().flow.index);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x00000002u);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x100d6170u);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x100d6168u);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.value_d);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x100d76a0u);
                fast_biquad_stereo(0x100d76a0u, call_state().flow.value_d, 0x100d6168u, 0x100d6170u);
                { const std::uint32_t lhs = call_state().flow.index; const std::uint32_t rhs = 0x00000004u; const std::uint32_t result = lhs + rhs; call_state().flow.index = result; update_add_condition( lhs, rhs, result, 32u); }
                { const std::uint32_t lhs = call_state().flow.frame_cursor; const std::uint32_t rhs = 0x00000014u; const std::uint32_t result = lhs + rhs; call_state().flow.frame_cursor = result; update_add_condition( lhs, rhs, result, 32u); }
                if ((static_cast<std::int32_t>(call_state().flow.index) < static_cast<std::int32_t>(0x1000d5c4u))) {
                    stage = ProcessStage::FlowStep32;
                    continue;
                }
                stage = ProcessStage::FlowStep33;
                continue;
            }
            case ProcessStage::FlowStep33: {
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x100d63b0u));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] * native_double_from_binary64_bits(read_u64(0x100d6170u));
                call_state().flow.value_a = read_u32(0x1010609cu);
                write_u64(0x100d6170u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x100d63b0u));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] * native_double_from_binary64_bits(read_u64(0x100d6168u));
                write_u64(0x100d6168u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                stage = ProcessStage::FlowStep35; continue;
            }
            case ProcessStage::FlowStep34: {
                write_u32(0x100d6850u, static_cast<std::uint32_t>(0x00000000u));
                write_u32(0x100d6854u, static_cast<std::uint32_t>(0x00000000u));
                write_u32(0x100d6858u, static_cast<std::uint32_t>(0x00000000u));
                write_u32(0x100d685cu, static_cast<std::uint32_t>(0x00000000u));
                stage = ProcessStage::FlowStep35;
                continue;
            }
            case ProcessStage::FlowStep35: {
                if ((((call_state().flow.value_a) & 0xffffffffu) != ((call_state().flow.value_b) & 0xffffffffu))) {
                    stage = ProcessStage::FlowStep38;
                    continue;
                }
                call_state().flow.value_c = read_u32(0x101060b8u);
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x100d60d0u));
                if ((((call_state().flow.value_c) & 0xffffffffu) == ((call_state().flow.value_b) & 0xffffffffu))) {
                    stage = ProcessStage::FlowStep36;
                    continue;
                }
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] * native_double_from_binary64_bits(read_u64(0x1000c5e0u));
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x100d6170u)) - call_state().floating.temporary[7u];
                write_u64(0x100d60c8u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                call_state().floating.temporary[6u] = native_double_from_binary64_bits(read_u64(0x100d60d0u));
                call_state().floating.temporary[6u] = call_state().floating.temporary[6u] * native_double_from_binary64_bits(read_u64(0x1000c5d0u));
                call_state().floating.temporary[5u] = call_state().floating.temporary[7u];
                call_state().floating.temporary[5u] = call_state().floating.temporary[5u] * native_double_from_binary64_bits(read_u64(0x1000c5c0u));
                call_state().floating.temporary[6u] = call_state().floating.temporary[6u] + call_state().floating.temporary[5u];
                write_u64(0x100d6170u, native_double_to_binary64_bits(call_state().floating.temporary[6u]));
                write_u64(0x100d60d0u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x100d60e0u));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] * native_double_from_binary64_bits(read_u64(0x1000c5e0u));
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x100d6168u)) - call_state().floating.temporary[7u];
                write_u64(0x100d60d8u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                call_state().floating.temporary[6u] = native_double_from_binary64_bits(read_u64(0x100d60e0u));
                call_state().floating.temporary[6u] = call_state().floating.temporary[6u] * native_double_from_binary64_bits(read_u64(0x1000c5d0u));
                call_state().floating.temporary[5u] = call_state().floating.temporary[7u];
                call_state().floating.temporary[5u] = call_state().floating.temporary[5u] * native_double_from_binary64_bits(read_u64(0x1000c5c0u));
                stage = ProcessStage::FlowStep37; continue;
            }
            case ProcessStage::FlowStep36: {
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] * native_double_from_binary64_bits(read_u64(0x1000c5b0u));
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x100d6170u)) - call_state().floating.temporary[7u];
                write_u64(0x100d60c8u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                call_state().floating.temporary[6u] = native_double_from_binary64_bits(read_u64(0x100d60d0u));
                call_state().floating.temporary[6u] = call_state().floating.temporary[6u] * native_double_from_binary64_bits(read_u64(0x1000c5a0u));
                call_state().floating.temporary[5u] = call_state().floating.temporary[7u];
                call_state().floating.temporary[5u] = call_state().floating.temporary[5u] * native_double_from_binary64_bits(read_u64(0x1000c590u));
                call_state().floating.temporary[6u] = call_state().floating.temporary[6u] + call_state().floating.temporary[5u];
                write_u64(0x100d6170u, native_double_to_binary64_bits(call_state().floating.temporary[6u]));
                write_u64(0x100d60d0u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x100d60e0u));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] * native_double_from_binary64_bits(read_u64(0x1000c5b0u));
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x100d6168u)) - call_state().floating.temporary[7u];
                write_u64(0x100d60d8u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                call_state().floating.temporary[6u] = native_double_from_binary64_bits(read_u64(0x100d60e0u));
                call_state().floating.temporary[6u] = call_state().floating.temporary[6u] * native_double_from_binary64_bits(read_u64(0x1000c5a0u));
                call_state().floating.temporary[5u] = call_state().floating.temporary[7u];
                call_state().floating.temporary[5u] = call_state().floating.temporary[5u] * native_double_from_binary64_bits(read_u64(0x1000c590u));
                stage = ProcessStage::FlowStep37;
                continue;
            }
            case ProcessStage::FlowStep37: {
                call_state().floating.temporary[6u] = call_state().floating.temporary[6u] + call_state().floating.temporary[5u];
                write_u64(0x100d6168u, native_double_to_binary64_bits(call_state().floating.temporary[6u]));
                write_u64(0x100d60e0u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                stage = ProcessStage::FlowStep38;
                continue;
            }
            case ProcessStage::FlowStep38: {
                call_state().flow.value_c = read_u32(0x101060f0u);
                if (((((((call_state().flow.value_c >> 8u) & 0xffu)) & (0x00000002u)) & 0xffu) == 0u)) {
                    stage = ProcessStage::FlowStep39;
                    continue;
                }
                if ((((call_state().flow.value_a) & 0xffffffffu) == ((call_state().flow.value_b) & 0xffffffffu))) {
                    stage = ProcessStage::FlowStep45;
                    continue;
                }
                stage = ProcessStage::FlowStep39;
                continue;
            }
            case ProcessStage::FlowStep39: {
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x100d6168u));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] * native_double_from_binary64_bits(read_u64(0x1000c580u));
                write_u64(0x100d6a68u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x100d6170u));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] * native_double_from_binary64_bits(read_u64(0x1000c580u));
                write_u64(0x100d6a60u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                call_state().flow.frame_cursor -= 4u; fast_10007fe0(); call_state().flow.frame_cursor += 4u;
                fast_level_detector((read_u8(0x101060f0u) & 8u) != 0u);
                stage = ProcessStage::FlowStep44; continue;
                if (((((read_u8(0x101060f0u)) & (0x00000008u)) & 0xffu) == 0u)) {
                    stage = ProcessStage::FlowStep41;
                    continue;
                }
                { const std::uint32_t lhs = call_state().flow.index; const std::uint32_t rhs = call_state().flow.index; const std::uint32_t result = lhs ^ rhs; call_state().flow.index = result; update_logic_condition( result, 32u); }
                call_state().flow.pointer = 0x100d6368u;
                stage = ProcessStage::FlowStep40;
                continue;
            }
            case ProcessStage::FlowStep40: {
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(call_state().flow.pointer + static_cast<std::uint32_t>(-8)));
                call_state().floating.temporary[7u] = native_double_abs(call_state().floating.temporary[7u]);
                write_u64(call_state().flow.frame_cursor + 0x00000080u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(call_state().flow.pointer));
                call_state().floating.temporary[7u] = native_double_abs(call_state().floating.temporary[7u]);
                write_u64(call_state().flow.frame_cursor + 0x00000018u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                call_state().flow.value_c = read_u32(call_state().flow.frame_cursor + 0x0000001cu);
                call_state().flow.value_d = read_u32(call_state().flow.frame_cursor + 0x00000018u);
                call_state().flow.value_a = (call_state().flow.index * 8u) + 0x100d5f28u;
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.index);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.value_a);
                call_state().flow.value_a = read_u32(call_state().flow.frame_cursor + 0x0000008cu);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.value_c);
                call_state().flow.value_c = read_u32(call_state().flow.frame_cursor + 0x0000008cu);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.value_d);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.value_a);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.value_c);
                call_state().floating.temporary[7u] = fast_rms_envelope(
                    guest_f64(call_state().flow.frame_cursor), guest_f64(call_state().flow.frame_cursor + 8u),
                    read_u32(call_state().flow.frame_cursor + 16u), read_u32(call_state().flow.frame_cursor + 20u));

                { const std::uint32_t lhs = call_state().flow.frame_cursor; const std::uint32_t rhs = 0x00000018u; const std::uint32_t result = lhs + rhs; call_state().flow.frame_cursor = result; update_add_condition( lhs, rhs, result, 32u); }
                write_u64((call_state().flow.index * 8u) + 0x100d5ec8u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                { const std::uint32_t lhs = call_state().flow.pointer; const std::uint32_t rhs = 0x00000010u; const std::uint32_t result = lhs + rhs; call_state().flow.pointer = result; update_add_condition( lhs, rhs, result, 32u); }
                { const std::uint32_t old_value = call_state().flow.index; const std::uint32_t result = old_value + 1u; call_state().flow.index = result; const bool carry = call_state().flow.condition.carry; update_add_condition(old_value, 1u, result, 32u); call_state().flow.condition.carry = carry; }
                if ((static_cast<std::int32_t>(call_state().flow.pointer) < static_cast<std::int32_t>(0x100d63b8u))) {
                    stage = ProcessStage::FlowStep40;
                    continue;
                }
                stage = ProcessStage::FlowStep44; continue;
            }
            case ProcessStage::FlowStep41: {
                call_state().flow.value_d = 0x100d5ec8u;
                call_state().flow.value_c = 0x100d6368u;
                stage = ProcessStage::FlowStep42;
                continue;
            }
            case ProcessStage::FlowStep42: {
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(call_state().flow.value_c + static_cast<std::uint32_t>(-8)));
                call_state().floating.temporary[7u] = native_double_abs(call_state().floating.temporary[7u]);
                call_state().floating.temporary[6u] = native_double_from_binary64_bits(read_u64(call_state().flow.value_c));
                call_state().floating.temporary[6u] = native_double_abs(call_state().floating.temporary[6u]);
                write_u64(call_state().flow.frame_cursor + 0x00000018u, native_double_to_binary64_bits(call_state().floating.temporary[6u]));
                update_float_condition(call_state().floating.temporary[7u], native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000018u)));
                call_state().flow.value_a = (call_state().flow.value_a & 0xffff0000u) | ((call_state().floating.comparison_status) & 0xffffu);
                if (((((((call_state().flow.value_a >> 8u) & 0xffu)) & (0x00000041u)) & 0xffu) == 0u)) {
                    stage = ProcessStage::FlowStep43;
                    continue;
                }
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u];
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000018u));
                stage = ProcessStage::FlowStep43;
                continue;
            }
            case ProcessStage::FlowStep43: {
                write_u64(call_state().flow.value_d, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                { const std::uint32_t lhs = call_state().flow.value_c; const std::uint32_t rhs = 0x00000010u; const std::uint32_t result = lhs + rhs; call_state().flow.value_c = result; update_add_condition( lhs, rhs, result, 32u); }
                { const std::uint32_t lhs = call_state().flow.value_d; const std::uint32_t rhs = 0x00000008u; const std::uint32_t result = lhs + rhs; call_state().flow.value_d = result; update_add_condition( lhs, rhs, result, 32u); }
                if ((static_cast<std::int32_t>(call_state().flow.value_c) < static_cast<std::int32_t>(0x100d63b8u))) {
                    stage = ProcessStage::FlowStep42;
                    continue;
                }
                stage = ProcessStage::FlowStep44;
                continue;
            }
            case ProcessStage::FlowStep44: {
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x00000004u);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.value_b);
                fast_dynamics_range(call_state().flow.value_b, 4u);
                call_state().flow.value_d = read_u32(0x10106088u);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.value_d);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x1000ed80u);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x1000ed88u);
                fast_smooth_min(0x1000ed88u, 0x1000ed80u, static_cast<std::int32_t>(call_state().flow.value_d));
                call_state().flow.value_a = read_u32(0x101060ecu);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.value_a);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x1000ed90u);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x1000ed88u);
                fast_smooth_min(0x1000ed88u, 0x1000ed90u, static_cast<std::int32_t>(call_state().flow.value_a));
                call_state().flow.value_c = read_u32(0x101060e8u);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.value_c);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x1000ed98u);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x1000ed90u);
                fast_smooth_min(0x1000ed90u, 0x1000ed98u, static_cast<std::int32_t>(call_state().flow.value_c));
                call_state().flow.value_d = read_u32(0x101060e4u);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.value_d);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x1000eda0u);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x1000ed98u);
                fast_smooth_min(0x1000ed98u, 0x1000eda0u, static_cast<std::int32_t>(call_state().flow.value_d));
                call_state().flow.value_a = read_u32(0x1010609cu);
                { const std::uint32_t lhs = call_state().flow.frame_cursor; const std::uint32_t rhs = 0x00000038u; const std::uint32_t result = lhs + rhs; call_state().flow.frame_cursor = result; update_add_condition( lhs, rhs, result, 32u); }
                if ((((call_state().flow.value_a) & 0xffffffffu) != ((call_state().flow.value_b) & 0xffffffffu))) {
                    stage = ProcessStage::FlowStep64;
                    continue;
                }
                fast_band_delay_mix();
                #if defined(SSNATIVE_M13_NATIVE_BAND_POST)
                fast_m13_band_post(); stage = ProcessStage::FlowStep48; continue;
                #else
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x100d6800u));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] - native_double_from_binary64_bits(read_u64(0x100d6810u));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] + native_double_from_binary64_bits(read_u64(0x100d6820u));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] - native_double_from_binary64_bits(read_u64(0x100d6830u));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] + native_double_from_binary64_bits(read_u64(0x100d6840u));
                call_state().floating.temporary[6u] = native_double_from_binary64_bits(read_u64(0x100d6808u));
                call_state().floating.temporary[6u] = call_state().floating.temporary[6u] - native_double_from_binary64_bits(read_u64(0x100d6818u));
                call_state().floating.temporary[6u] = call_state().floating.temporary[6u] + native_double_from_binary64_bits(read_u64(0x100d6828u));
                call_state().floating.temporary[6u] = call_state().floating.temporary[6u] - native_double_from_binary64_bits(read_u64(0x100d6838u));
                call_state().floating.temporary[6u] = call_state().floating.temporary[6u] + native_double_from_binary64_bits(read_u64(0x100d6848u));
                write_u64(call_state().flow.frame_cursor + 0x00000080u, native_double_to_binary64_bits(call_state().floating.temporary[6u]));
                call_state().flow.value_d = read_u32(call_state().flow.frame_cursor + 0x00000080u);
                call_state().flow.value_a = read_u32(call_state().flow.frame_cursor + 0x00000084u);
                write_u64(0x100d6170u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                call_state().flow.pointer = read_u32(call_state().flow.frame_cursor + 0x00000010u);
                write_u32(0x100d6168u, static_cast<std::uint32_t>(call_state().flow.value_d));
                write_u32(0x100d616cu, static_cast<std::uint32_t>(call_state().flow.value_a));
                { const std::uint32_t lhs = call_state().flow.value_b; const std::uint32_t rhs = call_state().flow.value_b; const std::uint32_t result = lhs ^ rhs; call_state().flow.value_b = result; update_logic_condition( result, 32u); } stage = ProcessStage::FlowStep45; continue;
                #endif
                stage = ProcessStage::FlowStep45;
                continue;
            }
            case ProcessStage::FlowStep45: {
                call_state().flow.value_c = read_u32(0x100d6168u);
                call_state().flow.value_a = read_u32(0x100d6170u);
                call_state().flow.value_d = read_u32(0x100d616cu);
                write_u32(call_state().flow.frame_cursor + 0x00000028u, static_cast<std::uint32_t>(call_state().flow.value_c));
                call_state().flow.value_c = read_u32(0x100d6174u);
                write_u32(call_state().flow.frame_cursor + 0x00000038u, static_cast<std::uint32_t>(call_state().flow.value_a));
                call_state().flow.value_a = read_u32(0x100d616cu);
                write_u32(call_state().flow.frame_cursor + 0x0000003cu, static_cast<std::uint32_t>(call_state().flow.value_c));
                call_state().flow.value_c = read_u32(0x100d6170u);
                write_u32(call_state().flow.frame_cursor + 0x00000024u, static_cast<std::uint32_t>(call_state().flow.value_a));
                write_u32(call_state().flow.frame_cursor + 0x0000002cu, static_cast<std::uint32_t>(call_state().flow.value_d));
                call_state().flow.value_d = read_u32(0x100d6168u);
                write_u32(call_state().flow.frame_cursor + 0x00000030u, static_cast<std::uint32_t>(call_state().flow.value_c));
                call_state().flow.value_a = call_state().flow.frame_cursor + 0x00000028u;
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x00000002u);
                call_state().flow.value_c = call_state().flow.frame_cursor + 0x0000003cu;
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.value_a);
                write_u32(call_state().flow.frame_cursor + 0x00000028u, static_cast<std::uint32_t>(call_state().flow.value_d));
                call_state().flow.value_d = read_u32(0x100d6174u);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.value_c);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x100d7840u);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x1000d590u);
                write_u32(call_state().flow.frame_cursor + 0x00000048u, static_cast<std::uint32_t>(call_state().flow.value_d));
                call_state().flow.frame_cursor -= 4u; fast_10008ac0(); call_state().flow.frame_cursor += 4u;
                call_state().flow.value_d = call_state().flow.frame_cursor + 0x00000034u;
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x00000002u);
                call_state().flow.value_a = call_state().flow.frame_cursor + 0x00000048u;
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.value_d);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.value_a);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x100d7880u);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x1000d568u);
                fast_biquad_stereo(0x1000d568u, 0x100d7880u, call_state().flow.value_a, call_state().flow.value_d);
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000060u));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] * native_double_from_binary64_bits(read_u64(0x100d67e8u));
                { const std::uint32_t lhs = call_state().flow.frame_cursor; const std::uint32_t rhs = 0x00000028u; const std::uint32_t result = lhs + rhs; call_state().flow.frame_cursor = result; update_add_condition( lhs, rhs, result, 32u); }
                write_u64(call_state().flow.frame_cursor + 0x00000038u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000028u));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] * native_double_from_binary64_bits(read_u64(0x100d67e8u));
                write_u64(call_state().flow.frame_cursor + 0x00000028u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000030u));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] * native_double_from_binary64_bits(read_u64(0x100d67e8u));
                write_u64(call_state().flow.frame_cursor + 0x00000030u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000020u));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] * native_double_from_binary64_bits(read_u64(0x100d67e8u));
                write_u64(call_state().flow.frame_cursor + 0x00000020u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000038u));
                call_state().floating.temporary[7u] = native_double_abs(call_state().floating.temporary[7u]);
                write_u64(0x100d5ef0u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000028u));
                call_state().floating.temporary[7u] = native_double_abs(call_state().floating.temporary[7u]);
                call_state().floating.temporary[6u] = native_double_from_binary64_bits(read_u64(0x100d5ef0u));
                update_float_condition(call_state().floating.temporary[6u], call_state().floating.temporary[7u]);
                call_state().flow.value_a = (call_state().flow.value_a & 0xffff0000u) | ((call_state().floating.comparison_status) & 0xffffu);
                if (((((((call_state().flow.value_a >> 8u) & 0xffu)) & (0x00000041u)) & 0xffu) != 0u)) {
                    stage = ProcessStage::FlowStep46;
                    continue;
                }
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u];
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x100d5ef0u));
                stage = ProcessStage::FlowStep46;
                continue;
            }
            case ProcessStage::FlowStep46: {
                write_u64(0x100d5ef0u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000030u));
                call_state().floating.temporary[7u] = native_double_abs(call_state().floating.temporary[7u]);
                write_u64(0x100d5ef8u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000020u));
                call_state().floating.temporary[7u] = native_double_abs(call_state().floating.temporary[7u]);
                call_state().floating.temporary[6u] = native_double_from_binary64_bits(read_u64(0x100d5ef8u));
                update_float_condition(call_state().floating.temporary[6u], call_state().floating.temporary[7u]);
                call_state().flow.value_a = (call_state().flow.value_a & 0xffff0000u) | ((call_state().floating.comparison_status) & 0xffffu);
                if (((((((call_state().flow.value_a >> 8u) & 0xffu)) & (0x00000041u)) & 0xffu) != 0u)) {
                    stage = ProcessStage::FlowStep47;
                    continue;
                }
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u];
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x100d5ef8u));
                stage = ProcessStage::FlowStep47;
                continue;
            }
            case ProcessStage::FlowStep47: {
                write_u64(0x100d5ef8u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x00000006u);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x00000005u);
                fast_dynamics_range(5u, 6u);
                { const std::uint32_t lhs = call_state().flow.frame_cursor; const std::uint32_t rhs = 0x00000008u; const std::uint32_t result = lhs + rhs; call_state().flow.frame_cursor = result; update_add_condition( lhs, rhs, result, 32u); }
                stage = ProcessStage::FlowStep48;
                continue;
            }
            case ProcessStage::FlowStep48: {
                #if defined(SSNATIVE_M13_NATIVE_DELAY_OUTPUT)
                fast_m13_delay_output(); stage = ProcessStage::FlowStep51; continue;
                #else
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x1000edb0u));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] * native_double_from_binary64_bits(read_u64(0x1000c570u));
                call_state().floating.temporary[6u] = native_double_from_binary64_bits(read_u64(0x1004af00u));
                call_state().floating.temporary[6u] = call_state().floating.temporary[6u] * native_double_from_binary64_bits(read_u64(0x1000c560u));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] + call_state().floating.temporary[6u];
                write_u64(0x1004af00u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x1000eda8u));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] * native_double_from_binary64_bits(read_u64(0x1000c570u));
                call_state().floating.temporary[6u] = native_double_from_binary64_bits(read_u64(0x1004aef8u));
                call_state().floating.temporary[6u] = call_state().floating.temporary[6u] * native_double_from_binary64_bits(read_u64(0x1000c560u));
                call_state().flow.value_c = read_u32(0x100d5f20u);
                call_state().flow.value_d = read_u32(call_state().flow.frame_cursor + 0x00000034u);
                call_state().flow.value_a = (call_state().flow.value_c * 8u);
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] + call_state().floating.temporary[6u];
                { const std::uint32_t lhs = call_state().flow.value_a; const std::uint32_t rhs = call_state().flow.value_c; const std::uint32_t result = lhs - rhs; call_state().flow.value_a = result; update_sub_condition( lhs, rhs, result, 32u); }
                call_state().flow.value_c = read_u32(call_state().flow.frame_cursor + 0x00000030u);
                { const unsigned count = (0x00000004u) & 31u; if (count != 0u) { const std::uint32_t old_value = call_state().flow.value_a; const std::uint32_t result = old_value << count; call_state().flow.value_a = result; update_logic_condition(result, 32u); } }
                write_u64(0x1004aef8u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(call_state().flow.value_a + 0x1004d318u));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] * native_double_from_binary64_bits(read_u64(0x1004af00u));
                write_u32(call_state().flow.value_a + 0x1004d318u, static_cast<std::uint32_t>(call_state().flow.value_c));
                write_u32(call_state().flow.value_a + 0x1004d31cu, static_cast<std::uint32_t>(call_state().flow.value_d));
                call_state().floating.temporary[6u] = native_double_from_binary64_bits(read_u64(call_state().flow.value_a + 0x1004d310u));
                call_state().floating.temporary[5u] = native_double_from_binary64_bits(read_u64(0x1004aef8u));
                call_state().flow.value_c = read_u32(call_state().flow.frame_cursor + 0x00000038u);
                call_state().flow.value_d = read_u32(call_state().flow.frame_cursor + 0x0000003cu);
                call_state().floating.temporary[5u] = call_state().floating.temporary[5u] * call_state().floating.temporary[6u];
                write_u32(call_state().flow.value_a + 0x1004d310u, static_cast<std::uint32_t>(call_state().flow.value_c));
                write_u32(call_state().flow.value_a + 0x1004d314u, static_cast<std::uint32_t>(call_state().flow.value_d));
                call_state().flow.value_c = read_u32(call_state().flow.frame_cursor + 0x00000020u);
                call_state().flow.value_d = read_u32(call_state().flow.frame_cursor + 0x00000024u);
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] - call_state().floating.temporary[5u];
                call_state().floating.temporary[6u] = call_state().floating.temporary[6u];
                call_state().floating.temporary[6u] = native_double_from_binary64_bits(read_u64(call_state().flow.value_a + 0x1004d350u));
                call_state().floating.temporary[5u] = native_double_from_binary64_bits(read_u64(0x1004af00u));
                call_state().floating.temporary[5u] = call_state().floating.temporary[5u] * call_state().floating.temporary[6u];
                write_u32(call_state().flow.value_a + 0x1004d350u, static_cast<std::uint32_t>(call_state().flow.value_c));
                write_u32(call_state().flow.value_a + 0x1004d354u, static_cast<std::uint32_t>(call_state().flow.value_d));
                call_state().flow.value_c = read_u32(call_state().flow.value_a + 0x1004d348u);
                call_state().flow.value_d = read_u32(call_state().flow.value_a + 0x1004d34cu);
                write_u64(0x100d6168u, native_double_to_binary64_bits(call_state().floating.temporary[5u]));
                write_u32(call_state().flow.frame_cursor + 0x00000050u, static_cast<std::uint32_t>(call_state().flow.value_c));
                write_u32(call_state().flow.frame_cursor + 0x00000054u, static_cast<std::uint32_t>(call_state().flow.value_d));
                call_state().floating.temporary[6u] = call_state().floating.temporary[6u];
                call_state().floating.temporary[6u] = static_cast<NativeDouble>(static_cast<std::int32_t>(read_u32(0x101060f8u)));
                call_state().flow.value_c = read_u32(call_state().flow.frame_cursor + 0x00000028u);
                call_state().flow.value_d = read_u32(call_state().flow.frame_cursor + 0x0000002cu);
                write_u32(call_state().flow.value_a + 0x1004d348u, static_cast<std::uint32_t>(call_state().flow.value_c));
                write_u32(call_state().flow.value_a + 0x1004d34cu, static_cast<std::uint32_t>(call_state().flow.value_d));
                write_u64(call_state().flow.frame_cursor + 0x00000080u, native_double_to_binary64_bits(call_state().floating.temporary[6u]));
                call_state().floating.temporary[6u] = call_state().floating.temporary[6u] * call_state().floating.temporary[7u];
                call_state().floating.temporary[6u] = call_state().floating.temporary[6u] * native_double_from_binary64_bits(read_u64(0x1000c4e0u));
                write_u64(0x100d6170u, native_double_to_binary64_bits(call_state().floating.temporary[6u]));
                call_state().flow.value_d = read_u32(0x100d6170u);
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u];
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x1004aef8u));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] * native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000050u));
                write_u32(call_state().flow.frame_cursor + 0x00000038u, static_cast<std::uint32_t>(call_state().flow.value_d));
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x100d6168u)) - call_state().floating.temporary[7u];
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] * native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000080u));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] * native_double_from_binary64_bits(read_u64(0x1000c4e0u));
                write_u64(0x100d6168u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                call_state().flow.value_a = read_u32(0x100d6168u);
                call_state().flow.value_c = read_u32(0x100d616cu);
                write_u32(call_state().flow.frame_cursor + 0x00000028u, static_cast<std::uint32_t>(call_state().flow.value_a));
                call_state().flow.value_a = read_u32(0x100d6174u);
                write_u32(call_state().flow.frame_cursor + 0x0000002cu, static_cast<std::uint32_t>(call_state().flow.value_c));
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x100d6170u));
                call_state().floating.temporary[7u] = native_double_abs(call_state().floating.temporary[7u]);
                call_state().floating.temporary[6u] = native_double_from_binary64_bits(read_u64(0x100d6168u));
                call_state().flow.value_c = read_u32(0x100d6168u);
                call_state().flow.value_d = read_u32(0x100d616cu);
                call_state().floating.temporary[6u] = native_double_abs(call_state().floating.temporary[6u]);
                write_u64(call_state().flow.frame_cursor + 0x00000018u, native_double_to_binary64_bits(call_state().floating.temporary[6u]));
                update_float_condition(call_state().floating.temporary[7u], native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000018u)));
                write_u32(call_state().flow.frame_cursor + 0x0000003cu, static_cast<std::uint32_t>(call_state().flow.value_a));
                call_state().flow.value_a = read_u32(0x100d6170u);
                write_u32(call_state().flow.frame_cursor + 0x00000030u, static_cast<std::uint32_t>(call_state().flow.value_a));
                write_u32(call_state().flow.frame_cursor + 0x00000020u, static_cast<std::uint32_t>(call_state().flow.value_c));
                call_state().flow.value_c = read_u32(0x100d6174u);
                write_u32(call_state().flow.frame_cursor + 0x00000024u, static_cast<std::uint32_t>(call_state().flow.value_d));
                call_state().flow.value_a = (call_state().flow.value_a & 0xffff0000u) | ((call_state().floating.comparison_status) & 0xffffu);
                write_u32(call_state().flow.frame_cursor + 0x00000034u, static_cast<std::uint32_t>(call_state().flow.value_c));
                if (((((((call_state().flow.value_a >> 8u) & 0xffu)) & (0x00000041u)) & 0xffu) == 0u)) {
                    stage = ProcessStage::FlowStep49;
                    continue;
                }
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u];
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000018u));
                stage = ProcessStage::FlowStep49;
                continue;
            }
            case ProcessStage::FlowStep49: {
                update_float_condition(call_state().floating.temporary[7u], native_double_from_binary64_bits(read_u64(0x100d63f0u)));
                call_state().flow.value_a = (call_state().flow.value_a & 0xffff0000u) | ((call_state().floating.comparison_status) & 0xffffu);
                if (((((((call_state().flow.value_a >> 8u) & 0xffu)) & (0x00000041u)) & 0xffu) != 0u)) {
                    stage = ProcessStage::FlowStep50;
                    continue;
                }
                write_u64(0x100d63f0u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                stage = ProcessStage::FlowStep51; continue;
            }
            case ProcessStage::FlowStep50: {
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u]; stage = ProcessStage::FlowStep51; continue;
                #endif
                stage = ProcessStage::FlowStep51;
                continue;
            }
            case ProcessStage::FlowStep51: {
                #if defined(SSNATIVE_M13_NATIVE_POSTFILTER)
                fast_m13_postfilter(); stage = ProcessStage::FlowStep59; continue;
                #else
                call_state().flow.value_d = call_state().flow.frame_cursor + 0x00000028u;
                call_state().flow.value_a = call_state().flow.frame_cursor + 0x00000038u;
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.value_d);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.value_a);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x100d6960u);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x1000d5c8u);
                fast_fourth_stereo(0x1000d5c8u, 0x100d6960u, call_state().flow.value_a, call_state().flow.value_d);
                call_state().flow.value_c = call_state().flow.frame_cursor + 0x00000030u;
                call_state().flow.value_d = call_state().flow.frame_cursor + 0x00000040u;
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.value_c);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.value_d);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x100d75a0u);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x1000d610u);
                fast_fourth_stereo(0x1000d610u, 0x100d75a0u, call_state().flow.value_d, call_state().flow.value_c);
                call_state().flow.value_a = read_u32(0x101060a4u);
                { const std::uint32_t lhs = call_state().flow.frame_cursor; const std::uint32_t rhs = 0x00000020u; const std::uint32_t result = lhs + rhs; call_state().flow.frame_cursor = result; update_add_condition( lhs, rhs, result, 32u); }
                if ((((call_state().flow.value_a) & 0xffffffffu) != ((call_state().flow.value_b) & 0xffffffffu))) {
                    stage = ProcessStage::FlowStep52;
                    continue;
                }
                call_state().flow.value_d = read_u32(0x1010f4b4u);
                call_state().flow.value_a = call_state().flow.frame_cursor + 0x00000028u;
                call_state().flow.value_c = call_state().flow.frame_cursor + 0x00000038u;
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.value_a);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.value_c);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.value_d);
                fast_soft_clip_stereo(static_cast<std::int32_t>(call_state().flow.value_d), call_state().flow.value_c, call_state().flow.value_a);
                call_state().flow.value_d = read_u32(0x1010f4b4u);
                call_state().flow.value_a = call_state().flow.frame_cursor + 0x0000002cu;
                call_state().flow.value_c = call_state().flow.frame_cursor + 0x0000003cu;
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.value_a);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.value_c);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.value_d);
                fast_soft_clip_stereo(static_cast<std::int32_t>(call_state().flow.value_d), call_state().flow.value_c, call_state().flow.value_a);
                { const std::uint32_t lhs = call_state().flow.frame_cursor; const std::uint32_t rhs = 0x00000018u; const std::uint32_t result = lhs + rhs; call_state().flow.frame_cursor = result; update_add_condition( lhs, rhs, result, 32u); }
                stage = ProcessStage::FlowStep52;
                continue;
            }
            case ProcessStage::FlowStep52: {
                call_state().flow.value_a = call_state().flow.frame_cursor + 0x00000028u;
                call_state().flow.value_c = call_state().flow.frame_cursor + 0x00000038u;
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.value_a);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.value_c);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x100d6900u);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x1000d5c8u);
                fast_fourth_stereo(0x1000d5c8u, 0x100d6900u, call_state().flow.value_c, call_state().flow.value_a);
                call_state().flow.value_d = call_state().flow.frame_cursor + 0x00000030u;
                call_state().flow.value_a = call_state().flow.frame_cursor + 0x00000040u;
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.value_d);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.value_a);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x100d7600u);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x1000d610u);
                fast_fourth_stereo(0x1000d610u, 0x100d7600u, call_state().flow.value_a, call_state().flow.value_d);
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000040u));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] + native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000048u));
                { const std::uint32_t lhs = call_state().flow.frame_cursor; const std::uint32_t rhs = 0x00000020u; const std::uint32_t result = lhs + rhs; call_state().flow.frame_cursor = result; update_add_condition( lhs, rhs, result, 32u); }
                write_u64(0x100d6168u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000030u));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] + native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000038u));
                write_u64(0x100d6170u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                call_state().floating.temporary[7u] = native_double_abs(call_state().floating.temporary[7u]);
                call_state().floating.temporary[6u] = call_state().floating.temporary[7u];
                call_state().floating.temporary[5u] = native_double_from_binary64_bits(read_u64(0x100d6168u));
                call_state().floating.temporary[5u] = native_double_abs(call_state().floating.temporary[5u]);
                write_u64(call_state().flow.frame_cursor + 0x00000080u, native_double_to_binary64_bits(call_state().floating.temporary[5u]));
                write_u64(call_state().flow.frame_cursor + 0x00000018u, native_double_to_binary64_bits(call_state().floating.temporary[5u]));
                update_float_condition(call_state().floating.temporary[6u], native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000018u)));
                call_state().flow.value_a = (call_state().flow.value_a & 0xffff0000u) | ((call_state().floating.comparison_status) & 0xffffu);
                if (((((((call_state().flow.value_a >> 8u) & 0xffu)) & (0x00000041u)) & 0xffu) == 0u)) {
                    stage = ProcessStage::FlowStep53;
                    continue;
                }
                call_state().floating.temporary[6u] = call_state().floating.temporary[6u];
                call_state().floating.temporary[6u] = native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000018u));
                stage = ProcessStage::FlowStep53;
                continue;
            }
            case ProcessStage::FlowStep53: {
                update_float_condition(call_state().floating.temporary[6u], native_double_from_binary64_bits(read_u64(0x100d63e0u)));
                call_state().flow.value_a = (call_state().flow.value_a & 0xffff0000u) | ((call_state().floating.comparison_status) & 0xffffu);
                if (((((((call_state().flow.value_a >> 8u) & 0xffu)) & (0x00000041u)) & 0xffu) != 0u)) {
                    stage = ProcessStage::FlowStep54;
                    continue;
                }
                write_u64(0x100d63e0u, native_double_to_binary64_bits(call_state().floating.temporary[6u]));
                stage = ProcessStage::FlowStep55; continue;
            }
            case ProcessStage::FlowStep54: {
                call_state().floating.temporary[6u] = call_state().floating.temporary[6u];
                stage = ProcessStage::FlowStep55;
                continue;
            }
            case ProcessStage::FlowStep55: {
                call_state().flow.value_a = read_u32(0x101060a4u);
                call_state().flow.value_c = read_u32(call_state().flow.frame_cursor + 0x00000080u);
                call_state().flow.value_d = read_u32(call_state().flow.frame_cursor + 0x00000084u);
                { const std::uint32_t lhs = call_state().flow.value_a; const std::uint32_t rhs = call_state().flow.value_b; update_sub_condition(lhs, rhs, lhs - rhs, 32u); }
                write_u64(call_state().flow.frame_cursor + 0x00000050u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                write_u32(call_state().flow.frame_cursor + 0x00000018u, static_cast<std::uint32_t>(call_state().flow.value_c));
                write_u32(call_state().flow.frame_cursor + 0x0000001cu, static_cast<std::uint32_t>(call_state().flow.value_d));
                if (!call_state().flow.condition.zero) {
                    stage = ProcessStage::FlowStep56;
                    continue;
                }
                call_state().flow.value_a = read_u32(0x1010f4b8u);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x100d6170u);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x100d6168u);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.value_a);
                fast_soft_clip_stereo(static_cast<std::int32_t>(call_state().flow.value_a), 0x100d6168u, 0x100d6170u);
                { const std::uint32_t lhs = call_state().flow.frame_cursor; const std::uint32_t rhs = 0x0000000cu; const std::uint32_t result = lhs + rhs; call_state().flow.frame_cursor = result; update_add_condition( lhs, rhs, result, 32u); }
                stage = ProcessStage::FlowStep56;
                continue;
            }
            case ProcessStage::FlowStep56: {
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x100d6170u));
                call_state().floating.temporary[7u] = native_double_abs(call_state().floating.temporary[7u]);
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000050u)) - call_state().floating.temporary[7u];
                call_state().floating.temporary[6u] = native_double_from_binary64_bits(read_u64(0x100d6168u));
                call_state().floating.temporary[6u] = native_double_abs(call_state().floating.temporary[6u]);
                call_state().floating.temporary[6u] = native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000018u)) - call_state().floating.temporary[6u];
                write_u64(call_state().flow.frame_cursor + 0x00000018u, native_double_to_binary64_bits(call_state().floating.temporary[6u]));
                update_float_condition(call_state().floating.temporary[7u], native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000018u)));
                call_state().flow.value_a = (call_state().flow.value_a & 0xffff0000u) | ((call_state().floating.comparison_status) & 0xffffu);
                if (((((((call_state().flow.value_a >> 8u) & 0xffu)) & (0x00000041u)) & 0xffu) == 0u)) {
                    stage = ProcessStage::FlowStep57;
                    continue;
                }
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u];
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000018u));
                stage = ProcessStage::FlowStep57;
                continue;
            }
            case ProcessStage::FlowStep57: {
                update_float_condition(call_state().floating.temporary[7u], native_double_from_binary64_bits(read_u64(0x100d63e8u)));
                call_state().flow.value_a = (call_state().flow.value_a & 0xffff0000u) | ((call_state().floating.comparison_status) & 0xffffu);
                if (((((((call_state().flow.value_a >> 8u) & 0xffu)) & (0x00000041u)) & 0xffu) != 0u)) {
                    stage = ProcessStage::FlowStep58;
                    continue;
                }
                write_u64(0x100d63e8u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                stage = ProcessStage::FlowStep59; continue;
            }
            case ProcessStage::FlowStep58: {
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u]; stage = ProcessStage::FlowStep59; continue;
                #endif
                stage = ProcessStage::FlowStep59;
                continue;
            }
            case ProcessStage::FlowStep59: {
                if ((((read_u32(0x101060c8u)) & 0xffffffffu) != ((call_state().flow.value_b) & 0xffffffffu))) {
                    stage = ProcessStage::FlowStep61;
                    continue;
                }
                call_state().flow.value_a = read_u32(0x101060b8u);
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x100d60f0u));
                if ((((call_state().flow.value_a) & 0xffffffffu) == ((call_state().flow.value_b) & 0xffffffffu))) {
                    stage = ProcessStage::FlowStep60;
                    continue;
                }
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] * native_double_from_binary64_bits(read_u64(0x1000c540u));
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x100d6170u)) - call_state().floating.temporary[7u];
                write_u64(0x100d60e8u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                call_state().floating.temporary[6u] = call_state().floating.temporary[7u];
                call_state().floating.temporary[6u] = call_state().floating.temporary[6u] * native_double_from_binary64_bits(read_u64(0x1000c530u));
                write_u64(0x100d6170u, native_double_to_binary64_bits(call_state().floating.temporary[6u]));
                write_u64(0x100d60f0u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x100d6100u));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] * native_double_from_binary64_bits(read_u64(0x1000c540u));
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x100d6168u)) - call_state().floating.temporary[7u];
                write_u64(0x100d60f8u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] * native_double_from_binary64_bits(read_u64(0x1000c530u));
                call_state().flow.value_c = read_u32(0x100d60f8u);
                call_state().flow.value_d = read_u32(0x100d60fcu);
                write_u32(0x100d6100u, static_cast<std::uint32_t>(call_state().flow.value_c));
                write_u32(0x100d6104u, static_cast<std::uint32_t>(call_state().flow.value_d));
                stage = ProcessStage::FlowStep66; continue;
            }
            case ProcessStage::FlowStep60: {
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] * native_double_from_binary64_bits(read_u64(0x1000c520u));
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x100d6170u)) - call_state().floating.temporary[7u];
                write_u64(0x100d60e8u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                call_state().floating.temporary[6u] = call_state().floating.temporary[7u];
                call_state().floating.temporary[6u] = call_state().floating.temporary[6u] * native_double_from_binary64_bits(read_u64(0x1000c510u));
                write_u64(0x100d6170u, native_double_to_binary64_bits(call_state().floating.temporary[6u]));
                write_u64(0x100d60f0u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x100d6100u));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] * native_double_from_binary64_bits(read_u64(0x1000c520u));
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x100d6168u)) - call_state().floating.temporary[7u];
                write_u64(0x100d60f8u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] * native_double_from_binary64_bits(read_u64(0x1000c510u));
                call_state().flow.value_a = read_u32(0x100d60f8u);
                call_state().flow.value_c = read_u32(0x100d60fcu);
                write_u32(0x100d6100u, static_cast<std::uint32_t>(call_state().flow.value_a));
                write_u32(0x100d6104u, static_cast<std::uint32_t>(call_state().flow.value_c));
                stage = ProcessStage::FlowStep66; continue;
            }
            case ProcessStage::FlowStep61: {
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x100d6170u));
                truncate_native_double_to_i64_parts(call_state().floating.temporary[7u]);
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x100d6168u));
                write_u32(0x1000f5c8u, static_cast<std::uint32_t>(call_state().flow.value_a));
                truncate_native_double_to_i64_parts(call_state().floating.temporary[7u]);
                write_u32(0x1000ed10u, static_cast<std::uint32_t>(call_state().flow.value_a));
                { const std::uint32_t lhs = call_state().flow.value_d; const std::uint32_t rhs = call_state().flow.value_d; const std::uint32_t result = lhs ^ rhs; call_state().flow.value_d = result; update_logic_condition( result, 32u); }
                { const std::uint32_t lhs = call_state().flow.index; const std::uint32_t rhs = call_state().flow.index; const std::uint32_t result = lhs ^ rhs; call_state().flow.index = result; update_logic_condition( result, 32u); }
                { const std::uint32_t lhs = call_state().flow.value_a; const std::uint32_t rhs = call_state().flow.value_a; const std::uint32_t result = lhs ^ rhs; call_state().flow.value_a = result; update_logic_condition( result, 32u); }
                stage = ProcessStage::FlowStep62;
                continue;
            }
            case ProcessStage::FlowStep62: {
                call_state().flow.value_c = read_u32(call_state().flow.value_a + 0x1004af0cu);
                call_state().flow.pointer = read_u32(call_state().flow.value_a + 0x1000f5ccu);
                { const std::int64_t product = static_cast<std::int64_t>(static_cast<std::int32_t>(call_state().flow.pointer)) * static_cast<std::int64_t>(static_cast<std::int32_t>(call_state().flow.value_c)); call_state().flow.pointer = static_cast<std::uint32_t>(product); call_state().flow.condition.carry = call_state().flow.condition.overflow = (product > INT32_MAX || product < INT32_MIN); }
                { const std::uint32_t lhs = call_state().flow.value_d; const std::uint32_t rhs = call_state().flow.pointer; const std::uint32_t result = lhs + rhs; call_state().flow.value_d = result; update_add_condition( lhs, rhs, result, 32u); }
                call_state().flow.pointer = read_u32(call_state().flow.value_a + 0x1000ed14u);
                { const std::int64_t product = static_cast<std::int64_t>(static_cast<std::int32_t>(call_state().flow.pointer)) * static_cast<std::int64_t>(static_cast<std::int32_t>(call_state().flow.value_c)); call_state().flow.pointer = static_cast<std::uint32_t>(product); call_state().flow.condition.carry = call_state().flow.condition.overflow = (product > INT32_MAX || product < INT32_MIN); }
                { const std::uint32_t lhs = call_state().flow.value_a; const std::uint32_t rhs = 0x00000004u; const std::uint32_t result = lhs + rhs; call_state().flow.value_a = result; update_add_condition( lhs, rhs, result, 32u); }
                { const std::uint32_t lhs = call_state().flow.index; const std::uint32_t rhs = call_state().flow.pointer; const std::uint32_t result = lhs + rhs; call_state().flow.index = result; update_add_condition( lhs, rhs, result, 32u); }
                if ((static_cast<std::int32_t>(call_state().flow.value_a) < static_cast<std::int32_t>(0x00000068u))) {
                    stage = ProcessStage::FlowStep62;
                    continue;
                }
                call_state().flow.value_a = 0x00000004u;
                stage = ProcessStage::FlowStep63;
                continue;
            }
            case ProcessStage::FlowStep63: {
                call_state().flow.value_c = read_u32(call_state().flow.value_a + 0x1000f628u);
                write_u32(call_state().flow.value_a + 0x1000f62cu, static_cast<std::uint32_t>(call_state().flow.value_c));
                call_state().flow.value_c = read_u32(call_state().flow.value_a + 0x1000ed70u);
                write_u32(call_state().flow.value_a + 0x1000ed74u, static_cast<std::uint32_t>(call_state().flow.value_c));
                { const std::uint32_t lhs = call_state().flow.value_a; const std::uint32_t rhs = 0x00000004u; const std::uint32_t result = lhs - rhs; call_state().flow.value_a = result; update_sub_condition( lhs, rhs, result, 32u); }
                if ((static_cast<std::int32_t>(call_state().flow.value_a) >= static_cast<std::int32_t>(0xffffffa0u))) {
                    stage = ProcessStage::FlowStep63;
                    continue;
                }
                { const unsigned count = (0x0000000du) & 31u; if (count != 0u) { const std::uint32_t old_value = call_state().flow.value_d; const std::uint32_t result = static_cast<std::uint32_t>(static_cast<std::int32_t>(old_value) >> count); call_state().flow.value_d = result; update_logic_condition(result, 32u); } }
                write_u32(call_state().flow.frame_cursor + 0x00000018u, static_cast<std::uint32_t>(call_state().flow.value_d));
                call_state().floating.temporary[7u] = static_cast<NativeDouble>(static_cast<std::int32_t>(read_u32(call_state().flow.frame_cursor + 0x00000018u)));
                { const unsigned count = (0x0000000du) & 31u; if (count != 0u) { const std::uint32_t old_value = call_state().flow.index; const std::uint32_t result = static_cast<std::uint32_t>(static_cast<std::int32_t>(old_value) >> count); call_state().flow.index = result; update_logic_condition(result, 32u); } }
                write_u32(call_state().flow.frame_cursor + 0x00000018u, static_cast<std::uint32_t>(call_state().flow.index));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] * native_double_from_binary64_bits(read_u64(0x1000c580u));
                write_u64(0x100d6170u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                call_state().floating.temporary[7u] = static_cast<NativeDouble>(static_cast<std::int32_t>(read_u32(call_state().flow.frame_cursor + 0x00000018u)));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] * native_double_from_binary64_bits(read_u64(0x1000c580u));
                stage = ProcessStage::FlowStep65; continue;
            }
            case ProcessStage::FlowStep64: {
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x100d6168u));
                write_u32(0x100d6888u, static_cast<std::uint32_t>(call_state().flow.value_b));
                write_u32(0x100d689cu, static_cast<std::uint32_t>(call_state().flow.value_b));
                write_u32(0x100d5f58u, static_cast<std::uint32_t>(call_state().flow.value_b));
                stage = ProcessStage::FlowStep65;
                continue;
            }
            case ProcessStage::FlowStep65: {
                call_state().flow.pointer = read_u32(call_state().flow.frame_cursor + 0x00000010u);
                stage = ProcessStage::FlowStep66;
                continue;
            }
            case ProcessStage::FlowStep66: {
                call_state().flow.value_a = read_u32(0x100d6894u);
                { const std::uint32_t lhs = call_state().flow.value_a; const std::uint32_t rhs = call_state().flow.value_b; update_sub_condition(lhs, rhs, lhs - rhs, 32u); }
                call_state().flow.value_a = read_u32(0x100d61c8u);
                if (call_state().flow.condition.zero) {
                    stage = ProcessStage::FlowStep67;
                    continue;
                }
                { const std::uint32_t old_value = call_state().flow.value_a; const std::uint32_t result = old_value + 1u; call_state().flow.value_a = result; const bool carry = call_state().flow.condition.carry; update_add_condition(old_value, 1u, result, 32u); call_state().flow.condition.carry = carry; }
                { const std::uint32_t lhs = call_state().flow.value_a; const std::uint32_t rhs = 0x000003e8u; update_sub_condition(lhs, rhs, lhs - rhs, 32u); }
                write_u32(0x100d61c8u, static_cast<std::uint32_t>(call_state().flow.value_a));
                if ((call_state().flow.condition.zero || call_state().flow.condition.negative != call_state().flow.condition.overflow)) {
                    stage = ProcessStage::FlowStep68;
                    continue;
                }
                write_u32(0x100d61c8u, static_cast<std::uint32_t>(0x000003e8u));
                stage = ProcessStage::FlowStep68; continue;
            }
            case ProcessStage::FlowStep67: {
                { const std::uint32_t old_value = call_state().flow.value_a; const std::uint32_t result = old_value - 1u; call_state().flow.value_a = result; const bool carry = call_state().flow.condition.carry; update_sub_condition(old_value, 1u, result, 32u); call_state().flow.condition.carry = carry; }
                write_u32(0x100d61c8u, static_cast<std::uint32_t>(call_state().flow.value_a));
                if (!call_state().flow.condition.negative) {
                    stage = ProcessStage::FlowStep68;
                    continue;
                }
                write_u32(0x100d61c8u, static_cast<std::uint32_t>(call_state().flow.value_b));
                stage = ProcessStage::FlowStep68;
                continue;
            }
            case ProcessStage::FlowStep68: {
                call_state().flow.value_a = read_u32(0x100d61ccu);
                if ((static_cast<std::int32_t>(call_state().flow.value_a) < static_cast<std::int32_t>(0x00000273u))) {
                    stage = ProcessStage::FlowStep69;
                    continue;
                }
                { const std::uint32_t lhs = call_state().flow.value_a; const std::uint32_t rhs = call_state().flow.value_a; const std::uint32_t result = lhs ^ rhs; call_state().flow.value_a = result; update_logic_condition( result, 32u); }
                stage = ProcessStage::FlowStep69;
                continue;
            }
            case ProcessStage::FlowStep69: {
                call_state().flow.index = read_u32(0x100d61c8u);
                call_state().flow.value_d = 0x000003e8u;
                call_state().floating.temporary[6u] = static_cast<NativeDouble>(static_cast<std::int32_t>(read_u32((call_state().flow.value_a * 4u) + 0x100d6b60u)));
                { const std::uint32_t lhs = call_state().flow.value_d; const std::uint32_t rhs = call_state().flow.index; const std::uint32_t result = lhs - rhs; call_state().flow.value_d = result; update_sub_condition( lhs, rhs, result, 32u); }
                { const std::uint32_t lhs = call_state().flow.value_a; const std::uint32_t rhs = 0x00000002u; const std::uint32_t result = lhs + rhs; call_state().flow.value_a = result; update_add_condition( lhs, rhs, result, 32u); }
                write_u32(call_state().flow.frame_cursor + 0x00000018u, static_cast<std::uint32_t>(call_state().flow.value_d));
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x100d6170u);
                call_state().floating.temporary[5u] = static_cast<NativeDouble>(static_cast<std::int32_t>(read_u32(call_state().flow.frame_cursor + 0x0000001cu)));
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x00007ff8u);
                write_u32(0x100d61ccu, static_cast<std::uint32_t>(call_state().flow.value_a));
                write_u64(call_state().flow.frame_cursor + 0x00000088u, native_double_to_binary64_bits(call_state().floating.temporary[5u]));
                call_state().floating.temporary[6u] *= static_cast<NativeDouble>(static_cast<std::int32_t>(read_u32(0x100d61c8u)));
                call_state().floating.temporary[5u] = native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000088u));
                call_state().floating.temporary[5u] = call_state().floating.temporary[5u] * native_double_from_binary64_bits(read_u64(0x100d6170u));
                call_state().floating.temporary[5u] = call_state().floating.temporary[5u] + call_state().floating.temporary[6u];
                call_state().floating.temporary[5u] = call_state().floating.temporary[5u] * native_double_from_binary64_bits(read_u64(0x1000c500u));
                write_u64(0x100d6170u, native_double_to_binary64_bits(call_state().floating.temporary[5u]));
                call_state().floating.temporary[5u] = native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000088u));
                call_state().floating.temporary[5u] = call_state().floating.temporary[5u] * call_state().floating.temporary[7u];
                call_state().floating.temporary[5u] = call_state().floating.temporary[5u] + call_state().floating.temporary[6u];
                call_state().floating.temporary[5u] = call_state().floating.temporary[5u] * native_double_from_binary64_bits(read_u64(0x1000c500u));
                write_u64(0x100d6168u, native_double_to_binary64_bits(call_state().floating.temporary[5u]));
                call_state().floating.temporary[6u] = call_state().floating.temporary[6u];
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u];
                call_state().flow.frame_cursor -= 4u; fast_10008ff0(); call_state().flow.frame_cursor += 4u;
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x100d6168u);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, 0x00007ff8u);
                fast_soft_clip_mono(0x7ff8, 0x100d6168u);
                call_state().flow.value_a = read_u32(0x1010609cu);
                { const std::uint32_t lhs = call_state().flow.frame_cursor; const std::uint32_t rhs = 0x00000010u; const std::uint32_t result = lhs + rhs; call_state().flow.frame_cursor = result; update_add_condition( lhs, rhs, result, 32u); }
                if ((((call_state().flow.value_a) & 0xffffffffu) != ((call_state().flow.value_b) & 0xffffffffu))) {
                    stage = ProcessStage::FlowStep73;
                    continue;
                }
                { const std::uint32_t lhs = read_u32(0x100d5f60u); const std::uint32_t rhs = call_state().flow.value_b; update_sub_condition(lhs, rhs, lhs - rhs, 32u); }
                stage = ProcessStage::FlowStep72; continue;
            }
            case ProcessStage::FlowStep70: {
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x100d6168u));
                stage = ProcessStage::FlowStep71;
                continue;
            }
            case ProcessStage::FlowStep71: {
                truncate_native_double_to_i64_parts(call_state().floating.temporary[7u]);
                call_state().flow.index = read_u32(call_state().flow.frame_base + 0x00000018u);
                write_u16(call_state().flow.pointer, static_cast<std::uint16_t>((call_state().flow.value_a & 0xffffu)));
                if ((((call_state().flow.index) & 0xffffffffu) != ((0x00000002u) & 0xffffffffu))) {
                    stage = ProcessStage::FlowStep78;
                    continue;
                }
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x100d6170u));
                update_float_condition(call_state().floating.temporary[7u], native_double_from_binary64_bits(read_u64(0x1000c4d0u)));
                call_state().flow.value_a = (call_state().flow.value_a & 0xffff0000u) | ((call_state().floating.comparison_status) & 0xffffu);
                if (((((((call_state().flow.value_a >> 8u) & 0xffu)) & (0x00000041u)) & 0xffu) != 0u)) {
                    stage = ProcessStage::FlowStep75;
                    continue;
                }
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x1000c4d0u));
                stage = ProcessStage::FlowStep77; continue;
            }
            case ProcessStage::FlowStep72: {
                call_state().floating.temporary[7u] = static_cast<NativeDouble>(static_cast<std::int32_t>(read_u32(0x101060d4u)));
                call_state().floating.temporary[6u] = call_state().floating.temporary[7u];
                call_state().floating.temporary[6u] = call_state().floating.temporary[6u] * native_double_from_binary64_bits(read_u64(0x100d6168u));
                call_state().floating.temporary[6u] = call_state().floating.temporary[6u] * native_double_from_binary64_bits(read_u64(0x1000c4e0u));
                write_u64(0x100d6168u, native_double_to_binary64_bits(call_state().floating.temporary[6u]));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] * native_double_from_binary64_bits(read_u64(0x100d6170u));
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u] * native_double_from_binary64_bits(read_u64(0x1000c4e0u));
                write_u64(0x100d6170u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                stage = ProcessStage::FlowStep73;
                continue;
            }
            case ProcessStage::FlowStep73: {
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x100d6168u));
                update_float_condition(call_state().floating.temporary[7u], native_double_from_binary64_bits(read_u64(0x1000c4d0u)));
                call_state().flow.value_a = (call_state().flow.value_a & 0xffff0000u) | ((call_state().floating.comparison_status) & 0xffffu);
                if (((((((call_state().flow.value_a >> 8u) & 0xffu)) & (0x00000041u)) & 0xffu) != 0u)) {
                    stage = ProcessStage::FlowStep74;
                    continue;
                }
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x1000c4d0u));
                stage = ProcessStage::FlowStep71; continue;
            }
            case ProcessStage::FlowStep74: {
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x100d6168u));
                update_float_condition(call_state().floating.temporary[7u], native_double_from_binary64_bits(read_u64(0x1000c4f0u)));
                call_state().flow.value_a = (call_state().flow.value_a & 0xffff0000u) | ((call_state().floating.comparison_status) & 0xffffu);
                if (((((((call_state().flow.value_a >> 8u) & 0xffu)) & (0x00000001u)) & 0xffu) == 0u)) {
                    stage = ProcessStage::FlowStep70;
                    continue;
                }
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x1000c4f0u));
                stage = ProcessStage::FlowStep71; continue;
            }
            case ProcessStage::FlowStep75: {
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x100d6170u));
                update_float_condition(call_state().floating.temporary[7u], native_double_from_binary64_bits(read_u64(0x1000c4f0u)));
                call_state().flow.value_a = (call_state().flow.value_a & 0xffff0000u) | ((call_state().floating.comparison_status) & 0xffffu);
                if (((((((call_state().flow.value_a >> 8u) & 0xffu)) & (0x00000001u)) & 0xffu) == 0u)) {
                    stage = ProcessStage::FlowStep76;
                    continue;
                }
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x1000c4f0u));
                stage = ProcessStage::FlowStep77; continue;
            }
            case ProcessStage::FlowStep76: {
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x100d6170u));
                stage = ProcessStage::FlowStep77;
                continue;
            }
            case ProcessStage::FlowStep77: {
                truncate_native_double_to_i64_parts(call_state().floating.temporary[7u]);
                write_u16(call_state().flow.pointer + 0x00000002u, static_cast<std::uint16_t>((call_state().flow.value_a & 0xffffu)));
                stage = ProcessStage::FlowStep78;
                continue;
            }
            case ProcessStage::FlowStep78: {
                call_state().flow.value_a = static_cast<std::uint32_t>(static_cast<std::int32_t>(static_cast<std::int16_t>(read_u16(call_state().flow.pointer))));
                call_state().flow.value_d = static_cast<std::int32_t>(call_state().flow.value_a) < 0 ? 0xffffffffu : 0u;
                { const std::uint32_t lhs = call_state().flow.value_a; const std::uint32_t rhs = call_state().flow.value_d; const std::uint32_t result = lhs ^ rhs; call_state().flow.value_a = result; update_logic_condition( result, 32u); }
                { const std::uint32_t lhs = call_state().flow.value_a; const std::uint32_t rhs = call_state().flow.value_d; const std::uint32_t result = lhs - rhs; call_state().flow.value_a = result; update_sub_condition( lhs, rhs, result, 32u); }
                write_u32(call_state().flow.frame_cursor + 0x00000018u, static_cast<std::uint32_t>(call_state().flow.value_a));
                call_state().flow.value_a = static_cast<std::uint32_t>(static_cast<std::int32_t>(static_cast<std::int16_t>(read_u16(call_state().flow.pointer + 0x00000002u))));
                call_state().floating.temporary[7u] = static_cast<NativeDouble>(static_cast<std::int32_t>(read_u32(call_state().flow.frame_cursor + 0x00000018u)));
                call_state().flow.value_d = static_cast<std::int32_t>(call_state().flow.value_a) < 0 ? 0xffffffffu : 0u;
                { const std::uint32_t lhs = call_state().flow.value_a; const std::uint32_t rhs = call_state().flow.value_d; const std::uint32_t result = lhs ^ rhs; call_state().flow.value_a = result; update_logic_condition( result, 32u); }
                { const std::uint32_t lhs = call_state().flow.value_a; const std::uint32_t rhs = call_state().flow.value_d; const std::uint32_t result = lhs - rhs; call_state().flow.value_a = result; update_sub_condition( lhs, rhs, result, 32u); }
                write_u32(call_state().flow.frame_cursor + 0x00000018u, static_cast<std::uint32_t>(call_state().flow.value_a));
                call_state().floating.temporary[6u] = static_cast<NativeDouble>(static_cast<std::int32_t>(read_u32(call_state().flow.frame_cursor + 0x00000018u)));
                write_u64(call_state().flow.frame_cursor + 0x00000018u, native_double_to_binary64_bits(call_state().floating.temporary[6u]));
                call_state().floating.temporary[6u] = native_double_from_binary64_bits(read_u64(0x100d63c8u));
                update_float_condition(call_state().floating.temporary[6u], call_state().floating.temporary[7u]);
                call_state().flow.value_a = (call_state().flow.value_a & 0xffff0000u) | ((call_state().floating.comparison_status) & 0xffffu);
                if (((((((call_state().flow.value_a >> 8u) & 0xffu)) & (0x00000001u)) & 0xffu) == 0u)) {
                    stage = ProcessStage::FlowStep79;
                    continue;
                }
                write_u64(0x100d63c8u, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                stage = ProcessStage::FlowStep80; continue;
            }
            case ProcessStage::FlowStep79: {
                call_state().floating.temporary[7u] = call_state().floating.temporary[7u];
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(0x100d63c8u));
                update_float_condition(call_state().floating.temporary[7u], native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000018u)));
                call_state().flow.value_a = (call_state().flow.value_a & 0xffff0000u) | ((call_state().floating.comparison_status) & 0xffffu);
                if (((((((call_state().flow.value_a >> 8u) & 0xffu)) & (0x00000001u)) & 0xffu) == 0u)) {
                    stage = ProcessStage::FlowStep80;
                    continue;
                }
                call_state().flow.value_a = read_u32(call_state().flow.frame_cursor + 0x00000018u);
                call_state().flow.value_c = read_u32(call_state().flow.frame_cursor + 0x0000001cu);
                write_u32(0x100d63c8u, static_cast<std::uint32_t>(call_state().flow.value_a));
                write_u32(0x100d63ccu, static_cast<std::uint32_t>(call_state().flow.value_c));
                stage = ProcessStage::FlowStep80;
                continue;
            }
            case ProcessStage::FlowStep80: {
                call_state().flow.value_a = read_u32(call_state().flow.frame_cursor + 0x00000014u);
                call_state().flow.pointer = call_state().flow.pointer + (call_state().flow.index * 2u);
                call_state().flow.value_d = call_state().flow.value_a;
                { const std::uint32_t old_value = call_state().flow.value_a; const std::uint32_t result = old_value - 1u; call_state().flow.value_a = result; const bool carry = call_state().flow.condition.carry; update_sub_condition(old_value, 1u, result, 32u); call_state().flow.condition.carry = carry; }
                update_logic_condition((call_state().flow.value_d) & (call_state().flow.value_d), 32u);
                write_u32(call_state().flow.frame_cursor + 0x00000010u, static_cast<std::uint32_t>(call_state().flow.pointer));
                write_u32(call_state().flow.frame_cursor + 0x00000014u, static_cast<std::uint32_t>(call_state().flow.value_a));
                if (!call_state().flow.condition.zero) {
                    stage = ProcessStage::FlowStep00;
                    continue;
                }
                stage = ProcessStage::FlowStep82; continue;
            }
            case ProcessStage::FlowStep81: {
                { const std::uint32_t lhs = call_state().flow.value_a; const std::uint32_t rhs = call_state().flow.value_a; const std::uint32_t result = lhs ^ rhs; call_state().flow.value_a = result; update_logic_condition( result, 32u); }
                write_u32(0x100d5f58u, static_cast<std::uint32_t>(call_state().flow.value_a));
                write_u32(0x100d6888u, static_cast<std::uint32_t>(call_state().flow.value_a));
                write_u32(0x100d689cu, static_cast<std::uint32_t>(call_state().flow.value_a));
                write_u32(0x100d6850u, static_cast<std::uint32_t>(call_state().flow.value_a));
                write_u32(0x100d6854u, static_cast<std::uint32_t>(call_state().flow.value_a));
                write_u32(0x100d6858u, static_cast<std::uint32_t>(call_state().flow.value_a));
                write_u32(0x100d685cu, static_cast<std::uint32_t>(call_state().flow.value_a));
                call_state().flow.value_a = read_u32(0x100d5f54u);
                { const std::uint32_t lhs = ((call_state().flow.value_a >> 8u) & 0xffu); const std::uint32_t rhs = 0x000000ffu; const std::uint32_t result = lhs | rhs; call_state().flow.value_a = (call_state().flow.value_a & 0xffff00ffu) | (((result) & 0xffu) << 8u); update_logic_condition( result, 8u); }
                write_u32(0x100d5f54u, static_cast<std::uint32_t>(call_state().flow.value_a));
                stage = ProcessStage::FlowStep82;
                continue;
            }
            case ProcessStage::FlowStep82: {
                // The supplied DLL contains a dormant evaluation timer at
                // 0x1000392a..0x10003996. Its audio-muting branch is unreachable in the
                // original binary. Preserve the observable ModifySamples return value,
                // but do not execute or maintain the dead counters.
                call_state().flow.value_a = read_u32(call_state().flow.frame_base + 0x10u);

                call_state().flow.pointer = read_u32(call_state().flow.frame_cursor); call_state().flow.frame_cursor += 4u;
                call_state().flow.index = read_u32(call_state().flow.frame_cursor); call_state().flow.frame_cursor += 4u;
                call_state().flow.value_b = read_u32(call_state().flow.frame_cursor); call_state().flow.frame_cursor += 4u;
                call_state().flow.frame_cursor = call_state().flow.frame_base;
                call_state().flow.frame_base = read_u32(call_state().flow.frame_cursor); call_state().flow.frame_cursor += 4u;
                call_state().flow.frame_cursor += 4u; return;
            }
            case ProcessStage::FlowStep83: {
                { const std::uint32_t lhs = call_state().flow.frame_cursor; const std::uint32_t rhs = 0x00000008u; const std::uint32_t result = lhs - rhs; call_state().flow.frame_cursor = result; update_sub_condition( lhs, rhs, result, 32u); }
                call_state().flow.value_d = read_u32(call_state().flow.frame_cursor + 0x0000000cu);
                call_state().flow.value_c = read_u32(call_state().flow.frame_cursor + 0x00000014u);
                call_state().flow.frame_cursor -= 4u; write_u32(call_state().flow.frame_cursor, call_state().flow.index);
                call_state().flow.index = read_u32(call_state().flow.frame_cursor + 0x00000014u);
                { const std::uint32_t lhs = call_state().flow.value_a; const std::uint32_t rhs = call_state().flow.value_a; const std::uint32_t result = lhs ^ rhs; call_state().flow.value_a = result; update_logic_condition( result, 32u); }
                { const std::uint32_t old_value = call_state().flow.value_c; const std::uint32_t result = old_value - 1u; call_state().flow.value_c = result; const bool carry = call_state().flow.condition.carry; update_sub_condition(old_value, 1u, result, 32u); call_state().flow.condition.carry = carry; }
                call_state().floating.temporary[7u] = native_double_from_binary64_bits(read_u64(call_state().flow.index));
                call_state().floating.temporary[6u] = native_double_from_binary64_bits(read_u64(call_state().flow.value_d));
                update_logic_condition((call_state().flow.value_c) & (call_state().flow.value_c), 32u);
                write_u64(call_state().flow.frame_cursor + 0x00000004u, native_double_to_binary64_bits(call_state().floating.temporary[6u]));
                if ((call_state().flow.condition.zero || call_state().flow.condition.negative != call_state().flow.condition.overflow)) {
                    stage = ProcessStage::FlowStep85;
                    continue;
                }
                stage = ProcessStage::FlowStep84;
                continue;
            }
            case ProcessStage::FlowStep84: {
                call_state().floating.temporary[5u] = call_state().floating.temporary[7u];
                call_state().floating.temporary[5u] = call_state().floating.temporary[5u] * native_double_from_binary64_bits(read_u64(0x1000c7d0u));
                call_state().floating.temporary[4u] = native_double_from_binary64_bits(read_u64((call_state().flow.value_a * 8u) + 0x100104e0u));
                call_state().floating.temporary[4u] = call_state().floating.temporary[4u] * native_double_from_binary64_bits(read_u64(0x1000c680u));
                { const std::uint32_t old_value = call_state().flow.value_a; const std::uint32_t result = old_value + 1u; call_state().flow.value_a = result; const bool carry = call_state().flow.condition.carry; update_add_condition(old_value, 1u, result, 32u); call_state().flow.condition.carry = carry; }
                call_state().floating.temporary[5u] = call_state().floating.temporary[5u] + call_state().floating.temporary[4u];
                { const std::uint32_t lhs = call_state().flow.value_a; const std::uint32_t rhs = call_state().flow.value_c; update_sub_condition(lhs, rhs, lhs - rhs, 32u); }
                write_u64((call_state().flow.value_a * 8u) + 0x100104d8u, native_double_to_binary64_bits(call_state().floating.temporary[5u]));
                call_state().floating.temporary[4u] = call_state().floating.temporary[6u];
                call_state().floating.temporary[4u] = call_state().floating.temporary[4u] * native_double_from_binary64_bits(read_u64(0x1000c7d0u));
                call_state().floating.temporary[3u] = native_double_from_binary64_bits(read_u64((call_state().flow.value_a * 8u) + 0x100d5e68u));
                call_state().floating.temporary[3u] = call_state().floating.temporary[3u] * native_double_from_binary64_bits(read_u64(0x1000c680u));
                call_state().floating.temporary[4u] = call_state().floating.temporary[4u] + call_state().floating.temporary[3u];
                write_u64(call_state().flow.frame_cursor + 0x00000004u, native_double_to_binary64_bits(call_state().floating.temporary[4u]));
                write_u64((call_state().flow.value_a * 8u) + 0x100d5e68u, native_double_to_binary64_bits(call_state().floating.temporary[4u]));
                call_state().floating.temporary[5u] = call_state().floating.temporary[5u] + call_state().floating.temporary[5u];
                call_state().floating.temporary[7u] = call_state().floating.temporary[5u] - call_state().floating.temporary[7u];
                call_state().floating.temporary[5u] = native_double_from_binary64_bits(read_u64(call_state().flow.frame_cursor + 0x00000004u));
                call_state().floating.temporary[5u] = call_state().floating.temporary[5u] + call_state().floating.temporary[5u];
                call_state().floating.temporary[6u] = call_state().floating.temporary[5u] - call_state().floating.temporary[6u];
                if ((call_state().flow.condition.negative != call_state().flow.condition.overflow)) {
                    stage = ProcessStage::FlowStep84;
                    continue;
                }
                write_u64(call_state().flow.frame_cursor + 0x00000004u, native_double_to_binary64_bits(call_state().floating.temporary[6u]));
                call_state().flow.value_a = read_u32(call_state().flow.frame_cursor + 0x00000004u);
                call_state().flow.value_c = read_u32(call_state().flow.frame_cursor + 0x00000008u);
                write_u64(call_state().flow.index, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                write_u32(call_state().flow.value_d, static_cast<std::uint32_t>(call_state().flow.value_a));
                write_u32(call_state().flow.value_d + 0x00000004u, static_cast<std::uint32_t>(call_state().flow.value_c));
                call_state().flow.index = read_u32(call_state().flow.frame_cursor); call_state().flow.frame_cursor += 4u;
                { const std::uint32_t lhs = call_state().flow.frame_cursor; const std::uint32_t rhs = 0x00000008u; const std::uint32_t result = lhs + rhs; call_state().flow.frame_cursor = result; update_add_condition( lhs, rhs, result, 32u); }
                call_state().flow.frame_cursor += 4u; stage = ProcessStage::FlowStep09; continue;
            }
            case ProcessStage::FlowStep85: {
                call_state().flow.value_a = read_u32(call_state().flow.frame_cursor + 0x00000004u);
                call_state().flow.value_c = read_u32(call_state().flow.frame_cursor + 0x00000008u);
                call_state().floating.temporary[6u] = call_state().floating.temporary[6u];
                write_u64(call_state().flow.index, native_double_to_binary64_bits(call_state().floating.temporary[7u]));
                write_u32(call_state().flow.value_d, static_cast<std::uint32_t>(call_state().flow.value_a));
                write_u32(call_state().flow.value_d + 0x00000004u, static_cast<std::uint32_t>(call_state().flow.value_c));
                call_state().flow.index = read_u32(call_state().flow.frame_cursor); call_state().flow.frame_cursor += 4u;
                { const std::uint32_t lhs = call_state().flow.frame_cursor; const std::uint32_t rhs = 0x00000008u; const std::uint32_t result = lhs + rhs; call_state().flow.frame_cursor = result; update_add_condition( lhs, rhs, result, 32u); }
                call_state().flow.frame_cursor += 4u; stage = ProcessStage::FlowStep09; continue;

            }
            default:
                __builtin_unreachable();
            }
        }
    
#endif
    }


};


class NativeColdControl final {
public:
    explicit NativeColdControl(NamedStateStorage& globals) noexcept
        : globals_(globals) {}

    void run_configure() {
        constexpr std::uint32_t kSampleRate = 44100u;
        constexpr std::uint32_t kZero = 0u;

        const std::uint32_t calibration = configure_square_to_i32(2.0);
        write_u32(0x100d68e8u, calibration);
        for (std::uint32_t address = 0x100d6a00u;
             address < 0x100d6a1cu; address += 4u) {
            write_u32(address, 1u);
        }

        std::uint32_t coefficient_state = 0x100d76e0u;
        std::uint32_t runtime_block = 0x1010edd8u;
        std::uint32_t table_offset = 0u;
        while (runtime_block < 0x1010f3c0u) {
            std::uint32_t cursor = runtime_block;
            for (unsigned index = 0; index < 3u; ++index) {
                write_u32(cursor - 8u, kZero);
                write_u32(cursor - 4u, kZero);
                write_u32(cursor, kZero);
                cursor += 0x48u;
            }
            write_u32(0x1000ed80u + table_offset, kZero);
            write_u32(0x1000ed84u + table_offset, kZero);
            write_f64(coefficient_state, 1.0);
            write_u32(0x1000f638u + table_offset, kZero);
            write_u32(0x1000f63cu + table_offset, kZero);
            coefficient_state += 0x10u;
            table_offset += 8u;
            runtime_block = cursor;
        }

        std::uint32_t destination = 0x1010f4b4u;
        for (std::uint32_t source = 0x1010d8fcu;
             source < 0x1010ec64u;
             source += 0x9b4u, destination += 4u) {
            const auto value = as_i32(read_u32(source));
            write_u32(destination, configure_scaled_pow_b(value) - calibration);
        }

        write_u32(0x100d6894u, kZero);
        const std::uint32_t scaled_a_1 =
            configure_scaled_pow_a(as_i32(read_u32(0x1010608cu)));
        write_f64(0x100d63b0u,
                  static_cast<double>(as_i32(scaled_a_1)) * read_f64(0x1000c6e0u));

        const std::uint32_t scaled_a_2 =
            configure_scaled_pow_a(as_i32(read_u32(0x101060d0u)));
        write_f64(0x100d67e8u,
                  static_cast<double>(as_i32(scaled_a_2)) * read_f64(0x1000c6e0u));

        write_u32(0x100d68ecu,
                  configure_scaled_pow_a(-as_i32(read_u32(0x101060b0u))));

        const auto symmetric_input = as_i32(read_u32(0x10106080u));
        write_u32(0x10106084u, configure_scaled_pow_a(-symmetric_input));
        const std::uint32_t symmetric_pow = configure_scaled_pow_a(-symmetric_input);
        const auto symmetric_signed = as_i32(symmetric_pow);
        const auto symmetric_half = symmetric_signed / 2;
        write_f64(0x100d6350u, static_cast<double>(symmetric_half));

        write_u32(0x100d635cu,
                  configure_scaled_pow_a(-as_i32(read_u32(0x101060c0u))));

        configure_filter_coefficients(
            as_i32(read_u32(0x10106090u)),
            as_i32(read_u32(0x101060ccu)));
        configure_gain_pair(as_i32(read_u32(0x101060bcu)));

        write_f64(0x1010f390u, configure_time_coefficient(10, kSampleRate));
        write_f64(0x1010f398u, configure_time_coefficient(20, kSampleRate));
        write_u32(0x1010f3b0u, configure_scaled_pow_b(-10));

        write_u32(0x1010f3b8u, 0u);
        write_u32(0x1010f3bcu, 0u);
        write_u32(0x1010f3c0u, 0u);
        write_f64(0x1010f3c8u, -1.0);
        write_u32(0x100d6a1cu, 1u);
        write_f64(0x1010f420u, 1.0);
        write_f64(0x1010f428u, 1.0);
        write_f64(0x1010f458u, 1.0);
        write_u32(0x1010f440u, 0xffffu);
        write_f64(0x1010f418u, 1.0);
        write_f64(0x1010f3d8u, 1.0);
        write_f64(0x1010f3e0u, 1.0);
        write_f64(0x1010f410u, 1.0);
        write_u32(0x1010f3f8u, 0xffffu);
        write_f64(0x1010f3d0u, 1.0);

        write_u32(0x100d5f5cu,
                  configure_rate_power(as_i32(read_u32(0x101060acu)),
                                       static_cast<std::int32_t>(kSampleRate)));
        write_u32(0x100d688cu,
                  configure_scaled_pow_b(as_i32(read_u32(0x101060a0u))));

        for (std::uint32_t address = 0x1010eddcu;
             address < 0x1010f214u; address += 0xd8u) {
            write_u32(address,
                      configure_rate_power(as_i32(read_u32(0x101060c4u)),
                                           static_cast<std::int32_t>(kSampleRate)));
        }

        write_u32(0x1010f214u, 500u);
        write_u32(0x1010f2ecu, 500u);
        write_f64(0x1010ecf0u,
                  configure_time_coefficient(as_i32(read_u32(0x10106100u)),
                                             kSampleRate));
        write_f64(0x1010ed38u,
                  configure_time_coefficient(as_i32(read_u32(0x101060fcu)),
                                             kSampleRate));
        write_f64(0x1010ece8u,
                  configure_time_coefficient(as_i32(read_u32(0x10106108u)),
                                             kSampleRate));
        write_f64(0x1010ed30u,
                  configure_time_coefficient(as_i32(read_u32(0x10106104u)),
                                             kSampleRate));

        const double split_value =
            static_cast<double>(as_i32(read_u32(0x1010610cu)));
        const double split_scale = read_f64(0x1000c4e0u);
        write_f64(0x1010ed10u, 1.0);
        write_f64(0x1010ed58u, 1.0);
        write_f64(0x1010ece0u,
                  (read_f64(0x1000c6d0u) - split_value) * split_scale);
        write_f64(0x1010ed28u, split_value * split_scale);
    }

    void run_postload() {
        constexpr std::int32_t kMinimum = 10;
        constexpr std::int32_t kMaximum = 100;
        constexpr std::uint32_t kSampleRate = 44100u;

        for (std::uint32_t outer = 0x1010a874u;
             outer < 0x1010b228u; outer += 0x33cu) {
            for (unsigned band = 0; band < 7u; ++band) {
                const std::uint32_t address = outer + band * 0x9b4u;
                auto value = as_i32(read_u32(address));
                if (value < kMinimum) value = kMinimum;
                if (value > kMaximum) value = kMaximum;
                write_u32(address, static_cast<std::uint32_t>(value));
            }
        }

        for (std::uint32_t group = 0; group < 3u; ++group) {
            std::uint32_t source_end = 0x1010abb0u;
            std::uint32_t special_destination = 0x1010ee28u;
            std::uint32_t parameter = 0x1010a870u + group * 0x33cu;
            std::uint32_t result = 0x1010edc8u + group * 0x48u;
            std::uint32_t secondary_parameter = 0x1010a86cu;
            std::uint32_t secondary_result = 0x1010edc0u;

            while (source_end < 0x1010ef9cu) {
                if (group == 1u) {
                    const double divisor =
                        static_cast<double>(as_i32(read_u32(source_end)));
                    const double scale = read_f64(0x1000c010u);
                    write_f64(special_destination, 1.0 - scale / divisor);
                } else {
                    const double divisor =
                        static_cast<double>(as_i32(read_u32(parameter + 4u)));
                    const double scale = read_f64(0x1000c010u);
                    write_f64(result + 0x18u, scale / divisor - 1.0);
                }

                write_u32(result,
                          configure_scaled_pow_b(-as_i32(read_u32(parameter))));
                write_f64(result - 0x20u,
                          configure_time_coefficient(
                              as_i32(read_u32(parameter - 0x10u)), kSampleRate));
                write_f64(result - 0x18u,
                          configure_time_coefficient(
                              as_i32(read_u32(parameter - 0x0cu)), kSampleRate));
                write_f64(secondary_result - 8u,
                          configure_time_coefficient(
                              as_i32(read_u32(secondary_parameter - 4u)),
                              kSampleRate));
                write_f64(secondary_result,
                          configure_time_coefficient(
                              as_i32(read_u32(secondary_parameter)),
                              kSampleRate));

                source_end += 0x9b4u;
                parameter += 0x9b4u;
                special_destination += 0xd8u;
                result += 0xd8u;
                secondary_parameter += 0x9b4u;
                secondary_result += 0xd8u;
            }
        }

        for (std::uint32_t source = 0x1010a878u,
                           destination = 0x1010f4a0u;
             source < 0x1010d8fcu;
             source += 0x9b4u, destination += 4u) {
            write_u32(destination,
                      configure_scaled_pow_b(as_i32(read_u32(source))));
        }

        auto count = as_i32(read_u32(0x10106098u));
        if (count > 20) {
            count = 0;
            write_u32(0x10106098u, 0u);
            write_u32(0x1000dd0cu, 0u);
        } else {
            write_u32(0x1000dd0cu,
                      configure_rate_power(count,
                                           static_cast<std::int32_t>(kSampleRate)));
        }
    }

private:
    NamedStateStorage& globals_;

    template<class T>
    [[nodiscard]] T read_t(const std::uint32_t address) const {
        T value{};
        std::memcpy(&value, globals_.ptr(address, sizeof(T)), sizeof(T));
        return value;
    }

    template<class T>
    void write_t(const std::uint32_t address, const T value) {
        std::memcpy(globals_.ptr(address, sizeof(T)), &value, sizeof(T));
    }

    [[nodiscard]] std::uint32_t read_u32(const std::uint32_t address) const {
        return read_t<std::uint32_t>(address);
    }
    [[nodiscard]] std::uint64_t read_u64(const std::uint32_t address) const {
        return read_t<std::uint64_t>(address);
    }
    [[nodiscard]] double read_f64(const std::uint32_t address) const {
        return std::bit_cast<double>(read_u64(address));
    }
    void write_u32(const std::uint32_t address, const std::uint32_t value) {
        write_t(address, value);
    }
    void write_u64(const std::uint32_t address, const std::uint64_t value) {
        write_t(address, value);
    }
    void write_f64(const std::uint32_t address, const double value) {
        write_u64(address, std::bit_cast<std::uint64_t>(value));
    }

    [[nodiscard]] static std::int32_t as_i32(const std::uint32_t value) noexcept {
        return static_cast<std::int32_t>(value);
    }

    [[nodiscard]] static std::uint32_t trunc_saturated_to_u32(
        const double value) noexcept {
        std::int64_t converted{};
        if (std::isnan(value)) {
            converted = std::numeric_limits<std::int64_t>::min();
        } else if (value >= static_cast<double>(
                       std::numeric_limits<std::int64_t>::max())) {
            converted = std::numeric_limits<std::int64_t>::max();
        } else if (value <= static_cast<double>(
                       std::numeric_limits<std::int64_t>::min())) {
            converted = std::numeric_limits<std::int64_t>::min();
        } else {
            converted = static_cast<std::int64_t>(std::trunc(value));
        }
        return static_cast<std::uint32_t>(converted);
    }

    [[nodiscard]] std::uint32_t configure_square_to_i32(
        const double value) const noexcept {
        double result = value * value;
        result = result * read_f64(0x1000c710u);
        double linear = value * read_f64(0x1000c700u);
        result = result + linear;
        return trunc_saturated_to_u32(result);
    }

    [[nodiscard]] static std::uint32_t configure_rate_power(
        const std::int32_t first, const std::int32_t second) noexcept {
        const std::int64_t product_wide =
            static_cast<std::int64_t>(first) * static_cast<std::int64_t>(second);
        const auto product = static_cast<std::int32_t>(
            static_cast<std::uint32_t>(product_wide));
        const std::int64_t scaled =
            static_cast<std::int64_t>(static_cast<std::int32_t>(0x10624dd3u)) *
            static_cast<std::int64_t>(product);
        auto quotient = static_cast<std::int32_t>(
            static_cast<std::uint64_t>(scaled) >> 32u);
        quotient >>= 6;
        const auto correction = static_cast<std::uint32_t>(quotient) >> 31u;
        return static_cast<std::uint32_t>(quotient) + correction;
    }

    [[nodiscard]] double configure_time_coefficient(
        const std::int32_t time_value,
        const std::uint32_t sample_rate) const {
        double exponent = read_f64(0x1000c720u) /
            static_cast<double>(static_cast<std::int32_t>(sample_rate));
        double divisor = static_cast<double>(time_value) * read_f64(0x1000c500u);
        exponent = exponent / divisor;
        return std::pow(read_f64(0x1000c730u), exponent);
    }

    [[nodiscard]] std::uint32_t configure_scaled_pow_a(
        const std::int32_t value) const {
        const double exponent = static_cast<double>(value) * read_f64(0x1000c760u);
        double result = std::pow(read_f64(0x1000c010u), exponent);
        result = result * read_f64(0x1000c690u);
        return trunc_saturated_to_u32(result);
    }

    [[nodiscard]] std::uint32_t configure_scaled_pow_b(
        const std::int32_t value) const {
        const double exponent = static_cast<double>(value) * read_f64(0x1000c770u);
        double result = std::pow(read_f64(0x1000c010u), exponent);
        result = result * read_f64(0x1000c690u);
        return trunc_saturated_to_u32(result);
    }

    void configure_filter_coefficients(std::int32_t selector,
                                       const std::int32_t frequency_value) {
        const std::uint32_t mode_flags = read_u32(0x101060f0u);
        if ((mode_flags & 0x40u) != 0u) {
            selector /= 3;
        }

        double frequency = static_cast<double>(frequency_value) *
            read_f64(0x1000c7b0u);
        frequency = frequency * read_f64(0x1000c7a0u);

        const double power = std::pow(
            read_f64(0x1000c010u),
            static_cast<double>(selector) * read_f64(0x1000c760u));
        const std::uint32_t mode = mode_flags & 0x20u;
        const double power_scaled = power * read_f64(0x1000c790u);

        if (read_u32(0x100d6250u) != mode) {
            write_u32(0x100d6250u, mode);
            for (std::uint32_t address = 0x100d7660u;
                 address < 0x100d7688u; address += 4u) {
                write_u32(address, 0u);
            }
        }

        if (selector <= 0) {
            write_f64(0x100d76a0u, 1.0);
            write_f64(0x100d76a8u, 0.0);
            write_f64(0x100d76b0u, 0.0);
            write_f64(0x100d76b8u, 0.0);
            write_f64(0x100d76c0u, 0.0);
            return;
        }

        const double power_scaled_sq = power_scaled * power_scaled;
        const double power_sq = power * power;
        const double q = std::sqrt(
            (power_scaled_sq - 1.0) / (power_sq - power_scaled_sq));
        const double angle = mode != 0u
            ? frequency * read_f64(0x1000c620u)
            : read_f64(0x1000c780u);
        const double k = q * std::tan(angle);
        const double cosine = std::cos(frequency);
        const double k_power = k * power;
        const double denominator = k + 1.0;

        write_f64(0x100d76a0u, (k_power + 1.0) / denominator);
        if (mode != 0u) {
            write_f64(0x100d76a8u, (k_power - 1.0) / denominator);
            write_f64(0x100d76b0u, 0.0);
            write_f64(0x100d76b8u, (k - 1.0) / denominator);
            write_f64(0x100d76c0u, 0.0);
        } else {
            const double cosine_term = -(cosine + cosine) / denominator;
            write_f64(0x100d76a8u, cosine_term);
            write_f64(0x100d76b0u, (1.0 - k_power) / denominator);
            write_f64(0x100d76b8u, cosine_term);
            write_f64(0x100d76c0u, (1.0 - k) / denominator);
        }
    }

    void configure_gain_pair(const std::int32_t value) {
        double exponent = static_cast<double>(value) * read_f64(0x1000c7a0u);
        exponent = exponent * read_f64(0x1000c7c0u);
        const double result = std::pow(read_f64(0x1000c730u), exponent);
        double symmetric = result + read_f64(0x1000c000u);
        symmetric = symmetric * read_f64(0x1000c620u);
        write_f64(0x10010468u, symmetric);
        write_f64(0x10010470u, -symmetric);
        write_f64(0x10010478u, result);
    }
};


} // namespace

struct NamedStateEngine::Impl final {
    Impl() : machine(globals, &hot_caches) {}
    NamedStateStorage globals;
    HotControlCaches hot_caches;
    NativeProcessExecutor machine;
};

NamedStateEngine::NamedStateEngine()
    : impl_(std::make_unique<Impl>()) {
    initialize_static_image();
}
NamedStateEngine::~NamedStateEngine() = default;
void NamedStateEngine::initialize_static_image() {
    impl_->globals.clear();
    impl_->globals.copy_from(kGlobalBase, kRdata, sizeof(kRdata));
    impl_->globals.copy_from(0x1000d000u, kData, sizeof(kData));
}
void NamedStateEngine::copy_dat(const DatFile& config) {
    const auto& raw = config.raw();
    impl_->globals.copy_from(state_address::signature, &raw.signature, sizeof(raw.signature));
    impl_->globals.copy_from(state_address::process_base, raw.process.data(), sizeof(raw.process));
    impl_->globals.copy_from(state_address::common_base, &raw.common, sizeof(raw.common));
}
void NamedStateEngine::run_postload(){
    NativeColdControl(impl_->globals).run_postload();
}
void NamedStateEngine::run_configure(){
    NativeColdControl(impl_->globals).run_configure();
}
void NamedStateEngine::build_init_tables(){
    auto& m=impl_->machine;
    const double angle=m.read_global_f64(state_address::sample_percent_scale),scale=m.read_global_f64(0x1000c4d0u);
    for(std::uint32_t a=0x100d6b60u,i=0;a<0x100d7530u;a+=4u,++i)m.write_global_u32(a,static_cast<std::uint32_t>(static_cast<std::int32_t>(std::trunc(std::sin(static_cast<double>(i)*angle)*scale))));
    const double table_scale=m.read_global_f64(state_address::table_scale);
    for(std::uint32_t src=state_address::init_table_source,dst=state_address::init_table_destination;src<0x1000c0f8u;src+=8u,dst+=4u)m.write_global_u32(dst,static_cast<std::uint32_t>(static_cast<std::int32_t>(std::trunc(m.read_global_f64(src)*table_scale))));
}
void NamedStateEngine::run_reset(){impl_->machine.reset_named_state();}
void NamedStateEngine::load_config(const DatFile& config){initialize_static_image();copy_dat(config);run_postload();run_configure();build_init_tables();impl_->machine.prepare_hot_constants();run_reset();initialized_=true;}
void NamedStateEngine::reset(){if(initialized_)run_reset();}
bool NamedStateEngine::process(std::span<std::int16_t> samples,std::size_t channels,std::uint32_t sample_rate,std::string& error) noexcept {
    try {
        if(!initialized_)throw std::runtime_error("DSP configuration is not loaded");
        auto& m=impl_->machine;
        const std::array<std::uint32_t,6> args={0u,kAudioBase,static_cast<std::uint32_t>(samples.size()/channels),16u,static_cast<std::uint32_t>(channels),sample_rate};
        m.run_process(args, samples);
        error.clear();return true;
    } catch(const std::exception& e){error=e.what();return false;} catch(...){error="unknown named-state core failure";return false;}
}

std::size_t native_process_executor_bytes() noexcept {
    return sizeof(NativeProcessExecutor);
}

std::size_t hot_control_cache_bytes() noexcept {
    return sizeof(HotControlCaches);
}

std::size_t continuation_state_bytes() noexcept {
    return 0u;
}

std::size_t persistent_continuation_bytes() noexcept {
    return 0u;
}

} // namespace ssnative::detail

#undef SSNATIVE_ALWAYS_INLINE
