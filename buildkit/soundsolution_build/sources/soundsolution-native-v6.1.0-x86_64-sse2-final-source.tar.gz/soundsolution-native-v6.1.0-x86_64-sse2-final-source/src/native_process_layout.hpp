#pragma once

#include <cstddef>
#include <cstdint>

namespace ssnative::detail::native_process {

// The structured process body uses one call-local native scratch frame.
// Control flow is represented by a typed C++ stage loop: no goto statements,
// numeric code labels, runtime instruction table, dispatcher, continuation
// stack, x86 register names, or persistent process-control state remain.
inline constexpr std::size_t kProcessFrameBytes = 512u;
inline constexpr std::uint32_t kFrameCompatibilityBase = 0x70000e00u;
inline constexpr std::uint32_t kFrameCompatibilityEnd =
    kFrameCompatibilityBase + static_cast<std::uint32_t>(kProcessFrameBytes);
inline constexpr std::uint32_t kInitialFrameCursor =
    kFrameCompatibilityBase + 0x100u;

inline constexpr std::size_t kConfigureStackPhysicalBytes = 0u;
inline constexpr std::size_t kPostloadStackPhysicalBytes = 0u;
inline constexpr std::size_t kColdStackPhysicalBytes = 0u;
inline constexpr std::size_t kContinuationCapacity = 0u;
inline constexpr std::size_t kControlDomainCount = 0u;
inline constexpr std::size_t kConfigureContinuationStateBytes = 0u;
inline constexpr std::size_t kPostloadContinuationStateBytes = 0u;
inline constexpr std::size_t kNativeConfigureFunctionCount = 8u;
inline constexpr std::size_t kNativeConfigureStaticOperationCount = 0u;
inline constexpr std::size_t kNativePostloadFunctionCount = 1u;
inline constexpr std::size_t kNativePostloadDirectCallCount = 6u;
inline constexpr std::size_t kNativePostloadStaticOperationCount = 0u;
inline constexpr std::size_t kProcessProgramInstructionCount = 0u;
inline constexpr std::size_t kDirectProcessBodyCount = 978u;
inline constexpr std::size_t kStructuredProcessStageCount = 87u;
inline constexpr std::size_t kProcessGotoCount = 0u;
inline constexpr std::size_t kProcessNumericLabelCount = 0u;
inline constexpr std::size_t kLegacyRegisterIdentifierCount = 0u;
inline constexpr std::size_t kFoldedNativeHotOperationCount = 53u;

static_assert((kProcessFrameBytes % alignof(std::uint64_t)) == 0u);
static_assert(kProcessFrameBytes >= 480u);
static_assert(kInitialFrameCursor >= kFrameCompatibilityBase);
static_assert(kInitialFrameCursor < kFrameCompatibilityEnd);

} // namespace ssnative::detail::native_process
