#include <cerrno>
#include <climits>
#include <cstddef>

namespace {

constexpr int digit_value(const unsigned char ch) noexcept {
    if (ch >= static_cast<unsigned char>('0') && ch <= static_cast<unsigned char>('9')) {
        return static_cast<int>(ch - static_cast<unsigned char>('0'));
    }
    if (ch >= static_cast<unsigned char>('a') && ch <= static_cast<unsigned char>('z')) {
        return 10 + static_cast<int>(ch - static_cast<unsigned char>('a'));
    }
    if (ch >= static_cast<unsigned char>('A') && ch <= static_cast<unsigned char>('Z')) {
        return 10 + static_cast<int>(ch - static_cast<unsigned char>('A'));
    }
    return -1;
}

constexpr bool is_space(const unsigned char ch) noexcept {
    return ch == static_cast<unsigned char>(' ') ||
           ch == static_cast<unsigned char>('\t') ||
           ch == static_cast<unsigned char>('\n') ||
           ch == static_cast<unsigned char>('\r') ||
           ch == static_cast<unsigned char>('\f') ||
           ch == static_cast<unsigned char>('\v');
}

} // namespace

// GCC 14/glibc 2.38+ headers redirect strtoul to this symbol.  Defining it
// locally keeps the generated binary usable on Debian 12 (glibc 2.36).
extern "C" unsigned long __isoc23_strtoul(
    const char* input,
    char** end_pointer,
    int base) noexcept {
    const char* const original = input;

    if (input == nullptr || (base != 0 && (base < 2 || base > 36))) {
        errno = EINVAL;
        if (end_pointer != nullptr) {
            *end_pointer = const_cast<char*>(original);
        }
        return 0UL;
    }

    while (is_space(static_cast<unsigned char>(*input))) {
        ++input;
    }

    bool negative = false;
    if (*input == '+' || *input == '-') {
        negative = (*input == '-');
        ++input;
    }

    if ((base == 0 || base == 16) && input[0] == '0' &&
        (input[1] == 'x' || input[1] == 'X') && digit_value(static_cast<unsigned char>(input[2])) >= 0 &&
        digit_value(static_cast<unsigned char>(input[2])) < 16) {
        base = 16;
        input += 2;
    } else if ((base == 0 || base == 2) && input[0] == '0' &&
               (input[1] == 'b' || input[1] == 'B') &&
               (input[2] == '0' || input[2] == '1')) {
        base = 2;
        input += 2;
    } else if (base == 0) {
        base = (*input == '0') ? 8 : 10;
    }

    const char* const digits_begin = input;
    unsigned long value = 0UL;
    bool overflow = false;

    for (;;) {
        const int digit = digit_value(static_cast<unsigned char>(*input));
        if (digit < 0 || digit >= base) {
            break;
        }

        const unsigned long unsigned_digit = static_cast<unsigned long>(digit);
        if (value > (ULONG_MAX - unsigned_digit) / static_cast<unsigned long>(base)) {
            overflow = true;
        } else if (!overflow) {
            value = value * static_cast<unsigned long>(base) + unsigned_digit;
        }
        ++input;
    }

    if (input == digits_begin) {
        if (end_pointer != nullptr) {
            *end_pointer = const_cast<char*>(original);
        }
        return 0UL;
    }

    if (end_pointer != nullptr) {
        *end_pointer = const_cast<char*>(input);
    }

    if (overflow) {
        errno = ERANGE;
        return ULONG_MAX;
    }

    return negative ? (0UL - value) : value;
}
