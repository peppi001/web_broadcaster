#include "kernels.hpp"

#include <cmath>
#include <cstdint>
#include <limits>

namespace ssnative::detail {
namespace {

[[nodiscard]] std::int32_t truncate_to_i32(const double value) noexcept {
    if (value >= static_cast<double>(std::numeric_limits<std::int32_t>::max())) {
        return std::numeric_limits<std::int32_t>::max();
    }
    if (value <= static_cast<double>(std::numeric_limits<std::int32_t>::min())) {
        return std::numeric_limits<std::int32_t>::min();
    }
    return static_cast<std::int32_t>(value);
}

[[nodiscard]] double process_biquad_channel(
    const BiquadCoefficients& c,
    std::array<double, 2>& state,
    const double input) noexcept {
    // x87 order from 0x10008AC0:
    // w0 = input - a1*w1 - a2*w2
    // y  = b0*w0 + b1*w1 + b2*w2
    const double w0 = input - c.a[0] * state[0] - c.a[1] * state[1];
    const double output = c.b[0] * w0 + c.b[1] * state[0] +
                          c.b[2] * state[1];
    state[1] = state[0];
    state[0] = w0;
    return output;
}

[[nodiscard]] double process_fourth_order_channel(
    const FourthOrderCoefficients& c,
    std::array<double, 4>& state,
    const double input) noexcept {
    const double w0 = input - c.a[0] * state[0] - c.a[1] * state[1] -
                      c.a[2] * state[2] - c.a[3] * state[3];
    const double output = c.b[0] * w0 + c.b[1] * state[0] +
                          c.b[2] * state[1] + c.b[3] * state[2] +
                          c.b[4] * state[3];
    state[3] = state[2];
    state[2] = state[1];
    state[1] = state[0];
    state[0] = w0;
    return output;
}

} // namespace

void process_stereo_one_pole(const OnePoleCoefficients& c,
                             StereoOnePoleState& state,
                             double& left,
                             double& right) noexcept {
    const double old_left = state.left_previous;
    const double next_left = left - c.feedback * old_left;
    left = c.current_weight * next_left + c.previous_weight * old_left;
    state.left_previous = next_left;

    const double old_right = state.right_previous;
    const double next_right = right - c.feedback * old_right;
    right = c.current_weight * next_right + c.previous_weight * old_right;
    state.right_previous = next_right;
}

void process_stereo_biquad(const BiquadCoefficients& c,
                           StereoBiquadState& state,
                           double& left,
                           double& right) noexcept {
    left = process_biquad_channel(c, state.left, left);
    right = process_biquad_channel(c, state.right, right);
}

void process_stereo_fourth_order(const FourthOrderCoefficients& c,
                                 StereoFourthOrderState& state,
                                 double& left,
                                 double& right) noexcept {
    left = process_fourth_order_channel(c, state.left, left);
    right = process_fourth_order_channel(c, state.right, right);
}

double soft_clip(const double sample,
                 const double threshold,
                 const double knee) noexcept {
    const double magnitude = std::abs(sample);
    if (magnitude < threshold) {
        return sample;
    }
    const double excess = magnitude - threshold;
    const double clipped = threshold + (excess * knee) / (knee + excess);
    return sample < 0.0 ? -clipped : clipped;
}

void soft_clip_stereo(double& left,
                      double& right,
                      const double threshold,
                      const double knee) noexcept {
    left = soft_clip(left, threshold, knee);
    right = soft_clip(right, threshold, knee);
}

void smooth_toward_min(const double input,
                       double& state,
                       const std::int32_t percent) noexcept {
    const double target = input < state ? input : state;
    state = (static_cast<double>(100 - percent) * state +
             static_cast<double>(percent) * target) * 0.01;
}

std::int32_t multiply_milli(const std::int32_t a,
                            const std::int32_t b) noexcept {
    const std::int64_t product = static_cast<std::int64_t>(a) *
                                 static_cast<std::int64_t>(b);
    return static_cast<std::int32_t>(product / 1000);
}

std::int32_t quadratic_map(const double value) noexcept {
    return truncate_to_i32(205.4 * value * value + 663.4 * value);
}

} // namespace ssnative::detail
