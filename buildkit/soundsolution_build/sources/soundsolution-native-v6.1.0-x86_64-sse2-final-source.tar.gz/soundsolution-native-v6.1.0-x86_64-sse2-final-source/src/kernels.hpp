#pragma once

#include <array>
#include <cstdint>

namespace ssnative::detail {

// Literal C++ translations of standalone x87 kernels in the original DLL.
// Names describe the resulting algebra; the original addresses are kept in
// comments and tests so every translation remains traceable.

struct OnePoleCoefficients {
    double previous_weight{}; // original +0x00
    double current_weight{};  // original +0x08
    double feedback{};        // original +0x10
};

struct StereoOnePoleState {
    double left_previous{};
    double right_previous{};
};

// Original function 0x10008B60.
void process_stereo_one_pole(const OnePoleCoefficients& coefficients,
                             StereoOnePoleState& state,
                             double& left,
                             double& right) noexcept;

struct BiquadCoefficients {
    std::array<double, 3> b{};
    std::array<double, 2> a{};
};

struct StereoBiquadState {
    std::array<double, 2> left{};
    std::array<double, 2> right{};
};

// Original function 0x10008AC0, transposed/direct-form-II state ordering.
void process_stereo_biquad(const BiquadCoefficients& coefficients,
                           StereoBiquadState& state,
                           double& left,
                           double& right) noexcept;

struct FourthOrderCoefficients {
    std::array<double, 5> b{};
    std::array<double, 4> a{};
};

struct StereoFourthOrderState {
    std::array<double, 4> left{};
    std::array<double, 4> right{};
};

// Original function 0x10008BD0.
void process_stereo_fourth_order(const FourthOrderCoefficients& coefficients,
                                 StereoFourthOrderState& state,
                                 double& left,
                                 double& right) noexcept;

// Original functions 0x10008FF0 (single channel) and 0x10009070 (stereo).
[[nodiscard]] double soft_clip(double sample,
                               double threshold,
                               double knee) noexcept;
void soft_clip_stereo(double& left,
                      double& right,
                      double threshold,
                      double knee) noexcept;

// Original function 0x100095C0. It moves state only toward a lower input,
// using an integer percentage exactly as the DLL does.
void smooth_toward_min(double input,
                       double& state,
                       std::int32_t percent) noexcept;

// Original function 0x10007B20: signed (a*b)/1000 with truncation toward zero.
[[nodiscard]] std::int32_t multiply_milli(std::int32_t a,
                                          std::int32_t b) noexcept;

// Original function 0x10007AC0 followed by _ftol.
[[nodiscard]] std::int32_t quadratic_map(double value) noexcept;

} // namespace ssnative::detail
