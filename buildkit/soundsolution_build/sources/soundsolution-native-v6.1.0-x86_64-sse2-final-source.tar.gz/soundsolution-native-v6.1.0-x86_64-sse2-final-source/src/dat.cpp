#include "ssnative/dat.hpp"

#include <algorithm>
#include <cstring>
#include <fstream>
#include <stdexcept>
#include <vector>

namespace ssnative {
namespace {

[[nodiscard]] std::string fixed_c_string(const char* data, const std::size_t size) {
    const auto* end = std::find(data, data + size, '\0');
    return std::string(data, end);
}

void validate_image(const DatImageRaw& image) {
    if (image.signature != kDatSignature) {
        throw std::runtime_error("unsupported Sound Solution DAT signature");
    }
    if (fixed_c_string(image.version.data(), image.version.size()) != "2.0") {
        throw std::runtime_error("unsupported Sound Solution DAT version");
    }
}

} // namespace

DatFile DatFile::load(const std::filesystem::path& path) {
    std::ifstream input(path, std::ios::binary);
    if (!input) {
        throw std::runtime_error("cannot open DAT file: " + path.string());
    }

    input.seekg(0, std::ios::end);
    const auto length = input.tellg();
    if (length != static_cast<std::streamoff>(kDatFileSize)) {
        throw std::runtime_error("invalid DAT size: expected 18418 bytes");
    }
    input.seekg(0, std::ios::beg);

    std::array<std::byte, kDatFileSize> bytes{};
    input.read(reinterpret_cast<char*>(bytes.data()),
               static_cast<std::streamsize>(bytes.size()));
    if (!input) {
        throw std::runtime_error("failed to read complete DAT file");
    }
    return from_bytes(bytes);
}

DatFile DatFile::from_bytes(const std::span<const std::byte> bytes) {
    if (bytes.size() != kDatFileSize) {
        throw std::runtime_error("invalid DAT byte count");
    }

    DatImageRaw image{};
    std::memcpy(&image, bytes.data(), sizeof(image));
    validate_image(image);
    return DatFile(image);
}

void DatFile::save(const std::filesystem::path& path) const {
    validate_image(image_);
    std::ofstream output(path, std::ios::binary | std::ios::trunc);
    if (!output) {
        throw std::runtime_error("cannot create DAT file: " + path.string());
    }
    const auto bytes = to_bytes();
    output.write(reinterpret_cast<const char*>(bytes.data()),
                 static_cast<std::streamsize>(bytes.size()));
    if (!output) {
        throw std::runtime_error("failed to write complete DAT file");
    }
}

std::array<std::byte, kDatFileSize> DatFile::to_bytes() const noexcept {
    std::array<std::byte, kDatFileSize> bytes{};
    std::memcpy(bytes.data(), &image_, sizeof(image_));
    return bytes;
}

std::string DatFile::version_string() const {
    return fixed_c_string(image_.version.data(), image_.version.size());
}

std::string DatFile::name() const {
    return fixed_c_string(image_.common.name.data(), image_.common.name.size());
}

void DatFile::set_name(const std::string_view value) {
    if (value.size() >= image_.common.name.size()) {
        throw std::runtime_error("DAT name is too long (maximum 59 bytes)");
    }
    image_.common.name.fill('\0');
    std::copy(value.begin(), value.end(), image_.common.name.begin());
}

const ProcessRecordRaw& DatFile::process(const std::size_t band,
                                         const std::size_t stage) const {
    if (band >= kProcessBandCount || stage >= kProcessStageCount) {
        throw std::out_of_range("Sound Solution process index out of range");
    }
    return image_.process.at(process_index(band, stage));
}

ProcessRecordRaw& DatFile::process(const std::size_t band,
                                   const std::size_t stage) {
    if (band >= kProcessBandCount || stage >= kProcessStageCount) {
        throw std::out_of_range("Sound Solution process index out of range");
    }
    return image_.process.at(process_index(band, stage));
}

bool DatFile::is_supported() const noexcept {
    return image_.signature == kDatSignature &&
           image_.version[0] == '2' && image_.version[1] == '.' &&
           image_.version[2] == '0' && image_.version[3] == '\0';
}

} // namespace ssnative
