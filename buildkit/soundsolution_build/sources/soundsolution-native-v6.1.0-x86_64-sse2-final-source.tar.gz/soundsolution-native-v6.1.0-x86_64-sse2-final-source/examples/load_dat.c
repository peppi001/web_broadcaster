#include "ssnative/ssnative.h"

#include <stdio.h>

int main(int argc, char** argv) {
    if (argc != 2) {
        fprintf(stderr, "usage: %s config.dat\n", argv[0]);
        return 2;
    }

    ssnative_dsp* dsp = ssnative_create();
    if (dsp == NULL) {
        fprintf(stderr, "cannot allocate DSP\n");
        return 1;
    }

    const ssnative_status status = ssnative_load_dat(dsp, argv[1]);
    if (status != SSNATIVE_STATUS_OK) {
        fprintf(stderr, "%s: %s\n",
                ssnative_status_string(status), ssnative_last_error(dsp));
        ssnative_destroy(dsp);
        return 1;
    }

    puts("DAT loaded successfully");
    ssnative_destroy(dsp);
    return 0;
}
