#include "ssnative/ssnative.h"

#include <algorithm>
#include <cerrno>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <limits>
#include <vector>

namespace {

bool parse_u32(const char* text, std::uint32_t& value) {
    if (text == nullptr || *text == '\0') return false;
    errno = 0;
    char* end = nullptr;
    const unsigned long parsed = std::strtoul(text, &end, 10);
    if (errno != 0 || end == text || *end != '\0' ||
        parsed > std::numeric_limits<std::uint32_t>::max()) {
        return false;
    }
    value = static_cast<std::uint32_t>(parsed);
    return true;
}

int print_failure(ssnative_dsp* dsp, const char* operation, ssnative_status status) {
    std::fprintf(stderr, "%s failed: %s", operation, ssnative_status_string(status));
    if (dsp != nullptr) {
        const char* detail = ssnative_last_error(dsp);
        if (detail != nullptr && *detail != '\0') std::fprintf(stderr, " (%s)", detail);
    }
    std::fputc('\n', stderr);
    return 1;
}

} // namespace

int main(int argc, char** argv) {
    if (argc != 4) {
        std::fprintf(stderr,
                     "Usage: %s CONFIG.dat CHANNELS SAMPLE_RATE\n"
                     "Reads raw signed 16-bit little-endian interleaved PCM from stdin\n"
                     "and writes processed PCM to stdout.\n",
                     argv[0]);
        return 2;
    }

    std::uint32_t channels = 0;
    std::uint32_t sample_rate = 0;
    if (!parse_u32(argv[2], channels) || !parse_u32(argv[3], sample_rate) ||
        (channels != 1U && channels != 2U) || sample_rate < 44100U) {
        std::fprintf(stderr, "CHANNELS must be 1 or 2; SAMPLE_RATE must be at least 44100.\n");
        return 2;
    }

#if defined(_WIN32)
    _setmode(_fileno(stdin), _O_BINARY);
    _setmode(_fileno(stdout), _O_BINARY);
#endif

    ssnative_dsp* dsp = ssnative_create();
    if (dsp == nullptr) {
        std::fprintf(stderr, "ssnative_create failed: out of memory\n");
        return 1;
    }

    ssnative_status status = ssnative_load_dat(dsp, argv[1]);
    if (status != SSNATIVE_STATUS_OK) {
        const int result = print_failure(dsp, "configuration load", status);
        ssnative_destroy(dsp);
        return result;
    }

    std::size_t frames_per_block = 1024U;
    if (const char* block_text = std::getenv("SSNATIVE_BLOCK_FRAMES");
        block_text != nullptr && *block_text != '\0') {
        std::uint32_t parsed_block = 0;
        if (!parse_u32(block_text, parsed_block) || parsed_block == 0U ||
            parsed_block > 1048576U) {
            std::fprintf(stderr, "SSNATIVE_BLOCK_FRAMES must be between 1 and 1048576.\n");
            ssnative_destroy(dsp);
            return 2;
        }
        frames_per_block = parsed_block;
    }
    std::vector<std::int16_t> samples(frames_per_block * channels);
    const std::size_t frame_bytes = static_cast<std::size_t>(channels) * sizeof(std::int16_t);
    std::vector<unsigned char> pending(frame_bytes);
    std::size_t pending_size = 0;

    for (;;) {
        unsigned char* byte_buffer = reinterpret_cast<unsigned char*>(samples.data());
        if (pending_size != 0U) {
            std::copy_n(pending.data(), pending_size, byte_buffer);
        }

        const std::size_t capacity = samples.size() * sizeof(samples[0]);
        const std::size_t read = std::fread(byte_buffer + pending_size, 1U,
                                           capacity - pending_size, stdin);
        std::size_t total = pending_size + read;

        if (total == 0U) {
            if (std::ferror(stdin) != 0) {
                std::perror("stdin read");
                ssnative_destroy(dsp);
                return 1;
            }
            break;
        }

        const std::size_t complete_bytes = total - (total % frame_bytes);
        pending_size = total - complete_bytes;
        if (pending_size != 0U) {
            std::copy_n(byte_buffer + complete_bytes, pending_size, pending.data());
        }

        if (complete_bytes != 0U) {
            const std::size_t frames = complete_bytes / frame_bytes;
            status = ssnative_process_s16_interleaved(
                dsp, samples.data(), frames, channels, sample_rate);
            if (status != SSNATIVE_STATUS_OK) {
                const int result = print_failure(dsp, "audio processing", status);
                ssnative_destroy(dsp);
                return result;
            }
            if (std::fwrite(byte_buffer, 1U, complete_bytes, stdout) != complete_bytes) {
                std::perror("stdout write");
                ssnative_destroy(dsp);
                return 1;
            }
        }

        if (read == 0U) {
            if (std::ferror(stdin) != 0) {
                std::perror("stdin read");
                ssnative_destroy(dsp);
                return 1;
            }
            break;
        }
    }

    if (pending_size != 0U) {
        std::fprintf(stderr, "Input ended with an incomplete PCM frame (%zu trailing byte(s)).\n",
                     pending_size);
        ssnative_destroy(dsp);
        return 1;
    }

    if (std::fflush(stdout) != 0) {
        std::perror("stdout flush");
        ssnative_destroy(dsp);
        return 1;
    }

    ssnative_destroy(dsp);
    return 0;
}
