#!/usr/bin/env python3
"""Audit the SoundSolution 6.1.0 structured process-flow milestone."""
from __future__ import annotations
import argparse
import re
from pathlib import Path


def extract_function(text: str, signature: str) -> str:
    start = text.find(signature)
    if start < 0:
        raise SystemExit(f'missing function: {signature}')
    brace = text.find('{', start)
    if brace < 0:
        raise SystemExit(f'missing function body: {signature}')
    depth = 0
    in_line = False
    in_block = False
    quote = None
    escaped = False
    index = brace
    while index < len(text):
        ch = text[index]
        nxt = text[index + 1] if index + 1 < len(text) else ''
        if in_line:
            if ch == '\n':
                in_line = False
        elif in_block:
            if ch == '*' and nxt == '/':
                in_block = False
                index += 1
        elif quote is not None:
            if escaped:
                escaped = False
            elif ch == '\\':
                escaped = True
            elif ch == quote:
                quote = None
        else:
            if ch == '/' and nxt == '/':
                in_line = True
                index += 1
            elif ch == '/' and nxt == '*':
                in_block = True
                index += 1
            elif ch in ('"', "'"):
                quote = ch
            elif ch == '{':
                depth += 1
            elif ch == '}':
                depth -= 1
                if depth == 0:
                    return text[brace + 1:index]
        index += 1
    raise SystemExit(f'unterminated function body: {signature}')


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    engine_path = root / 'src/named_state_engine.cpp'
    layout_path = root / 'src/native_process_layout.hpp'
    double_path = root / 'src/native_double.hpp'
    for path in (engine_path, layout_path, double_path):
        if not path.is_file():
            raise SystemExit(f'missing audit source: {path}')

    retired = (
        'src/native_process_body.inc', 'src/native_control_process.inc',
        'src/process_program.inc', 'src/native_control_configure.inc',
        'src/native_control_postload.inc', 'src/reconstructed_program.inc',
        'src/native_process_direct.inc', 'src/native_control_layout.hpp',
        'src/x87_compat.hpp')
    remains = [name for name in retired if (root / name).exists()]
    if remains:
        raise SystemExit('retired execution sources remain: ' + ', '.join(remains))

    code_inc = [p.name for p in (root / 'src').glob('*.inc')
                if p.name not in {'original_data.inc', 'original_rdata.inc'}]
    if code_inc:
        raise SystemExit('unexpected executable/source include fragments: ' +
                         ', '.join(sorted(code_inc)))

    engine = engine_path.read_text(encoding='utf-8')
    layout = layout_path.read_text(encoding='utf-8')
    native_double = double_path.read_text(encoding='utf-8')
    body = extract_function(engine, 'void execute_native_process()')
    combined = engine + '\n' + layout + '\n' + native_double

    forbidden = (
        'struct Instruction', 'struct Operand',
        'enum class Reg', 'enum class Op', 'execute_static<',
        'branch_cmp_static<', 'ProcessContinuation',
        'NativeContinuationState', 'RETURN_DISPATCH', 'enter_native_call',
        'leave_native_call', 'floating.top', 'floating.depth', 'fp.top',
        'fp.depth', 'void fpush(', 'NativeDouble fpop(',
        '#include "native_process_body.inc"', '#include "native_control_process.inc"',
        '#include "process_program.inc"', 'class CompatibilityControlMachine',
        'run_function(std::uint32_t entry', 'const Instruction& fetch(',
        'void execute_op(const Instruction&', 'using X87 =', 'x87_')
    residue = [fragment for fragment in forbidden if fragment in combined]
    if residue:
        raise SystemExit('retired process residue remains: ' + ', '.join(residue))

    legacy_registers = re.findall(r'\b(?:eax|ebx|ecx|edx|esi|edi|esp|ebp)\b', body)
    if legacy_registers:
        raise SystemExit('legacy x86 register identifiers remain in process body')

    numeric_labels = re.findall(r'^\s*L_[0-9a-fA-F]+:', body, re.M)
    if numeric_labels:
        raise SystemExit('numeric process labels remain')

    required = (
        'struct ProcessCondition', 'struct ProcessFlow final',
        'struct ProcessFloatingValues final', 'struct ProcessCallState final',
        'class NativeProcessExecutor', 'enum class ProcessStage : std::uint8_t',
        'for (;;) {', 'switch (stage)', 'void execute_native_process()',
        'class NativeColdControl final', 'using NativeDouble = long double;',
        'kProcessFrameBytes = 512u', 'kContinuationCapacity = 0u',
        'kControlDomainCount = 0u', 'kProcessProgramInstructionCount = 0u',
        'kDirectProcessBodyCount = 978u', 'kStructuredProcessStageCount = 87u',
        'kProcessGotoCount = 0u', 'kProcessNumericLabelCount = 0u',
        'kLegacyRegisterIdentifierCount = 0u')
    absent = [fragment for fragment in required if fragment not in combined]
    if absent:
        raise SystemExit('missing structured implementation: ' + ', '.join(absent))

    cases = re.findall(r'case\s+ProcessStage::([A-Za-z0-9_]+)\s*:', body)
    if len(cases) != 87 or len(set(cases)) != 87:
        raise SystemExit(f'structured stage audit failed: cases={len(cases)} unique={len(set(cases))}')
    assignments = re.findall(r'stage\s*=\s*ProcessStage::', body)
    if not assignments:
        raise SystemExit('structured process transitions are missing')
    if re.search(r'/\*[^\n]*original-index=', body):
        raise SystemExit('mechanical instruction comments remain in structured process body')

    lines = [
        'SoundSolution 6.1.0 structured process-flow audit',
        '=================================================',
        'Process source include: absent',
        'Executable process .inc fragments: 0',
        'Runtime instruction table: absent',
        'Runtime instruction interpreter: absent',
        'Operand/register dispatcher: absent',
        'Continuation state: 0 bytes',
        'Persistent process workspace: 0 bytes',
        'Legacy control domains: 0',
        'Configure: direct stackless C++',
        'Postload: direct stackless C++',
        'Reset: direct named-state C++',
        'Process: typed structured C++ stage loop',
        'Process call-local native frame: 512 bytes',
        'Direct process body operations: 978',
        f'Structured process stages: {len(cases)}',
        f'Structured process transitions: {len(assignments)}',
        'Process goto statements: 0',
        'Numeric process labels: 0',
        'Legacy x86 register identifiers: 0',
        'x87 compatibility identifiers: 0',
        'Audio-path heap allocations: 0',
        'Hot process cache bytes: 8704',
    ]
    report = '\n'.join(lines) + '\n'
    print(report, end='')
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(report, encoding='utf-8')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
