#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="${1:-$ROOT/_dist/TOOLCHAIN-ACTUAL.txt}"
mkdir -p "$(dirname -- "$OUT")"
{
    echo "Captured UTC: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
    echo "uname: $(uname -a)"
    echo "model: $(tr -d '\0' </proc/device-tree/model 2>/dev/null || echo unknown)"
    echo
    echo "cc:"
    cc --version 2>&1 || true
    echo
    echo "c++:"
    c++ --version 2>&1 || true
    echo
    echo "cmake: $(cmake --version 2>/dev/null | head -n1 || true)"
    echo "ninja: $(ninja --version 2>/dev/null || echo unavailable)"
    echo "make: $(make --version 2>/dev/null | head -n1 || true)"
    echo "python: $(python3 --version 2>&1 || true)"
    echo "ld: $(ld --version 2>/dev/null | head -n1 || true)"
    echo "as: $(as --version 2>/dev/null | head -n1 || true)"
    echo "tar: $(tar --version 2>/dev/null | head -n1 || true)"
    echo
    if command -v dpkg-query >/dev/null 2>&1; then
        for pkg in gcc g++ gcc-14 g++-14 libc6-dev binutils cmake ninja-build python3 make; do
            dpkg-query -W -f='${Package}=${Version}\n' "$pkg" 2>/dev/null || true
        done
    fi
} > "$OUT"
echo "Wrote $OUT"
