#include "ssnative/dat.hpp"

#include <filesystem>
#include <iostream>

int main(int argc, char** argv) {
    if (argc != 3) {
        std::cerr << "usage: ssdat-copy INPUT.dat OUTPUT.dat\n";
        return 2;
    }
    try {
        const auto dat = ssnative::DatFile::load(std::filesystem::path(argv[1]));
        dat.save(std::filesystem::path(argv[2]));
    } catch (const std::exception& error) {
        std::cerr << "ssdat-copy: " << error.what() << '\n';
        return 1;
    }
    return 0;
}
