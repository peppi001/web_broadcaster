#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int parse_positive(const char* text, long* value) {
    char* end = NULL;
    errno = 0;
    const long parsed = strtol(text, &end, 0);
    if (errno != 0 || end == text || *end != '\0' || parsed <= 0) return 0;
    *value = parsed;
    return 1;
}

static int32_t clamp_s16(int32_t value) {
    if (value < -32768) return -32768;
    if (value > 32767) return 32767;
    return value;
}

static void sample_pair(uint64_t frame, uint64_t sample_rate, int16_t* left_out, int16_t* right_out) {
    const uint64_t second = frame / sample_rate;
    int64_t left = 0;
    int64_t right = 0;
    if (second < 3u) {
        left = 0; right = 0;
    } else if (second < 6u) {
        left = 32767; right = -32768;
    } else if (second < 9u) {
        left = -32768; right = 32767;
    } else if (second < 12u) {
        if ((frame & 1u) == 0u) { left = 32767; right = -32768; }
        else { left = -32768; right = 32767; }
    } else if (second < 15u) {
        left = frame % 997u == 0u ? 32767 : 0;
        right = frame % 991u == 0u ? -32768 : 0;
    } else if (second < 18u) {
        const uint64_t phase = frame % (2u * 65536u);
        const int32_t value = clamp_s16(phase >= 65536u ? (int32_t)(phase - 65536u) : (int32_t)phase);
        left = value; right = -value - 1;
    } else if (second < 21u) {
        static const int16_t values[] = {0, 1, -1, 2, -2, 32767, -32768, 0};
        left = values[frame % 8u];
        right = values[(frame * 3u) % 8u];
    } else if (second < 24u) {
        const uint32_t l = (uint32_t)(((uint32_t)frame * UINT32_C(1103515245) + UINT32_C(12345)) >> 16u) & 0xffffu;
        const uint32_t r = (uint32_t)(((uint32_t)frame * UINT32_C(1664525) + UINT32_C(1013904223)) >> 16u) & 0xffffu;
        left = l >= 32768u ? (int32_t)l - 65536 : (int32_t)l;
        right = r >= 32768u ? (int32_t)r - 65536 : (int32_t)r;
    } else if (second < 27u) {
        left = ((frame / 64u) & 1u) != 0u ? 30000 : -30000;
        right = ((frame / 127u) & 1u) != 0u ? 25000 : -25000;
    } else {
        const uint64_t x = frame * UINT64_C(6364136223846793005) + UINT64_C(1442695040888963407);
        const uint64_t y = x ^ (x >> 29u) ^ (x << 17u);
        const uint32_t l = (uint32_t)((x >> 32u) & 0xffffu);
        const uint32_t r = (uint32_t)((y >> 32u) & 0xffffu);
        left = l >= 32768u ? (int32_t)l - 65536 : (int32_t)l;
        right = r >= 32768u ? (int32_t)r - 65536 : (int32_t)r;
    }
    *left_out = (int16_t)left;
    *right_out = (int16_t)right;
}

static void write_s16le(uint8_t* destination, int16_t value) {
    const uint16_t bits = (uint16_t)value;
    destination[0] = (uint8_t)(bits & 0xffu);
    destination[1] = (uint8_t)(bits >> 8u);
}

int main(int argc, char** argv) {
    long seconds = 30;
    long sample_rate = 44100;
    for (int i = 1; i < argc; ++i) {
        if (strcmp(argv[i], "--seconds") == 0 && i + 1 < argc) {
            if (!parse_positive(argv[++i], &seconds)) return 2;
        } else if (strcmp(argv[i], "--sample-rate") == 0 && i + 1 < argc) {
            if (!parse_positive(argv[++i], &sample_rate)) return 2;
        } else {
            return 2;
        }
    }
    uint8_t buffer[1u << 20];
    size_t used = 0;
    const uint64_t frames = (uint64_t)seconds * (uint64_t)sample_rate;
    for (uint64_t frame = 0; frame < frames; ++frame) {
        int16_t left, right;
        sample_pair(frame, (uint64_t)sample_rate, &left, &right);
        write_s16le(buffer + used, left);
        write_s16le(buffer + used + 2u, right);
        used += 4u;
        if (used == sizeof(buffer)) {
            if (fwrite(buffer, 1u, used, stdout) != used) return 3;
            used = 0;
        }
    }
    if (used != 0u && fwrite(buffer, 1u, used, stdout) != used) return 3;
    return ferror(stdout) ? 3 : 0;
}
