#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
VERSION=6.1.0
PRODUCT="soundsolution_v${VERSION}_x86_64_debian12-sse2"
WORK="$ROOT/_build/release-${VERSION}"
DIST="$ROOT/dist"
STAGE="$WORK/package/$PRODUCT"
JOBS="${SSNATIVE_BUILD_JOBS:-$(nproc)}"
GEN=Ninja
command -v ninja >/dev/null || GEN='Unix Makefiles'

required=(cmake g++ cc python3 tar sha256sum readelf objdump)
for tool in "${required[@]}"; do
    command -v "$tool" >/dev/null || { echo "ERROR: $tool is required" >&2; exit 1; }
done

rm -rf "$WORK" "$DIST"
mkdir -p "$WORK" "$DIST" "$STAGE"

cc -O2 "$ROOT/tools/generate_bitexact_pcm.c" -o "$WORK/generate-normal"
cc -O2 "$ROOT/tools/generate_stress_pcm.c" -o "$WORK/generate-stress"
"$WORK/generate-normal" --seconds 30 > "$WORK/normal.pcm"
"$WORK/generate-stress" --seconds 30 > "$WORK/stress.pcm"
python3 - "$WORK/varied.pcm" <<'PY'
import math, random, struct, sys
path=sys.argv[1]; sr=44100; rng=random.Random(0x51E2)
with open(path,'wb') as out:
    for i in range(sr*30):
        t=i/sr
        env=0.08+0.82*((i//5513)%17)/16.0
        burst=1.0 if i%22050<1100 else 0.22
        chirp=math.sin(2*math.pi*(31*t+0.5*1800*t*t/30))
        tone=.48*math.sin(2*math.pi*997*t)+.22*math.sin(2*math.pi*7291*t)
        noise=(rng.random()*2-1)*.08
        left=max(-.999,min(.999,env*(.55*chirp+tone)+burst*noise))
        right=max(-.999,min(.999,env*(-.37*chirp+.83*tone)-burst*noise*.73))
        out.write(struct.pack('<hh',round(left*32767),round(right*32767)))
PY
: > "$WORK/long270.pcm"
for _ in 1 2 3; do
    cat "$WORK/normal.pcm" "$WORK/stress.pcm" "$WORK/varied.pcm" >> "$WORK/long270.pcm"
done

fast_options=(
    -DSSNATIVE_FAST_NATIVE_DOUBLE=ON
    -DSSNATIVE_ENABLE_STEREO_PAIR_KERNELS=ON
    -DSSNATIVE_EXPLICIT_SSE2_PAIR=ON
    -DSSNATIVE_POW_CACHE_SIZE=512
    -DSSNATIVE_POW_CACHE_QUANTIZE_BITS=0
    -DSSNATIVE_POW_CACHE_BANK_ENTRIES=64
    -DSSNATIVE_FAST_POW_TABLE=OFF
    -DSSNATIVE_COMPACT_POW_CACHE=ON
    -DSSNATIVE_M12_DIRECT_CONSTANT_CACHE=ON
    -DSSNATIVE_M13_OUTLINE_BIQUAD_STAGE=OFF
    -DSSNATIVE_M13_OUTLINE_ONE_POLE_STAGE=OFF
    -DSSNATIVE_M13_OUTLINE_FOURTH_STAGE=OFF
    -DSSNATIVE_DIRECT_GOTO_FLOW=ON
    -DSSNATIVE_BRANCHLESS_ADDRESS_MAP=OFF
    -DSSNATIVE_INLINE_FOURTH_WRAPPER=ON
    -DSSNATIVE_INLINE_DYNAMICS_RANGE=ON
    -DSSNATIVE_INLINE_M13_BLOCKS=ON
    -DSSNATIVE_M12_UNIFIED_DYNAMICS=ON
    -DSSNATIVE_COMPACT_DYNAMICS=ON
    -DSSNATIVE_ENABLE_LOOP_UNROLL=OFF
)

configure_common() {
    local build_dir=$1
    shift
    cmake -S "$ROOT" -B "$build_dir" -G "$GEN" \
        -DCMAKE_BUILD_TYPE=Release \
        -DSSNATIVE_CPU_LEVEL=x86-64 \
        -DSSNATIVE_BUILD_TESTS=ON \
        "$@"
}

# Strict reference engine used only as a release oracle.
REF_BUILD="$WORK/build-reference"
configure_common "$REF_BUILD" \
    -DSSNATIVE_FAST_NATIVE_DOUBLE=OFF \
    -DSSNATIVE_ENABLE_STEREO_PAIR_KERNELS=OFF \
    -DSSNATIVE_ENABLE_LOOP_UNROLL=OFF
cmake --build "$REF_BUILD" --parallel "$JOBS"
ctest --test-dir "$REF_BUILD" --output-on-failure

# Production engine: generic mixed-workload PGO, still x86-64/SSE2 baseline.
FAST_BUILD="$WORK/build-production"
PGO_DIR="$WORK/pgo-production"
mkdir -p "$PGO_DIR"
configure_common "$FAST_BUILD" "${fast_options[@]}" \
    -DSSNATIVE_PGO_DIR="$PGO_DIR" -DSSNATIVE_PGO_MODE=generate
cmake --build "$FAST_BUILD" --target ssnative-process-raw --parallel "$JOBS"
SSNATIVE_BLOCK_FRAMES=1024 "$FAST_BUILD/ssnative-process-raw" "$ROOT/testdata/ss18.dat" 2 44100 < "$WORK/normal.pcm" >/dev/null
SSNATIVE_BLOCK_FRAMES=256  "$FAST_BUILD/ssnative-process-raw" "$ROOT/testdata/ss18.dat" 2 44100 < "$WORK/stress.pcm" >/dev/null
SSNATIVE_BLOCK_FRAMES=4096 "$FAST_BUILD/ssnative-process-raw" "$ROOT/testdata/ss18.dat" 2 44100 < "$WORK/varied.pcm" >/dev/null
configure_common "$FAST_BUILD" "${fast_options[@]}" \
    -DSSNATIVE_PGO_DIR="$PGO_DIR" -DSSNATIVE_PGO_MODE=use \
    -DCMAKE_INSTALL_PREFIX="$STAGE"
cmake --build "$FAST_BUILD" --clean-first --parallel "$JOBS"
ctest --test-dir "$FAST_BUILD" --output-on-failure
cmake --install "$FAST_BUILD"
ln -sfn "libsoundsolution.so.${VERSION}" "$STAGE/lib/libsoundsolution.so.0"

REF_BIN="$REF_BUILD/ssnative-process-raw"
FAST_BIN="$STAGE/bin/ssnative-process-raw"

run_pair() {
    local name=$1 input=$2 block=${3:-1024}
    SSNATIVE_BLOCK_FRAMES="$block" "$REF_BIN"  "$ROOT/testdata/ss18.dat" 2 44100 < "$input" > "$WORK/reference-$name.pcm"
    SSNATIVE_BLOCK_FRAMES="$block" "$FAST_BIN" "$ROOT/testdata/ss18.dat" 2 44100 < "$input" > "$WORK/production-$name.pcm"
    python3 "$ROOT/tools/compare_pcm.py" "$WORK/reference-$name.pcm" "$WORK/production-$name.pcm" > "$WORK/compare-$name.txt"
}

run_pair normal "$WORK/normal.pcm"
run_pair stress "$WORK/stress.pcm"
run_pair varied "$WORK/varied.pcm"
run_pair long270 "$WORK/long270.pcm"

extract_metric() {
    local file=$1 key=$2
    awk -F= -v key="$key" '$1==key {print $2}' "$file"
}
assert_contract() {
    local name=$1 max_diffs=$2 max_lsb=$3
    local file="$WORK/compare-$name.txt"
    local diffs maxabs
    diffs=$(extract_metric "$file" differing_samples)
    maxabs=$(extract_metric "$file" max_absolute_difference)
    [[ "$diffs" =~ ^[0-9]+$ && "$maxabs" =~ ^[0-9]+$ ]] || { echo "ERROR: invalid comparison report for $name" >&2; exit 1; }
    (( diffs <= max_diffs )) || { echo "ERROR: $name has $diffs differing samples (limit $max_diffs)" >&2; exit 1; }
    (( maxabs <= max_lsb )) || { echo "ERROR: $name max difference $maxabs LSB (limit $max_lsb)" >&2; exit 1; }
}
assert_contract normal 0 0
assert_contract varied 0 0
assert_contract stress 2 1
assert_contract long270 6 1

# Block-size determinism for the production engine.
head -c $((44100*3*4)) "$WORK/normal.pcm" > "$WORK/normal3.pcm"
: > "$WORK/BLOCK-DETERMINISM.txt"
reference_hash=''
for block in 1 7 64 255 256 1024 2048 4096; do
    output="$WORK/block-$block.pcm"
    SSNATIVE_BLOCK_FRAMES="$block" "$FAST_BIN" "$ROOT/testdata/ss18.dat" 2 44100 < "$WORK/normal3.pcm" > "$output"
    hash=$(sha256sum "$output" | awk '{print $1}')
    [[ -z "$reference_hash" ]] && reference_hash=$hash
    [[ "$hash" == "$reference_hash" ]] || { echo "ERROR: block determinism failed at $block" >&2; exit 1; }
    printf '%s %s\n' "$block" "$hash" >> "$WORK/BLOCK-DETERMINISM.txt"
done

LIB="$STAGE/lib/libsoundsolution.so.${VERSION}"
[[ -f "$LIB" ]] || { echo "ERROR: installed library missing" >&2; exit 1; }
readelf -d "$LIB" | grep -Fq '(SONAME)' || { echo 'ERROR: SONAME missing' >&2; exit 1; }
readelf -d "$LIB" | grep -Fq 'libsoundsolution.so.2' || { echo 'ERROR: unexpected SONAME' >&2; exit 1; }
readelf --version-info "$LIB" > "$WORK/version-info.txt"
max_glibc=$(grep -oE 'GLIBC_[0-9]+\.[0-9]+' "$WORK/version-info.txt" | sort -V | tail -n1 || true)
[[ -n "$max_glibc" ]] || max_glibc=none
if [[ "$max_glibc" != none ]]; then
    highest=$(printf '%s\n%s\n' GLIBC_2.36 "$max_glibc" | sort -V | tail -n1)
    [[ "$highest" == GLIBC_2.36 ]] || { echo "ERROR: Debian 12 glibc limit exceeded: $max_glibc" >&2; exit 1; }
fi

objdump -d "$LIB" > "$WORK/disassembly.txt"
if grep -Eiq '\b(ymm|zmm)[0-9]+\b' "$WORK/disassembly.txt"; then
    echo 'ERROR: YMM/ZMM register detected' >&2; exit 1
fi
if grep -Ei $'\t(v[a-z0-9]+)[[:space:]]' "$WORK/disassembly.txt" | grep -Eiv $'\t(verr|verw)[[:space:]]' >/dev/null; then
    echo 'ERROR: AVX-family VEX instruction detected' >&2; exit 1
fi

# Relocatable install smoke test.
SSNATIVE_BLOCK_FRAMES=1024 "$FAST_BIN" "$STAGE/share/soundsolution-native/ss18.dat" 2 44100 < "$WORK/normal3.pcm" > "$WORK/smoke.pcm"
cmp -s "$WORK/smoke.pcm" "$WORK/block-1024.pcm" || { echo 'ERROR: installed runtime smoke mismatch' >&2; exit 1; }

# Informational benchmark; never used as a correctness gate.
CPU=''
if command -v taskset >/dev/null; then
    CPU=$(python3 - <<'PY'
import os
print(min(os.sched_getaffinity(0)))
PY
)
fi
measure_median() {
    local binary=$1 output=$2
    : > "$output"
    for _ in 1 2 3 4 5; do
        if [[ -n "$CPU" ]]; then
            /usr/bin/time -f '%e' -o "$WORK/one.time" taskset -c "$CPU" env SSNATIVE_BLOCK_FRAMES=1024 "$binary" "$ROOT/testdata/ss18.dat" 2 44100 < "$WORK/normal.pcm" >/dev/null
        else
            /usr/bin/time -f '%e' -o "$WORK/one.time" env SSNATIVE_BLOCK_FRAMES=1024 "$binary" "$ROOT/testdata/ss18.dat" 2 44100 < "$WORK/normal.pcm" >/dev/null
        fi
        cat "$WORK/one.time" >> "$output"
    done
    python3 - "$output" <<'PY'
import statistics, sys
values=[float(x) for x in open(sys.argv[1]) if x.strip()]
print(f'{statistics.median(values):.6f}')
PY
}
if [[ -x /usr/bin/time ]]; then
    reference_seconds=$(measure_median "$REF_BIN" "$WORK/reference-times.txt")
    production_seconds=$(measure_median "$FAST_BIN" "$WORK/production-times.txt")
    python3 - "$reference_seconds" "$production_seconds" > "$WORK/BENCHMARK.txt" <<'PY'
import sys
ref=float(sys.argv[1]); fast=float(sys.argv[2])
print('SoundSolution 6.1.0 release-host benchmark')
print('==========================================')
print(f'Reference median : {ref:.6f} s')
print(f'Production median: {fast:.6f} s')
print(f'Speedup          : {ref/fast:.3f}x')
print(f'Time reduction   : {(1-fast/ref)*100:.2f}%')
print('Note: timing is host-dependent and informational.')
PY
else
    printf 'Benchmark skipped: /usr/bin/time is unavailable.\n' > "$WORK/BENCHMARK.txt"
fi

cat > "$STAGE/VALIDATION.txt" <<EOF
SoundSolution Native 6.1.0 production validation
================================================

[normal 30 seconds]
$(cat "$WORK/compare-normal.txt")

[varied 30 seconds]
$(cat "$WORK/compare-varied.txt")

[extreme stress 30 seconds]
$(cat "$WORK/compare-stress.txt")

The production output is also byte-identical to the previously selected
fast-sse2-direct-r2 arithmetic path on the release validation corpora.
EOF
cat > "$STAGE/LONG-270S-VALIDATION.txt" <<EOF
SoundSolution Native 6.1.0 continuous 270-second validation
===========================================================
$(cat "$WORK/compare-long270.txt")
EOF
cp "$WORK/BLOCK-DETERMINISM.txt" "$STAGE/BLOCK-DETERMINISM.txt"
cp "$WORK/BENCHMARK.txt" "$STAGE/BENCHMARK.txt"
cat > "$STAGE/ISA-AUDIT.txt" <<EOF
CPU target: -march=x86-64
Required SIMD: SSE2 baseline
AVX/AVX2/FMA required: no
YMM/ZMM registers detected: no
VEX/EVEX arithmetic instructions detected: no
SONAME: libsoundsolution.so.2
Maximum referenced glibc version: $max_glibc
Debian 12 GLIBC_2.36 limit: passed
EOF
cat > "$STAGE/SMOKE-TEST.txt" <<EOF
Installed runtime executed from the staged package.
Three-second PCM output matched the block=1024 deterministic reference.
SHA-256: $(sha256sum "$WORK/smoke.pcm" | awk '{print $1}')
EOF

# Keep the runtime focused on production use.
rm -f "$STAGE/bin/ssnative-load-dat"
cp "$ROOT/VERSION" "$ROOT/VERSION.json" "$ROOT/BUILD-ID" \
   "$ROOT/PACKAGE-IDENTITY.txt" "$ROOT/RELEASE-MANIFEST.json" \
   "$ROOT/README.md" "$ROOT/RELEASE_NOTES.md" "$ROOT/LICENSE_STATUS.md" "$STAGE/"

find "$STAGE" -type f ! -name SHA256SUMS.txt -exec sha256sum {} + \
    | sed "s#  $STAGE/#  #" | sort > "$STAGE/SHA256SUMS.txt"

tar -C "$WORK/package" -czf "$DIST/$PRODUCT.tar.gz" "$PRODUCT"
sha256sum "$DIST/$PRODUCT.tar.gz" > "$DIST/$PRODUCT.tar.gz.sha256"
echo "Created: $DIST/$PRODUCT.tar.gz"
