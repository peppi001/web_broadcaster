#!/usr/bin/env python3
"""Audit reconstructed state addresses used by SoundSolution 6.1.0."""
from __future__ import annotations
import argparse, re
from pathlib import Path
VIRTUAL_BASE=0x1000C000; VIRTUAL_END=0x10110000
RANGES=(("tables",0x1000C000,0x10011000),("runtime",0x1004A000,0x100D8000),("configuration",0x10106000,0x10110000))
NUMBER_RE=re.compile(r"(?<![A-Za-z0-9_])(?:0x[0-9A-Fa-f]+|[0-9]{8,10})(?:u|U|l|L)*")
def parse_number(token:str)->int:
    token=token.rstrip('uUlL'); return int(token,16) if token.lower().startswith('0x') else int(token,10)
def region_for(address:int)->str|None:
    for name,begin,end in RANGES:
        if begin<=address<end:return name
    return None
def collect(path:Path)->dict[int,int]:
    counts={}
    for m in NUMBER_RE.finditer(path.read_text(encoding='utf-8')):
        value=parse_number(m.group(0))
        if VIRTUAL_BASE<=value<VIRTUAL_END:counts[value]=counts.get(value,0)+1
    return counts
def main()->int:
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);p.add_argument('--report',type=Path);a=p.parse_args();root=a.root.resolve()
    sources=(root/'src/named_state_engine.cpp',)
    missing=[str(x) for x in sources if not x.is_file()]
    if missing:raise SystemExit('missing audit sources: '+', '.join(missing))
    if (root/'src/native_process_body.inc').exists():raise SystemExit('retired process source include remains')
    counts={}
    for source in sources:
        for address,count in collect(source).items():counts[address]=counts.get(address,0)+count
    layout=(root/'src/named_state_layout.hpp').read_text(encoding='utf-8')
    block=layout.split('namespace address {',1)[1].split('} // namespace address',1)[0]
    for m in NUMBER_RE.finditer(block):
        address=parse_number(m.group(0))
        if VIRTUAL_BASE<=address<VIRTUAL_END:counts[address]=counts.get(address,0)+1
    for boundary in (0x10011000,0x100D8000,0x10110000):counts.pop(boundary,None)
    unmapped=sorted(x for x in counts if region_for(x) is None)
    if unmapped:raise SystemExit('unmapped reconstructed state addresses: '+', '.join(f'0x{x:08x}' for x in unmapped[:32]))
    unique={name:0 for name,_,_ in RANGES};refs={name:0 for name,_,_ in RANGES}
    for address,count in counts.items():
        name=region_for(address);assert name;unique[name]+=1;refs[name]+=count
    lines=['SoundSolution 6.1.0 named-state address audit','============================================',f'Unique reconstructed state addresses: {len(counts)}',f'Total state-address references: {sum(counts.values())}']
    for name,begin,end in RANGES:lines.append(f'{name}: 0x{begin:08x}-0x{end:08x}; unique={unique[name]}; references={refs[name]}')
    lines.append('Unmapped compatibility-gap addresses: 0')
    text='\n'.join(lines)+'\n';print(text,end='')
    if a.report:a.report.parent.mkdir(parents=True,exist_ok=True);a.report.write_text(text,encoding='utf-8')
    return 0
if __name__=='__main__':raise SystemExit(main())
