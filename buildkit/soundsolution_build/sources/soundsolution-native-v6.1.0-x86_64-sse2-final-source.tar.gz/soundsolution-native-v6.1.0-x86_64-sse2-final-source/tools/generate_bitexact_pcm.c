#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static const int16_t edge_values[] = {
    0, 0, 32767, 1, -32768, -16384, 1, 0, -1, 1, 16384, -16384,
    -16384, 0, 30000, 1, -30000, -1, 32766, -32767, 2, -2,
    12345, -23456, -12345, 23456,
};

static uint32_t xorshift32(uint32_t value) {
    value ^= value << 13;
    value ^= value >> 17;
    value ^= value << 5;
    return value;
}

static int32_t python_floor_div4(int32_t value) {
    return value >= 0 ? value / 4 : -((-value + 3) / 4);
}

static int parse_positive(const char* text, long* value) {
    char* end = NULL;
    errno = 0;
    const long parsed = strtol(text, &end, 0);
    if (errno != 0 || end == text || *end != '\0' || parsed <= 0) return 0;
    *value = parsed;
    return 1;
}

static void write_s16le(uint8_t* destination, int16_t value) {
    const uint16_t bits = (uint16_t)value;
    destination[0] = (uint8_t)(bits & 0xffu);
    destination[1] = (uint8_t)(bits >> 8u);
}

int main(int argc, char** argv) {
    long seconds = 0;
    long sample_rate = 44100;
    long channels = 2;
    uint32_t seed = UINT32_C(0x6d2b79f5);
    for (int i = 1; i < argc; ++i) {
        if (strcmp(argv[i], "--seconds") == 0 && i + 1 < argc) {
            if (!parse_positive(argv[++i], &seconds)) return 2;
        } else if (strcmp(argv[i], "--sample-rate") == 0 && i + 1 < argc) {
            if (!parse_positive(argv[++i], &sample_rate)) return 2;
        } else if (strcmp(argv[i], "--channels") == 0 && i + 1 < argc) {
            if (!parse_positive(argv[++i], &channels) || (channels != 1 && channels != 2)) return 2;
        } else if (strcmp(argv[i], "--seed") == 0 && i + 1 < argc) {
            char* end = NULL;
            errno = 0;
            const unsigned long parsed = strtoul(argv[++i], &end, 0);
            if (errno != 0 || end == argv[i] || *end != '\0' || parsed > UINT32_MAX) return 2;
            seed = (uint32_t)parsed;
        } else {
            return 2;
        }
    }
    if (seconds <= 0 || sample_rate < 44100) return 2;

    const uint64_t sample_count = (uint64_t)seconds * (uint64_t)sample_rate * (uint64_t)channels;
    uint32_t state = seed;
    uint8_t buffer[1u << 20];
    size_t used = 0;
    for (uint64_t index = 0; index < sample_count; ++index) {
        int32_t sample;
        if (index < sizeof(edge_values) / sizeof(edge_values[0])) {
            sample = edge_values[index];
        } else {
            state = xorshift32(state);
            const uint32_t raw = (state >> 16u) & 0xffffu;
            const int32_t signed_value = raw >= 0x8000u ? (int32_t)raw - 0x10000 : (int32_t)raw;
            sample = python_floor_div4(signed_value);
            const uint32_t selector = (uint32_t)index & 0x3fffu;
            if (selector == 2u) sample = 1;
            else if (selector == 3u) sample = -1;
        }
        write_s16le(buffer + used, (int16_t)sample);
        used += 2u;
        if (used == sizeof(buffer)) {
            if (fwrite(buffer, 1u, used, stdout) != used) return 3;
            used = 0;
        }
    }
    if (used != 0u && fwrite(buffer, 1u, used, stdout) != used) return 3;
    return ferror(stdout) ? 3 : 0;
}
