#include "ssnative/dat.hpp"

#include <cstddef>
#include <filesystem>
#include <iomanip>
#include <iostream>

int main(int argc, char** argv) {
    if (argc != 2) {
        std::cerr << "usage: ssdat-dump FILE.dat\n";
        return 2;
    }

    try {
        const auto dat = ssnative::DatFile::load(std::filesystem::path(argv[1]));
        std::cout << "version: " << dat.version_string() << '\n';
        std::cout << "signature: 0x" << std::hex << std::uppercase
                  << dat.raw().signature << std::dec << '\n';
        std::cout << "name: " << dat.name() << "\n\n";

        std::cout << "process matrix (band x stage, first 7 int32 fields):\n";
        for (std::size_t band = 0; band < ssnative::kProcessBandCount; ++band) {
            for (std::size_t stage = 0; stage < ssnative::kProcessStageCount; ++stage) {
                const auto& record = dat.process(band, stage);
                std::cout << "band " << band << " stage " << stage
                          << " [record " << ssnative::process_index(band, stage) << "]:";
                for (const auto value : record.parameter) {
                    std::cout << ' ' << value;
                }
                std::cout << '\n';
            }
        }

        std::cout << "\nnon-zero common int32 fields (offset is DAT common-block relative):\n";
        for (std::size_t i = 0; i < dat.raw().common.parameter.size(); ++i) {
            const auto value = dat.raw().common.parameter[i];
            if (value != 0) {
                const auto offset = 60U + i * sizeof(std::int32_t);
                std::cout << "0x" << std::hex << std::setw(3) << std::setfill('0')
                          << offset << std::dec << std::setfill(' ')
                          << "  param[" << i << "] = " << value << '\n';
            }
        }
    } catch (const std::exception& error) {
        std::cerr << "ssdat-dump: " << error.what() << '\n';
        return 1;
    }
    return 0;
}
