#!/usr/bin/env python3
"""Compare two signed-16-bit little-endian PCM streams sample by sample."""
from __future__ import annotations

import argparse
from pathlib import Path
import sys


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("reference", type=Path)
    parser.add_argument("candidate", type=Path)
    parser.add_argument("--channels", type=int, default=2)
    args = parser.parse_args()
    if args.channels <= 0:
        parser.error("--channels must be positive")

    a = args.reference.read_bytes()
    b = args.candidate.read_bytes()
    if len(a) != len(b):
        print(f"size mismatch: reference={len(a)} candidate={len(b)}", file=sys.stderr)
        return 2
    if len(a) % 2:
        print("PCM byte count must be even", file=sys.stderr)
        return 2

    diff_count = 0
    first_sample = None
    max_abs = 0
    sum_abs = 0
    for index in range(0, len(a), 2):
        av = int.from_bytes(a[index:index + 2], "little", signed=True)
        bv = int.from_bytes(b[index:index + 2], "little", signed=True)
        delta = bv - av
        if delta:
            sample_index = index // 2
            diff_count += 1
            if first_sample is None:
                first_sample = sample_index
            absolute = abs(delta)
            max_abs = max(max_abs, absolute)
            sum_abs += absolute

    total_samples = len(a) // 2
    print(f"samples={total_samples}")
    print(f"differing_samples={diff_count}")
    print(f"first_differing_sample={first_sample if first_sample is not None else 'none'}")
    print(f"first_differing_frame={first_sample // args.channels if first_sample is not None else 'none'}")
    print(f"max_absolute_difference={max_abs}")
    print(f"mean_absolute_difference_nonzero={sum_abs / diff_count if diff_count else 0:.9f}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
