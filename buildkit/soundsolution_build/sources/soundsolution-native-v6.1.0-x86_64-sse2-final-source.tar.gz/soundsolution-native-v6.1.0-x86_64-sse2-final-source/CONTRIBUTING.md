# Contributing

All DSP changes must pass both CMake test profiles. Changes to the production
path must also run `./build.sh`, which compares output with the strict reference,
checks block-size determinism and rejects AVX/AVX2/FMA instructions. Do not add
CPU-model-specific compilation flags to the generic release.
