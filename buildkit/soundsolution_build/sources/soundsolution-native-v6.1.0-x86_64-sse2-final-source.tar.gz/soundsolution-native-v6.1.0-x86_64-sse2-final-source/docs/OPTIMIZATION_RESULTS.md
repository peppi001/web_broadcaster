# Generic SSE2 optimization search — final 6.1.0 selection

All candidates used `-march=x86-64`; no CPU-model-specific tuning was allowed.
Every accepted transformation had to preserve the SSE2-r1 output on normal,
stress and varied validation corpora.

## Accepted

- direct label-threaded process flow;
- typed global/frame/audio access;
- persistent region base pointers;
- restrict-qualified independent regions;
- explicit SSE2 stereo filters;
- selected hot-path inlining;
- compact exact cache entries;
- 12 x 64-entry exact per-dynamics pow cache;
- mixed PGO.

## Tested and rejected

- approximate table/polynomial pow: slower;
- mantissa-quantized pow cache: no stable gain and can add PCM differences;
- 32- and 128-entry bank sizes: slower than 64;
- 1024-entry monolithic cache: slower due to cache pressure;
- branchless address mapper: slower;
- dynamics cloning: no gain;
- loop unrolling: neutral or slower;
- compact dynamics disabled: slower;
- forced function/loop alignment: slower;
- `-fipa-pta -frename-registers`: slower;
- CPU-specific `-march=native` or `-mtune`: intentionally excluded.

## Selection benchmark

Median wall time, five pinned runs, 30-second corpora:

| Corpus | SSE2-r1 | direct r2 mixed PGO | Improvement |
|---|---:|---:|---:|
| normal | 0.991 s | 0.856 s | 13.6% |
| stress | 1.012 s | 0.849 s | 16.1% |
| varied | 1.010 s | 0.854 s | 15.4% |

Timing varies by host; these figures are for candidate selection, not a promise
for every processor. The selected code path remains generic SSE2.

## Target-host final result

The final 6.1.0 code processed 300.826122 seconds in 12.46 seconds versus
21.67 seconds for the strict x87 reference: 1.739x speedup and 42.50% shorter
processing time. The difference remained four isolated 1-LSB samples.
