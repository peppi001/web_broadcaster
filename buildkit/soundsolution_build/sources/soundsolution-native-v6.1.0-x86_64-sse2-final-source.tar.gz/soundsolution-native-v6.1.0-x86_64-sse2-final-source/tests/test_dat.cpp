#include "ssnative/dat.hpp"
#include "ssnative/dsp.hpp"

#include <array>
#include <cassert>
#include <cmath>
#include <cstddef>
#include <filesystem>
#include <fstream>
#include <iterator>
#include <string>
#include <vector>

int main() {
    const auto path = std::filesystem::path(SSNATIVE_TEST_DAT);
    const auto dat = ssnative::DatFile::load(path);

    assert(dat.is_supported());
    assert(dat.version_string() == "2.0");
    assert(dat.name() == "SZIVKULDI :D");
    assert(dat.raw().signature == ssnative::kDatSignature);
    assert(dat.process(0, 0).parameter[0] == 98);
    assert(dat.process(0, 1).parameter[0] == 10);
    assert(dat.process(6, 2).parameter[1] == 300);

    std::ifstream input(path, std::ios::binary);
    const std::vector<char> original((std::istreambuf_iterator<char>(input)),
                                     std::istreambuf_iterator<char>());
    const auto bytes = dat.to_bytes();
    assert(original.size() == bytes.size());
    for (std::size_t i = 0; i < bytes.size(); ++i) {
        assert(static_cast<unsigned char>(original[i]) ==
               std::to_integer<unsigned char>(bytes[i]));
    }

    const auto coefficient = ssnative::time_coefficient_ms(1000, 44100);
    assert(std::abs(coefficient - std::exp(-4.6 / 44100.0)) < 1e-15);
    assert(ssnative::db_hundredths_to_pcm(0) == 32767);
    assert(ssnative::db_tenths_to_pcm(0) == 32767);

    return 0;
}
