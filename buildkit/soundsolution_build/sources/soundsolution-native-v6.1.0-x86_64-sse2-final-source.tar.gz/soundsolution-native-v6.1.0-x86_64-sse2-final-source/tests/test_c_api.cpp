#include "ssnative/ssnative.h"

#include <cstdint>
#include <cstdio>
#include <cstring>
#include <vector>

namespace {

bool require(bool condition, const char* message) {
    if (!condition) {
        std::fprintf(stderr, "FAIL: %s\n", message);
        return false;
    }
    return true;
}

std::vector<std::int16_t> make_input(std::size_t frames) {
    std::vector<std::int16_t> samples(frames * 2U);
    for (std::size_t i = 0; i < frames; ++i) {
        samples[2U * i] = static_cast<std::int16_t>((i * 7919U) % 24001U) - 12000;
        samples[2U * i + 1U] = static_cast<std::int16_t>((i * 3571U + 1234U) % 20001U) - 10000;
    }
    return samples;
}

std::uint64_t fnv1a(const std::vector<std::int16_t>& samples) {
    std::uint64_t hash = 1469598103934665603ULL;
    const auto* bytes = reinterpret_cast<const std::uint8_t*>(samples.data());
    for (std::size_t i = 0; i < samples.size() * sizeof(samples[0]); ++i) {
        hash ^= bytes[i];
        hash *= 1099511628211ULL;
    }
    return hash;
}

} // namespace

int main() {
    bool ok = true;
    ok &= require(std::strcmp(ssnative_version(), "6.1.0") == 0,
                  "reported engine version");
#if defined(SSNATIVE_EXPECT_FAST_MODE)
    ok &= require(std::strcmp(ssnative_arithmetic_mode(), "native-binary64-fast") == 0,
                  "reported fast arithmetic mode");
#else
    ok &= require(std::strcmp(ssnative_arithmetic_mode(), "x87-binary80-bitexact") == 0,
                  "reported arithmetic mode");
#endif
    ok &= require(std::strcmp(ssnative_state_layout(),
                              "named-state-v14/structured-process-flow") == 0,
                  "reported named-state layout");
    ok &= require(std::strcmp(ssnative_control_layout(),
                              "structured-process-v1/typed-state-loop") == 0,
                  "reported native-call layout");
    ok &= require(ssnative_state_active_bytes() == 643072U,
                  "reported active state bytes");
    ok &= require(ssnative_state_virtual_bytes() == 1064960U,
                  "reported compatibility virtual bytes");
    ok &= require(ssnative_control_stack_virtual_bytes() == 0U,
                  "reported control stack virtual bytes");
    ok &= require(ssnative_control_stack_physical_bytes() == 512U,
                  "reported control stack physical bytes");
    ok &= require(ssnative_cold_control_stack_physical_bytes() == 0U,
                  "reported maximum cold control stack physical bytes");
    ok &= require(ssnative_configure_control_stack_physical_bytes() == 0U,
                  "reported configure control stack physical bytes");
    ok &= require(ssnative_postload_control_stack_physical_bytes() == 0U,
                  "reported postload control stack physical bytes");
    ok &= require(ssnative_control_continuation_capacity() == 0U,
                  "reported continuation capacity");
    ok &= require(ssnative_control_executor_bytes() <= 256U,
                  "reported cache-free control executor bytes");
    ok &= require(ssnative_hot_control_cache_bytes() > 0U &&
                  ssnative_hot_control_cache_bytes() <= 65536U,
                  "reported isolated hot control cache bytes");
    ok &= require(ssnative_control_domain_count() == 0U,
                  "reported control domain count");
    ok &= require(ssnative_control_continuation_state_bytes() == 0U,
                  "reported call-local continuation state bytes");
    ok &= require(ssnative_persistent_continuation_bytes() == 0U,
                  "reported persistent continuation bytes");
    ok &= require(ssnative_configure_continuation_state_bytes() == 0U,
                  "reported configure continuation state bytes");
    ok &= require(ssnative_postload_continuation_state_bytes() == 0U,
                  "reported postload continuation state bytes");
    ok &= require(ssnative_native_configure_function_count() == 8U,
                  "reported native configure function count");
    ok &= require(ssnative_native_configure_static_operation_count() == 0U,
                  "reported residual native configure static operation count");
    ok &= require(ssnative_native_postload_function_count() == 1U,
                  "reported native postload function count");
    ok &= require(ssnative_native_postload_direct_call_count() == 6U,
                  "reported native postload direct-call count");
    ok &= require(ssnative_native_postload_static_operation_count() == 0U,
                  "reported residual native postload static operation count");
    ok &= require(ssnative_process_program_instruction_count() == 0U,
                  "reported removed process program instruction count");
    ok &= require(ssnative_process_frame_bytes() == 512U,
                  "reported call-local native process frame bytes");
    ok &= require(ssnative_direct_process_body_count() == 978U,
                  "reported direct process body operation count");
    ok &= require(ssnative_structured_process_stage_count() == 87U,
                  "reported structured process stage count");
    ok &= require(ssnative_persistent_process_workspace_bytes() == 0U,
                  "reported persistent process workspace bytes");
    ssnative_dsp* dsp = ssnative_create();
    ok &= require(dsp != nullptr, "ssnative_create");
    if (dsp == nullptr) return 1;

    ok &= require(ssnative_load_dat(dsp, SSNATIVE_TEST_DAT) == SSNATIVE_STATUS_OK,
                  "load supplied DAT");

    auto samples = make_input(4096U);
    ok &= require(ssnative_process_s16_interleaved(
                      dsp, samples.data(), 4096U, 2U, 44100U) == SSNATIVE_STATUS_OK,
                  "process stereo PCM");
    constexpr std::uint64_t expected_pcm_hash = 0x96cd8d18cfff7804ULL;
    ok &= require(fnv1a(samples) == expected_pcm_hash,
                  "deterministic processed PCM hash");

    ok &= require(ssnative_reset(dsp) == SSNATIVE_STATUS_OK, "reset DSP state");
    auto after_reset = make_input(4096U);
    ok &= require(ssnative_process_s16_interleaved(
                      dsp, after_reset.data(), 4096U, 2U, 44100U) == SSNATIVE_STATUS_OK,
                  "process after reset");
    ok &= require(after_reset == samples, "reset restores deterministic state");

    std::int16_t invalid[12]{};
    ok &= require(ssnative_process_s16_interleaved(dsp, invalid, 4U, 3U, 44100U) ==
                      SSNATIVE_STATUS_INVALID_AUDIO_FORMAT,
                  "reject unsupported channel count");

    ssnative_destroy(dsp);
    return ok ? 0 : 1;
}
