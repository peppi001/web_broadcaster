#include "kernels.hpp"

#include <cassert>
#include <cmath>

namespace {

bool close(const double a, const double b) {
    return std::abs(a - b) < 1e-12;
}

} // namespace

int main() {
    using namespace ssnative::detail;

    {
        OnePoleCoefficients c{0.25, 0.75, 0.5};
        StereoOnePoleState s{2.0, -2.0};
        double l = 10.0;
        double r = -10.0;
        process_stereo_one_pole(c, s, l, r);
        assert(close(s.left_previous, 9.0));
        assert(close(s.right_previous, -9.0));
        assert(close(l, 7.25));
        assert(close(r, -7.25));
    }

    {
        BiquadCoefficients c{{1.0, 0.5, 0.25}, {0.1, 0.2}};
        StereoBiquadState s{{2.0, 3.0}, {-2.0, -3.0}};
        double l = 10.0;
        double r = -10.0;
        process_stereo_biquad(c, s, l, r);
        const double lw = 10.0 - 0.1 * 2.0 - 0.2 * 3.0;
        assert(close(l, lw + 0.5 * 2.0 + 0.25 * 3.0));
        assert(close(s.left[0], lw));
        assert(close(s.left[1], 2.0));
        assert(close(r, -l));
    }

    {
        FourthOrderCoefficients c{{1.0, 0.5, 0.25, 0.125, 0.0625},
                                  {0.1, 0.2, 0.3, 0.4}};
        StereoFourthOrderState s{{1.0, 2.0, 3.0, 4.0},
                                 {-1.0, -2.0, -3.0, -4.0}};
        double l = 20.0;
        double r = -20.0;
        process_stereo_fourth_order(c, s, l, r);
        const double w = 20.0 - 0.1 - 0.4 - 0.9 - 1.6;
        const double y = w + 0.5 + 0.5 + 0.375 + 0.25;
        assert(close(l, y));
        assert(close(r, -y));
        assert(close(s.left[0], w));
        assert(close(s.left[1], 1.0));
        assert(close(s.left[2], 2.0));
        assert(close(s.left[3], 3.0));
    }

    assert(close(soft_clip(50.0, 100.0, 20.0), 50.0));
    assert(close(soft_clip(110.0, 100.0, 20.0),
                 100.0 + 10.0 * 20.0 / 30.0));
    assert(close(soft_clip(-110.0, 100.0, 20.0),
                 -(100.0 + 10.0 * 20.0 / 30.0)));

    double state = 10.0;
    smooth_toward_min(2.0, state, 25);
    assert(close(state, 8.0));
    smooth_toward_min(20.0, state, 25);
    assert(close(state, 8.0));

    assert(multiply_milli(2500, 400) == 1000);
    assert(multiply_milli(-2500, 400) == -1000);
    assert(quadratic_map(1.0) == 868);
    return 0;
}
