#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
fail(){ echo "ERROR: $*" >&2; exit 1; }
[[ "$(cat VERSION)" == "6.1.0" ]] || fail "VERSION mismatch"
grep -Fq 'project(soundsolution_native VERSION 6.1.0' CMakeLists.txt || fail "CMake version mismatch"
grep -Fq 'return "6.1.0";' src/c_api.cpp || fail "C API version mismatch"
grep -Fq 'std::strcmp(ssnative_version(), "6.1.0")' tests/test_c_api.cpp || fail "C API test mismatch"
grep -Fq 'tools/build_x86_64_sse2_release.sh' build.sh || fail "final release builder not selected"
for flag in '-mfpmath=387' '-ffp-contract=off' '-fno-tree-vectorize'; do
    grep -Fq -- "$flag" CMakeLists.txt || fail "missing strict flag $flag"
done
for flag in '-mfpmath=sse' '-ffp-contract=fast' '-ffast-math' '-ftree-vectorize'; do
    grep -Fq -- "$flag" CMakeLists.txt || fail "missing production flag $flag"
done
grep -Fq 'using NativeDouble = double;' src/native_double.hpp || fail "binary64 backend missing"
grep -Fq 'using NativeDouble = long double;' src/native_double.hpp || fail "binary80 backend missing"
grep -Fq 'native-binary64-fast' src/c_api.cpp || fail "production arithmetic identity missing"
grep -Fq 'x87-binary80-bitexact' src/c_api.cpp || fail "reference arithmetic identity missing"
python3 -m json.tool VERSION.json >/dev/null
python3 -m json.tool RELEASE-MANIFEST.json >/dev/null
python3 -m json.tool CMakePresets.json >/dev/null
python3 -m py_compile tools/compare_pcm.py tools/audit_named_state.py tools/audit_native_control.py
python3 tools/audit_named_state.py --root . >/dev/null
python3 tools/audit_native_control.py --root . >/dev/null
bash -n build.sh tools/build_x86_64_sse2_release.sh
if [[ -f MANIFEST.sha256 ]]; then sha256sum -c MANIFEST.sha256 >/dev/null; fi
echo 'OK: SoundSolution Native 6.1.0 final generic SSE2 source verified.'
