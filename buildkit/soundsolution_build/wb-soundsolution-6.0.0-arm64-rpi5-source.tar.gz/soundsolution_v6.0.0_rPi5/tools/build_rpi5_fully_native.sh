#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
PRODUCT_NAME="soundsolution_v6.0.0_rPi5"
PACKAGE_VERSION="6.0.0"
ENGINE_VERSION="6.0.0"
TARGET="${1:-pi5}"
SMOKE_MODE="${SSNATIVE_SMOKE_MODE:-0}"

fail() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
case "$SMOKE_MODE" in 0|1) ;; *) fail "SSNATIVE_SMOKE_MODE must be 0 or 1" ;; esac
[[ "$TARGET" == "pi5" ]] || fail "Only the Raspberry Pi 5 target is supported"

ARCH="$(uname -m)"
MODEL=""
[[ -r /proc/device-tree/model ]] && MODEL="$(tr -d '\0' </proc/device-tree/model)"
if [[ "$SMOKE_MODE" == 0 ]]; then
    case "$ARCH" in aarch64|arm64) ;; *) fail "64-bit Raspberry Pi OS required; uname -m=$ARCH" ;; esac
    [[ "$MODEL" == *"Raspberry Pi 5"* ]] || fail "Raspberry Pi 5 required; model=${MODEL:-unknown}"
fi

for command in cmake c++ cc python3 sha256sum tar readelf awk sed grep; do
    command -v "$command" >/dev/null 2>&1 || fail "Missing command: $command"
done
command -v /usr/bin/time >/dev/null 2>&1 || fail "GNU time is required: /usr/bin/time"
if command -v ninja >/dev/null 2>&1; then GENERATOR=(-G Ninja); else GENERATOR=(-G "Unix Makefiles"); fi

CPU_LEVEL="raspberry-pi-5"
CPU_NAME="cortex-a76"
PGO_SECONDS="${SSNATIVE_PGO_SECONDS:-30}"
BLOCK_SIZES=(1 7 64 255 256 1024 2048 4096)
if [[ "$SMOKE_MODE" == 1 ]]; then
    CPU_LEVEL="x86-64-v3"
    CPU_NAME="developer-smoke"
    PGO_SECONDS="${SSNATIVE_PGO_SECONDS:-1}"
    BLOCK_SIZES=(1 1024)
fi

WORK_ROOT="${SSNATIVE_BUILD_ROOT:-${PROJECT_ROOT}/_build/rpi5-native-control}"
BUILD_DIR="$WORK_ROOT/release"
PGO_DATA="$WORK_ROOT/pgo-data"
INSTALL_DIR="$WORK_ROOT/${PRODUCT_NAME}"
PACKAGE_FILE="${SSNATIVE_OUTPUT_FILE:-${PROJECT_ROOT}/_dist/${PRODUCT_NAME}.tar.gz}"
JOBS="${SSNATIVE_BUILD_JOBS:-$(nproc)}"
PGO_JOBS="${SSNATIVE_PGO_BUILD_JOBS:-1}"
MAX_LOAD="${SSNATIVE_MAX_SINGLE_CORE_LOAD:-30.0}"
TARGET_LOAD="${SSNATIVE_TARGET_SINGLE_CORE_LOAD:-20.0}"
RUN_LONG="${SSNATIVE_RUN_LONG_VALIDATION:-0}"

[[ "$JOBS" =~ ^[1-9][0-9]*$ ]] || fail "SSNATIVE_BUILD_JOBS must be positive"
[[ "$PGO_JOBS" =~ ^[1-9][0-9]*$ ]] || fail "SSNATIVE_PGO_BUILD_JOBS must be positive"
[[ "$PGO_SECONDS" =~ ^[1-9][0-9]*$ ]] || fail "SSNATIVE_PGO_SECONDS must be positive"
case "$RUN_LONG" in 0|1) ;; *) fail "SSNATIVE_RUN_LONG_VALIDATION must be 0 or 1" ;; esac

GENERATOR_PCM_SOURCE="$PROJECT_ROOT/tools/generate_bitexact_pcm.c"
STRESS_PCM_SOURCE="$PROJECT_ROOT/tools/generate_stress_pcm.c"
STATE_AUDIT="$PROJECT_ROOT/tools/audit_named_state.py"
CONTROL_AUDIT="$PROJECT_ROOT/tools/audit_native_control.py"
CONFIG_SOURCE="$PROJECT_ROOT/testdata/ss18.dat"
[[ -f "$GENERATOR_PCM_SOURCE" && -f "$STRESS_PCM_SOURCE" && -f "$STATE_AUDIT" && -f "$CONTROL_AUDIT" && -f "$CONFIG_SOURCE" ]] || fail "Validation data is missing"

REFERENCE_INPUT_3_SHA="dc1d9263b214b8217ca8e38fdc4063c385b37b17ba1e769cca0d60fcc3a4f3d6"
REFERENCE_INPUT_STRESS_SHA="30ea4df8d3b76b03f522fac47ec6eabf23ccee7f6fa696e74fbf8b270e052e2f"
REFERENCE_3_SHA="ea5c85b2ebb0100fa44585ec4f106a9cae8b61c16489ff358beddf6ac181d49a"
REFERENCE_30_SHA="a1a4768be678cc2bffe50828a2eb1de655d1125a9ebad063de07b1776dac3e12"
REFERENCE_STRESS_SHA="5d2a39e1a2eddf9d27744117bf13f6a5ce26ae72414144c435089e91a8001235"
REFERENCE_270_SHA="8d4c8140b967dddbb94a0c91e4381d0caeff326cdbff105fdbcf757e1cfea09c"

COMMON_CMAKE=(
    -DCMAKE_BUILD_TYPE=Release
    -DCMAKE_INSTALL_PREFIX="$INSTALL_DIR"
    -DCMAKE_EXPORT_COMPILE_COMMANDS=ON
    -DSSNATIVE_CPU_LEVEL="$CPU_LEVEL"
    -DSSNATIVE_BUILD_TESTS=ON
    -DSSNATIVE_ENABLE_AUTOVECTORIZE=ON
    -DSSNATIVE_ENABLE_LOOP_UNROLL=OFF
    -DSSNATIVE_OPTIMIZATION_LEVEL=3
    -DSSNATIVE_ENABLE_STEREO_PAIR_KERNELS=ON
    -DSSNATIVE_COMPACT_DYNAMICS=ON
    -DSSNATIVE_M12_UNIFIED_DYNAMICS=ON
    -DSSNATIVE_M12_DIRECT_CONSTANT_CACHE=OFF
    -DSSNATIVE_M13_NATIVE_STATE_OUTPUT=ON
    -DSSNATIVE_M13_NATIVE_BAND_POST=ON
    -DSSNATIVE_M13_NATIVE_DELAY_OUTPUT=ON
    -DSSNATIVE_M13_NATIVE_PREFILTER_SETUP=ON
    -DSSNATIVE_M13_NATIVE_POSTFILTER=ON
    -DSSNATIVE_M13_OUTLINE_FILTER_BANK_STAGE=OFF
    -DSSNATIVE_M13_OUTLINE_BIQUAD_STAGE=ON
    -DSSNATIVE_M13_OUTLINE_ONE_POLE_STAGE=ON
    -DSSNATIVE_M13_OUTLINE_FOURTH_STAGE=ON
    -DSSNATIVE_PGO_DIR="$PGO_DATA"
)

configure() {
    local mode="$1"
    cmake -S "$PROJECT_ROOT" -B "$BUILD_DIR" "${GENERATOR[@]}" \
        "${COMMON_CMAKE[@]}" -DSSNATIVE_PGO_MODE="$mode"
}

benchmark_values() {
    python3 - "$1" "$2" <<'PY'
from pathlib import Path
import sys
seconds=float(sys.argv[1])
wall,user,system=map(float,Path(sys.argv[2]).read_text().split())
cpu=user+system
print(f"{wall:.3f} {cpu:.3f} {cpu/seconds*100:.2f}")
PY
}

printf '%s %s structured-process-flow native-double build\n' "$PRODUCT_NAME" "$PACKAGE_VERSION"
printf 'Target: %s (%s)\n' "${MODEL:-unknown}" "$CPU_NAME"
printf 'Fresh PGO training: %ss, block=1024\n' "$PGO_SECONDS"
printf 'Performance target: %s%%; package gate: %s%% single-core load\n' "$TARGET_LOAD" "$MAX_LOAD"

rm -rf -- "$WORK_ROOT"
mkdir -p -- "$WORK_ROOT"
GENERATOR_PCM="$WORK_ROOT/generate-bitexact-pcm"
STRESS_PCM="$WORK_ROOT/generate-stress-pcm"
cc -O3 -std=c11 -Wall -Wextra -Wpedantic "$GENERATOR_PCM_SOURCE" -o "$GENERATOR_PCM"
cc -O3 -std=c11 -Wall -Wextra -Wpedantic "$STRESS_PCM_SOURCE" -o "$STRESS_PCM"
INPUT_PGO="$WORK_ROOT/training-${PGO_SECONDS}s.pcm"
"$GENERATOR_PCM" --seconds "$PGO_SECONDS" > "$INPUT_PGO"

printf '\nNamed-state address audit...\n'
python3 "$STATE_AUDIT" --root "$PROJECT_ROOT" --report "$WORK_ROOT/NAMED-STATE-ADDRESS-AUDIT.txt"
printf '\nStructured process flow audit...\n'
python3 "$CONTROL_AUDIT" --root "$PROJECT_ROOT" --report "$WORK_ROOT/NATIVE-CONTROL-AUDIT.txt"

printf '\nStage 1/2: instrumented native cold-control build and PGO training...\n'
configure generate
GENERATE_LOG="$WORK_ROOT/generate-build.log"
cmake --build "$BUILD_DIR" --target ssnative-process-raw --parallel "$JOBS" 2>&1 | tee "$GENERATE_LOG"
if grep -Eq '(^|:)[[:space:]]*warning:' "$GENERATE_LOG"; then fail "Instrumented build emitted warnings"; fi
SSNATIVE_BLOCK_FRAMES=1024 "$BUILD_DIR/ssnative-process-raw" "$CONFIG_SOURCE" 2 44100 < "$INPUT_PGO" >/dev/null
PGO_FILE_COUNT="$(find "$PGO_DATA" -type f -name '*.gcda' | wc -l)"
[[ "$PGO_FILE_COUNT" -ge 5 ]] || fail "Too few PGO files: $PGO_FILE_COUNT"

printf '\nStage 2/2: final profile-use build...\n'
configure use
FINAL_LOG="$WORK_ROOT/final-build.log"
cmake --build "$BUILD_DIR" --parallel "$PGO_JOBS" 2>&1 | tee "$FINAL_LOG"
if grep -Eqi 'profile count data file not found|profile data.*out of date|coverage-mismatch' "$FINAL_LOG"; then
    fail "GCC did not consume the fresh PGO profile correctly"
fi
if grep -Eq '(^|:)[[:space:]]*warning:' "$FINAL_LOG"; then fail "Final build emitted warnings"; fi
ctest --test-dir "$BUILD_DIR" --output-on-failure
rm -rf -- "$INSTALL_DIR"
cmake --install "$BUILD_DIR"

PROCESSOR="$INSTALL_DIR/bin/ssnative-process-raw"
LIBRARY="$INSTALL_DIR/lib/libsoundsolution.so.2"
CONFIG="$INSTALL_DIR/share/soundsolution-native/ss18.dat"
[[ -x "$PROCESSOR" && -f "$LIBRARY" && -f "$CONFIG" ]] || fail "Installed runtime is incomplete"
if [[ "$SMOKE_MODE" == 0 ]]; then
    readelf -h "$LIBRARY" | grep -Eq 'Machine:[[:space:]]+AArch64' || fail "Library is not AArch64"
fi

VALIDATION="$WORK_ROOT/validation"
mkdir -p "$VALIDATION"
"$GENERATOR_PCM" --seconds 3 > "$VALIDATION/input-3s.pcm"
INPUT_3_SHA="$(sha256sum "$VALIDATION/input-3s.pcm" | awk '{print $1}')"
[[ "$INPUT_3_SHA" == "$REFERENCE_INPUT_3_SHA" ]] || fail "Native normal corpus generator differs from reference: $INPUT_3_SHA"
printf '\nBlock-boundary determinism...\n'
BASELINE_3_SHA=""
for block in "${BLOCK_SIZES[@]}"; do
    SSNATIVE_BLOCK_FRAMES="$block" "$PROCESSOR" "$CONFIG" 2 44100 \
        < "$VALIDATION/input-3s.pcm" > "$VALIDATION/output-3s-$block.pcm"
    hash="$(sha256sum "$VALIDATION/output-3s-$block.pcm" | awk '{print $1}')"
    [[ -n "$BASELINE_3_SHA" ]] || BASELINE_3_SHA="$hash"
    [[ "$hash" == "$BASELINE_3_SHA" ]] || fail "Block-size dependent PCM: block=$block hash=$hash baseline=$BASELINE_3_SHA"
    printf '  block=%-4s SHA-256=%s\n' "$block" "$hash"
done
[[ "$BASELINE_3_SHA" == "$REFERENCE_3_SHA" ]] \
    || fail "3-second PCM differs from the native-double reference: $BASELINE_3_SHA"

"$GENERATOR_PCM" --seconds 30 > "$VALIDATION/input-30s.pcm"
printf '\n30-second performance and determinism validation...\n'
/usr/bin/time -f '%e %U %S' -o "$VALIDATION/time-30.txt" \
    env SSNATIVE_BLOCK_FRAMES=1024 "$PROCESSOR" "$CONFIG" 2 44100 \
    < "$VALIDATION/input-30s.pcm" > "$VALIDATION/output-30s-a.pcm"
SSNATIVE_BLOCK_FRAMES=1024 "$PROCESSOR" "$CONFIG" 2 44100 \
    < "$VALIDATION/input-30s.pcm" > "$VALIDATION/output-30s-b.pcm"
SHA_30_A="$(sha256sum "$VALIDATION/output-30s-a.pcm" | awk '{print $1}')"
SHA_30_B="$(sha256sum "$VALIDATION/output-30s-b.pcm" | awk '{print $1}')"
[[ "$SHA_30_A" == "$SHA_30_B" ]] || fail "Repeated 30-second run is not deterministic"
[[ "$SHA_30_A" == "$REFERENCE_30_SHA" ]] \
    || fail "30-second PCM differs from the native-double reference: $SHA_30_A"
read -r WALL_30 CPU_30 LOAD_30 < <(benchmark_values 30 "$VALIDATION/time-30.txt")
printf 'SHA-256=%s; wall=%ss; CPU=%ss; single-core load=%s%%\n' "$SHA_30_A" "$WALL_30" "$CPU_30" "$LOAD_30"
if [[ "$SMOKE_MODE" == 0 ]]; then
    python3 - "$LOAD_30" "$MAX_LOAD" <<'PY' || fail "Performance gate failed"
import sys
raise SystemExit(0 if float(sys.argv[1]) <= float(sys.argv[2]) else 1)
PY
fi

printf '\n30-second stress validation...\n'
"$STRESS_PCM" --seconds 30 > "$VALIDATION/input-stress-30s.pcm"
INPUT_STRESS_SHA="$(sha256sum "$VALIDATION/input-stress-30s.pcm" | awk '{print $1}')"
[[ "$INPUT_STRESS_SHA" == "$REFERENCE_INPUT_STRESS_SHA" ]] || fail "Native stress corpus generator differs from reference: $INPUT_STRESS_SHA"
SSNATIVE_BLOCK_FRAMES=1024 "$PROCESSOR" "$CONFIG" 2 44100 \
    < "$VALIDATION/input-stress-30s.pcm" > "$VALIDATION/output-stress-30s.pcm"
STRESS_SHA="$(sha256sum "$VALIDATION/output-stress-30s.pcm" | awk '{print $1}')"
printf 'SHA-256=%s\n' "$STRESS_SHA"
[[ "$STRESS_SHA" == "$REFERENCE_STRESS_SHA" ]] \
    || fail "Stress PCM differs from the native-double reference: $STRESS_SHA"

LONG_SHA="not-run"
if [[ "$RUN_LONG" == 1 ]]; then
    printf '\n270-second continuous validation...\n'
    "$GENERATOR_PCM" --seconds 270 > "$VALIDATION/input-270s.pcm"
    SSNATIVE_BLOCK_FRAMES=1024 "$PROCESSOR" "$CONFIG" 2 44100 \
        < "$VALIDATION/input-270s.pcm" > "$VALIDATION/output-270s.pcm"
    LONG_SHA="$(sha256sum "$VALIDATION/output-270s.pcm" | awk '{print $1}')"
    printf 'SHA-256=%s\n' "$LONG_SHA"
    [[ "$LONG_SHA" == "$REFERENCE_270_SHA" ]] \
        || fail "270-second PCM differs from the native-double reference: $LONG_SHA"
fi

REF3_MATCH=no; [[ "$BASELINE_3_SHA" == "$REFERENCE_3_SHA" ]] && REF3_MATCH=yes
REF30_MATCH=no; [[ "$SHA_30_A" == "$REFERENCE_30_SHA" ]] && REF30_MATCH=yes

cat > "$INSTALL_DIR/BUILD-INFO.txt" <<INFO
Product: ${PRODUCT_NAME}
Package version: ${PACKAGE_VERSION}
Engine: SoundSolution Native ${ENGINE_VERSION}
Arithmetic: native IEEE-754 binary64 (double); no binary80 processing backend
Execution layout: configure/postload/reset are direct stackless C++; process uses a typed structured C++ stage loop with no goto, numeric code label, x86 register identifier, process code include, runtime instruction table, interpreter, dispatcher or continuation
State layout: named-state-v14/structured-process-flow
State active bytes: 643072
State virtual compatibility bytes: 1064960
State clear policy: only three proven live ranges are initialized; compatibility gaps remain untouched
Process call-local native frame bytes: 512
Process persistent workspace bytes: 0
Runtime process program instructions: 0
Structured process operation audit count: 978
Structured process stages: 87
Process goto statements: 0
Numeric process labels: 0
Legacy x86 register identifiers: 0
Folded native hot operations: 53
Legacy control domains: 0
Continuation capacity and state bytes: 0
Hot process cache bytes: 8704
Configure/postload physical stack bytes: 0
Validation corpus generators: native C, byte-identical to retained Python references
3-second input corpus SHA-256: ${INPUT_3_SHA}
30-second stress input corpus SHA-256: ${INPUT_STRESS_SHA}
Audio process allocations: none
Target: Raspberry Pi 5 (${CPU_NAME})
PGO training: ${PGO_SECONDS}s, block=1024, fresh profile files=${PGO_FILE_COUNT}
3-second SHA-256: ${BASELINE_3_SHA}
3-second native-double reference match: ${REF3_MATCH}
30-second SHA-256: ${SHA_30_A}
30-second native-double reference match: ${REF30_MATCH}
30-second CPU seconds: ${CPU_30}
30-second single-core load: ${LOAD_30}%
Performance target: ${TARGET_LOAD}%
Package performance gate: ${MAX_LOAD}%
Stress 30-second SHA-256: ${STRESS_SHA}
native-double stress reference SHA-256: ${REFERENCE_STRESS_SHA}
270-second SHA-256: ${LONG_SHA}
native-double 270-second reference SHA-256: ${REFERENCE_270_SHA}
Build UTC: $(date -u +%Y-%m-%dT%H:%M:%SZ)
INFO
cp "$PROJECT_ROOT/VERSION" "$INSTALL_DIR/PACKAGE-VERSION"
cp "$PROJECT_ROOT/VERSION.json" "$INSTALL_DIR/VERSION.json"
cp "$PROJECT_ROOT/BUILD-ID" "$INSTALL_DIR/BUILD-ID"
cp "$WORK_ROOT/NAMED-STATE-ADDRESS-AUDIT.txt" "$INSTALL_DIR/NAMED-STATE-ADDRESS-AUDIT.txt"
cp "$WORK_ROOT/NATIVE-CONTROL-AUDIT.txt" "$INSTALL_DIR/NATIVE-CONTROL-AUDIT.txt"

mkdir -p -- "$(dirname -- "$PACKAGE_FILE")"
rm -f -- "$PACKAGE_FILE"
tar -C "$WORK_ROOT" -czf "$PACKAGE_FILE" "$(basename -- "$INSTALL_DIR")"
printf '\nSUCCESS\nRuntime: %s\nSHA-256: %s\n' "$PACKAGE_FILE" "$(sha256sum "$PACKAGE_FILE" | awk '{print $1}')"
