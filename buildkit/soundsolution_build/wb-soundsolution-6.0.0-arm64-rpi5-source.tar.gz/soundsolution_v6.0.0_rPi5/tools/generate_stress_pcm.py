#!/usr/bin/env python3
"""Generate a deterministic 30-second stereo s16le edge-case corpus."""

from __future__ import annotations

import argparse
import struct
import sys


def clamp_s16(value: int) -> int:
    return max(-32768, min(32767, value))


def sample(frame: int, sample_rate: int) -> tuple[int, int]:
    second = frame // sample_rate
    if second < 3:
        return 0, 0
    if second < 6:
        return 32767, -32768
    if second < 9:
        return -32768, 32767
    if second < 12:
        return ((32767, -32768) if (frame & 1) == 0
                else (-32768, 32767))
    if second < 15:
        return (32767 if frame % 997 == 0 else 0,
                -32768 if frame % 991 == 0 else 0)
    if second < 18:
        phase = frame % (2 * 65536)
        value = phase - 65536 if phase >= 65536 else phase
        value = clamp_s16(value)
        return value, -value - 1
    if second < 21:
        values = (0, 1, -1, 2, -2, 32767, -32768, 0)
        return values[frame % len(values)], values[(frame * 3) % len(values)]
    if second < 24:
        left = ((frame * 1103515245 + 12345) >> 16) & 0xFFFF
        right = ((frame * 1664525 + 1013904223) >> 16) & 0xFFFF
        return (left - 65536 if left >= 32768 else left,
                right - 65536 if right >= 32768 else right)
    if second < 27:
        return (30000 if (frame // 64) & 1 else -30000,
                25000 if (frame // 127) & 1 else -25000)

    x = (frame * 6364136223846793005 + 1442695040888963407) & ((1 << 64) - 1)
    y = (x ^ (x >> 29) ^ (x << 17)) & ((1 << 64) - 1)
    left = (x >> 32) & 0xFFFF
    right = (y >> 32) & 0xFFFF
    return (left - 65536 if left >= 32768 else left,
            right - 65536 if right >= 32768 else right)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--seconds", type=int, default=30)
    parser.add_argument("--sample-rate", type=int, default=44100)
    args = parser.parse_args()
    if args.seconds <= 0 or args.sample_rate <= 0:
        parser.error("seconds and sample-rate must be positive")

    output = sys.stdout.buffer
    for frame in range(args.seconds * args.sample_rate):
        output.write(struct.pack("<hh", *sample(frame, args.sample_rate)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
