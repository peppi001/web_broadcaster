#!/usr/bin/env python3
"""Generate a deterministic signed-16-bit stereo PCM validation corpus."""

from __future__ import annotations

import argparse
import struct
import sys

EDGE_VALUES = (
    0, 0,
    32767, 1,
    -32768, -16384,
    1, 0,
    -1, 1,
    16384, -16384,
    -16384, 0,
    30000, 1,
    -30000, -1,
    32766, -32767,
    2, -2,
    12345, -23456,
    -12345, 23456,
)


def xorshift32(value: int) -> int:
    value ^= (value << 13) & 0xFFFFFFFF
    value ^= value >> 17
    value ^= (value << 5) & 0xFFFFFFFF
    return value & 0xFFFFFFFF


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--seconds", type=int, required=True)
    parser.add_argument("--sample-rate", type=int, default=44100)
    parser.add_argument("--channels", type=int, default=2, choices=(1, 2))
    parser.add_argument("--seed", type=lambda text: int(text, 0), default=0x6D2B79F5)
    args = parser.parse_args()
    if args.seconds <= 0 or args.sample_rate < 44100:
        parser.error("seconds must be positive and sample-rate must be at least 44100")

    sample_count = args.seconds * args.sample_rate * args.channels
    state = args.seed & 0xFFFFFFFF
    output = sys.stdout.buffer
    chunk = bytearray()
    pack = struct.Struct("<h").pack

    for index in range(sample_count):
        if index < len(EDGE_VALUES):
            sample = EDGE_VALUES[index]
        else:
            state = xorshift32(state)
            raw = (state >> 16) & 0xFFFF
            signed = raw - 0x10000 if raw >= 0x8000 else raw
            # Keep the long validation stream in a realistic headroom range.
            # Full-scale and low-level edge cases are already covered by the
            # fixed prefix above.
            sample = signed // 4
            selector = index & 0x3FFF
            if selector == 2:
                sample = 1
            elif selector == 3:
                sample = -1

        chunk += pack(sample)
        if len(chunk) >= 1 << 20:
            output.write(chunk)
            chunk.clear()

    if chunk:
        output.write(chunk)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
