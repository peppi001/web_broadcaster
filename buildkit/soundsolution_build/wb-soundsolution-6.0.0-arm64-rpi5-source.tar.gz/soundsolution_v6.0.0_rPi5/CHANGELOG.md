# Changelog

## 6.0.0

- Structured process stage loop replaced all numeric labels and goto branches.
- Removed all x86 register identifiers from the process source.
- Renamed the native-double compatibility layer and all x87-prefixed symbols.
- Added structured process-stage diagnostics and strict source audits.
- Preserved the 5.1.0 native-double PCM reference exactly in local validation.


## 5.1.0

- A `native_process_body.inc` teljesen eltávolítva.
- A process forrás közvetlenül a C++ fordítási egységbe került.
- Az utasításonkénti címkelánc 1113-ról 86 vezérlési címkére csökkent.
- Az explicit ugrások száma 1185-ről 110-re csökkent.
- Minden referencia PCM-hash bitazonos az 5.0.0-val.
- SONAME és C ABI kompatibilis maradt (`libsoundsolution.so.2`).

## 5.0.0

- Az utolsó process programtábla és runtime instrukcióvégrehajtó eltávolítva.
- A process continuation és visszatérési dispatcher megszűnt.
- A process lebegőpontos scratch már nem tart fenn x87 top/depth állapotot.
- A process teljes állapota híváslokális; tartós workspace nincs.
- A process 512 bájtos natív scratch frame-et használ.
- A 3/30/stress/270 másodperces PCM-hashek bitazonosak a 4.0.0-val.
- SONAME és C ABI kompatibilis maradt (`libsoundsolution.so.2`).
