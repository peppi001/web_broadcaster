#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"; cd "$ROOT"
fail(){ printf 'ERROR: %s\n' "$*" >&2; exit 1; }
EXPECTED_PRODUCT="soundsolution_v6.0.0_rPi5"
EXPECTED_VERSION="6.0.0"
EXPECTED_BUILD_ID="soundsolution_v6.0.0_rPi5-6.0.0-structured-process-flow-pgo30"
for file in VERSION VERSION.json BUILD-ID PACKAGE-IDENTITY.txt PORT_STATUS.json MANIFEST.sha256 \
 CMakeLists.txt src/named_state_engine.cpp src/native_process_layout.hpp \
 src/named_state_layout.hpp src/native_double.hpp tools/audit_named_state.py \
 tools/audit_native_control.py tools/build_rpi5_fully_native.sh \
 tools/generate_bitexact_pcm.c tools/generate_stress_pcm.c \
 docs/STRUCTURED_PROCESS_FLOW_6_0_0.md; do
    [[ -f "$file" ]] || fail "$file is missing"
done
for retired in src/native_process_body.inc src/native_control_process.inc \
 src/process_program.inc src/native_process_direct.inc src/native_control_layout.hpp \
 src/native_control_configure.inc src/native_control_postload.inc \
 src/reconstructed_program.inc src/x87_compat.hpp; do
    [[ ! -e "$retired" ]] || fail "retired source remains: $retired"
done
mapfile -t INC_FILES < <(find src -maxdepth 1 -type f -name '*.inc' -printf '%f\n' | LC_ALL=C sort)
[[ "${INC_FILES[*]}" == "original_data.inc original_rdata.inc" ]] \
    || fail "unexpected .inc sources: ${INC_FILES[*]}"
[[ "$(tr -d '[:space:]' < VERSION)" == "$EXPECTED_VERSION" ]] || fail "VERSION mismatch"
[[ "$(tr -d '\r\n' < BUILD-ID)" == "$EXPECTED_BUILD_ID" ]] || fail "BUILD-ID mismatch"
grep -Fxq "Product: $EXPECTED_PRODUCT" PACKAGE-IDENTITY.txt || fail "Product identity mismatch"
grep -Fq 'project(soundsolution_native VERSION 6.0.0' CMakeLists.txt || fail "CMake version mismatch"
grep -Fq 'SOVERSION 2' CMakeLists.txt || fail "SONAME major mismatch"
grep -Fq 'using NativeDouble = double;' src/native_double.hpp || fail "Native double alias missing"
for required in 'kProcessFrameBytes = 512u' 'kContinuationCapacity = 0u' \
 'kControlDomainCount = 0u' 'kProcessProgramInstructionCount = 0u' \
 'kDirectProcessBodyCount = 978u' 'kStructuredProcessStageCount = 87u' \
 'kProcessGotoCount = 0u' 'kProcessNumericLabelCount = 0u' \
 'kLegacyRegisterIdentifierCount = 0u'; do
    grep -Fq "$required" src/native_process_layout.hpp || fail "Missing layout: $required"
done
grep -Fq 'enum class ProcessStage : std::uint8_t' src/named_state_engine.cpp || fail "Process stage enum missing"
grep -Fq 'switch (stage)' src/named_state_engine.cpp || fail "Structured process switch missing"
! grep -Eq '\bgoto\b' src/named_state_engine.cpp || fail "goto remains"
! grep -Eq '^\s*L_[0-9a-fA-F]+:' src/named_state_engine.cpp || fail "numeric label remains"
! grep -Eq '\b(eax|ebx|ecx|edx|esi|edi|esp|ebp)\b' src/named_state_engine.cpp || fail "legacy register name remains"
! grep -Eq '\bX87\b|x87_' src/named_state_engine.cpp src/native_double.hpp || fail "x87 compatibility name remains"
for api in ssnative_state_layout ssnative_control_layout ssnative_state_active_bytes \
 ssnative_state_virtual_bytes ssnative_control_stack_virtual_bytes \
 ssnative_control_stack_physical_bytes ssnative_cold_control_stack_physical_bytes \
 ssnative_control_continuation_capacity ssnative_control_executor_bytes \
 ssnative_hot_control_cache_bytes ssnative_control_domain_count \
 ssnative_control_continuation_state_bytes ssnative_persistent_continuation_bytes \
 ssnative_process_program_instruction_count ssnative_process_frame_bytes \
 ssnative_direct_process_body_count ssnative_structured_process_stage_count \
 ssnative_persistent_process_workspace_bytes; do
    grep -Fq "$api" include/ssnative/ssnative.h || fail "$api C API missing"
done
STATE_REPORT="$(mktemp)"; PROCESS_REPORT="$(mktemp)"; GEN_TMP="$(mktemp -d)"
trap 'rm -f "$STATE_REPORT" "$PROCESS_REPORT"; rm -rf "$GEN_TMP"' EXIT
python3 tools/audit_named_state.py --root "$ROOT" > "$STATE_REPORT"
python3 tools/audit_native_control.py --root "$ROOT" > "$PROCESS_REPORT"
grep -Fq 'Unmapped compatibility-gap addresses: 0' "$STATE_REPORT" || fail "Named-state audit failed"
grep -Fq 'Structured process stages: 87' "$PROCESS_REPORT" || fail "Structured stage audit failed"
grep -Fq 'Process goto statements: 0' "$PROCESS_REPORT" || fail "goto audit failed"
grep -Fq 'Numeric process labels: 0' "$PROCESS_REPORT" || fail "label audit failed"
grep -Fq 'Legacy x86 register identifiers: 0' "$PROCESS_REPORT" || fail "register audit failed"
python3 -m json.tool VERSION.json >/dev/null
python3 -m json.tool PORT_STATUS.json >/dev/null
python3 - <<'PY'
from pathlib import Path
import json
v=json.loads(Path('VERSION.json').read_text())
assert v['product_name']=='soundsolution_v6.0.0_rPi5'
assert v['package_version']=='6.0.0'
assert v['build_id']=='soundsolution_v6.0.0_rPi5-6.0.0-structured-process-flow-pgo30'
assert v['engine_version']=='6.0.0'
assert v['arithmetic_mode']=='native-double'
assert v['binary80_in_audio_path'] is False
assert v['shared_library_soname']=='libsoundsolution.so.2'
assert v['state_layout']['mode']=='named-state-v14/structured-process-flow'
p=v['process_layout']
assert p['mode']=='structured-process-v1/typed-state-loop'
assert p['runtime_instruction_table'] is False
assert p['runtime_dispatcher'] is False
assert p['continuation_state_bytes']==0
assert p['persistent_workspace_bytes']==0
assert p['call_local_native_frame_bytes']==512
assert p['structured_stage_count']==87
assert p['goto_count']==0
assert p['numeric_label_count']==0
assert p['legacy_register_identifier_count']==0
PY
bash -n build.sh
bash -n tools/build_rpi5_fully_native.sh
cc -std=c11 -Wall -Wextra -Wpedantic -fsyntax-only tools/generate_bitexact_pcm.c
cc -std=c11 -Wall -Wextra -Wpedantic -fsyntax-only tools/generate_stress_pcm.c
cc -O2 -std=c11 tools/generate_bitexact_pcm.c -o "$GEN_TMP/normal"
cc -O2 -std=c11 tools/generate_stress_pcm.c -o "$GEN_TMP/stress"
"$GEN_TMP/normal" --seconds 3 > "$GEN_TMP/normal.pcm"
"$GEN_TMP/stress" --seconds 30 > "$GEN_TMP/stress.pcm"
[[ "$(sha256sum "$GEN_TMP/normal.pcm" | awk '{print $1}')" == "dc1d9263b214b8217ca8e38fdc4063c385b37b17ba1e769cca0d60fcc3a4f3d6" ]] || fail "Normal corpus mismatch"
[[ "$(sha256sum "$GEN_TMP/stress.pcm" | awk '{print $1}')" == "30ea4df8d3b76b03f522fac47ec6eabf23ccee7f6fa696e74fbf8b270e052e2f" ]] || fail "Stress corpus mismatch"
sha256sum -c MANIFEST.sha256
printf 'OK: SoundSolution Native 6.0.0 structured-process-flow package verified.\n'
