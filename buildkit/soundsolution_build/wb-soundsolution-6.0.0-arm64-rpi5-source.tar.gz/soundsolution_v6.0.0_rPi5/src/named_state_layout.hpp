#pragma once

#include <array>
#include <cstddef>
#include <cstdint>

namespace ssnative::detail::named_state {

// The reconstructed program still uses the original 32-bit virtual addresses
// as stable identifiers.  Version 6.0.0 no longer reserves the holes between
// the three live ranges: only the immutable tables, runtime DSP state and DAT
// configuration regions have physical storage.
inline constexpr std::uint32_t kVirtualBase = 0x1000c000u;
inline constexpr std::uint32_t kVirtualEnd = 0x10110000u;

inline constexpr std::uint32_t kConstantsBase = 0x1000c000u;
inline constexpr std::uint32_t kConstantsEnd = 0x10011000u;
inline constexpr std::uint32_t kRuntimeBase = 0x1004a000u;
inline constexpr std::uint32_t kRuntimeEnd = 0x100d8000u;
inline constexpr std::uint32_t kConfigurationBase = 0x10106000u;
inline constexpr std::uint32_t kConfigurationEnd = 0x10110000u;

inline constexpr std::size_t kConstantsBytes = kConstantsEnd - kConstantsBase;
inline constexpr std::size_t kRuntimeBytes = kRuntimeEnd - kRuntimeBase;
inline constexpr std::size_t kConfigurationBytes =
    kConfigurationEnd - kConfigurationBase;
inline constexpr std::size_t kPhysicalBytes =
    kConstantsBytes + kRuntimeBytes + kConfigurationBytes;
inline constexpr std::size_t kCompatibilityVirtualBytes =
    kVirtualEnd - kVirtualBase;

inline constexpr std::size_t kConstantsOffset = 0u;
inline constexpr std::size_t kRuntimeOffset = kConstantsBytes;
inline constexpr std::size_t kConfigurationOffset =
    kConstantsBytes + kRuntimeBytes;

inline constexpr std::size_t kPageShift = 12u;
inline constexpr std::size_t kPageBytes = 1u << kPageShift;
inline constexpr std::size_t kPageMask = kPageBytes - 1u;
inline constexpr std::size_t kVirtualPageCount =
    kCompatibilityVirtualBytes / kPageBytes;
inline constexpr std::uint32_t kUnmappedPage = 0xffffffffu;

[[nodiscard]] consteval bool contains_static(const std::uint32_t address,
                                             const std::size_t size) {
    const auto end = static_cast<std::uint64_t>(address) + size;
    return (address >= kConstantsBase && end <= kConstantsEnd) ||
           (address >= kRuntimeBase && end <= kRuntimeEnd) ||
           (address >= kConfigurationBase && end <= kConfigurationEnd);
}

[[nodiscard]] consteval std::size_t physical_offset_static(
    const std::uint32_t address) {
    if (address >= kConstantsBase && address < kConstantsEnd) {
        return kConstantsOffset + (address - kConstantsBase);
    }
    if (address >= kRuntimeBase && address < kRuntimeEnd) {
        return kRuntimeOffset + (address - kRuntimeBase);
    }
    if (address >= kConfigurationBase && address < kConfigurationEnd) {
        return kConfigurationOffset + (address - kConfigurationBase);
    }
    return static_cast<std::size_t>(kUnmappedPage);
}

[[nodiscard]] consteval std::array<std::uint32_t, kVirtualPageCount>
make_page_offsets() {
    std::array<std::uint32_t, kVirtualPageCount> result{};
    result.fill(kUnmappedPage);
    for (std::size_t page = 0; page < kVirtualPageCount; ++page) {
        const auto address = kVirtualBase +
            static_cast<std::uint32_t>(page * kPageBytes);
        const auto offset = physical_offset_static(address);
        if (offset != static_cast<std::size_t>(kUnmappedPage)) {
            result[page] = static_cast<std::uint32_t>(offset);
        }
    }
    return result;
}

inline constexpr auto kPageOffsets = make_page_offsets();

namespace reset {
inline constexpr std::uint32_t dynamics_a_base = 0x1000edc8u;
inline constexpr std::size_t dynamics_a_bytes = 510u * sizeof(std::uint32_t);
inline constexpr std::uint32_t dynamics_b_base = 0x1000f678u;
inline constexpr std::size_t dynamics_b_bytes = 890u * sizeof(std::uint32_t);
inline constexpr std::uint32_t delay_state_base = 0x1004cee8u;
inline constexpr std::size_t delay_state_bytes = 256u * sizeof(std::uint32_t);
static_assert(dynamics_a_base + dynamics_a_bytes == 0x1000f5c0u);
static_assert(dynamics_b_base + dynamics_b_bytes == 0x10010460u);
static_assert(delay_state_base + delay_state_bytes == 0x1004d2e8u);
} // namespace reset

namespace address {
// Immutable arithmetic tables.
inline constexpr std::uint32_t unity = 0x1000c000u;
inline constexpr std::uint32_t init_table_source = 0x1000c020u;
inline constexpr std::uint32_t table_scale = 0x1000c4c0u;
inline constexpr std::uint32_t sample_percent_scale = 0x1000c4e0u;
inline constexpr std::uint32_t blend_previous = 0x1000c560u;
inline constexpr std::uint32_t blend_current = 0x1000c570u;
inline constexpr std::uint32_t zero = 0x1000c6c0u;
inline constexpr std::uint32_t filter_constant_cache = 0x100d7600u;

// Runtime sample and detector state used by the native process blocks.
inline constexpr std::uint32_t output_right = 0x100d6168u;
inline constexpr std::uint32_t output_left = 0x100d6170u;
inline constexpr std::uint32_t band_outputs = 0x100d6360u;
inline constexpr std::uint32_t band_output_end = 0x100d63b8u;
inline constexpr std::uint32_t delayed_bands = 0x100d6800u;
inline constexpr std::uint32_t input_right = 0x100d6a60u;
inline constexpr std::uint32_t input_left = 0x100d6a68u;
inline constexpr std::uint32_t delay_index = 0x100d5f20u;
inline constexpr std::uint32_t delay_limit = 0x100d5f5cu;
inline constexpr std::uint32_t soft_clip_knee = 0x100d68e8u;
inline constexpr std::uint32_t first_peak = 0x100d5ef0u;
inline constexpr std::uint32_t second_peak = 0x100d5ef8u;
inline constexpr std::uint32_t post_scale = 0x100d67e8u;
inline constexpr std::uint32_t delay_history = 0x1004d2e8u;
inline constexpr std::uint32_t smoothed_band_gain = 0x1004aed0u;
inline constexpr std::uint32_t init_table_destination = 0x1004af08u;

// DAT-backed configuration fields used directly in the audio hot path.
inline constexpr std::uint32_t common_base = 0x10106040u;
inline constexpr std::uint32_t process_base = 0x1010a860u;
inline constexpr std::uint32_t interpolation_percent = 0x10106110u;
inline constexpr std::uint32_t delay_weights = 0x1010f4a0u;
inline constexpr std::uint32_t mode_flags = 0x101060f0u;
inline constexpr std::uint32_t soft_clip_disabled = 0x101060a4u;
inline constexpr std::uint32_t signature = 0x1010600cu;

// Dynamics state and configuration arrays.
inline constexpr std::uint32_t dynamics_enable = 0x100d6a00u;
inline constexpr std::uint32_t dynamics_level = 0x100d5ec8u;
inline constexpr std::uint32_t dynamics_detector = 0x1000f638u;
inline constexpr std::uint32_t dynamics_power = 0x10010490u;
inline constexpr std::uint32_t dynamics_gain = 0x1000ed80u;
inline constexpr std::uint32_t dynamics_runtime = 0x1010ee20u;
inline constexpr std::uint32_t global_threshold = 0x100d635cu;
inline constexpr std::uint32_t dynamics_release_mode = 0x100d5f58u;
inline constexpr std::uint32_t dynamics_low_path_enabled = 0x101060dcu;
inline constexpr std::uint32_t dynamics_global_path_bypass = 0x101060d8u;
inline constexpr std::uint32_t dynamics_release_program = 0x101060b4u;
inline constexpr std::uint32_t dynamics_final_limiter = 0x101060e0u;

// State/output native block.
inline constexpr std::uint32_t state_mix_a = 0x100d6850u;
inline constexpr std::uint32_t state_mix_b = 0x100d6854u;
inline constexpr std::uint32_t state_mix_c = 0x100d6858u;
inline constexpr std::uint32_t state_mix_d = 0x100d685cu;
inline constexpr std::uint32_t output_state_left = 0x100d6110u;
inline constexpr std::uint32_t output_state_left_aux = 0x100d6118u;
inline constexpr std::uint32_t output_state_right = 0x100d6128u;
inline constexpr std::uint32_t output_state_right_aux = 0x100d6130u;
inline constexpr std::uint32_t output_history_left_a = 0x1004af78u;
inline constexpr std::uint32_t output_history_left_b = 0x1004af80u;
inline constexpr std::uint32_t output_history_right_a = 0x1004af88u;
inline constexpr std::uint32_t output_history_right_b = 0x1004af90u;

// Filter-bank, pre/post-filter and delay sections.
inline constexpr std::uint32_t filter_bank_coefficients_normal = 0x1000c128u;
inline constexpr std::uint32_t filter_bank_coefficients_alternate = 0x1000c290u;
inline constexpr std::uint32_t filter_bank_state = 0x100d6658u;
inline constexpr std::uint32_t high_biquad_coefficients_a = 0x1000d590u;
inline constexpr std::uint32_t high_biquad_coefficients_b = 0x1000d568u;
inline constexpr std::uint32_t high_biquad_state_a = 0x100d7840u;
inline constexpr std::uint32_t high_biquad_state_b = 0x100d7880u;
inline constexpr std::uint32_t prefilter_coefficients_a = 0x1000d760u;
inline constexpr std::uint32_t prefilter_coefficients_b = 0x1000d748u;
inline constexpr std::uint32_t prefilter_state_a = 0x100d5fb8u;
inline constexpr std::uint32_t prefilter_state_b = 0x100d5ff8u;
inline constexpr std::uint32_t postfilter_coefficients_a = 0x1000d5c8u;
inline constexpr std::uint32_t postfilter_coefficients_b = 0x1000d610u;
inline constexpr std::uint32_t postfilter_state_a = 0x100d6960u;
inline constexpr std::uint32_t postfilter_state_b = 0x100d75a0u;
inline constexpr std::uint32_t postfilter_alt_state_a = 0x100d6900u;
inline constexpr std::uint32_t postfilter_alt_state_b = 0x100d7600u;
inline constexpr std::uint32_t delay_mix_left = 0x1004af00u;
inline constexpr std::uint32_t delay_mix_right = 0x1004aef8u;
inline constexpr std::uint32_t delay_gain_left = 0x1000edb0u;
inline constexpr std::uint32_t delay_gain_right = 0x1000eda8u;
inline constexpr std::uint32_t delay_tap_left_a = 0x1004d318u;
inline constexpr std::uint32_t delay_tap_right_a = 0x1004d310u;
inline constexpr std::uint32_t delay_tap_left_b = 0x1004d350u;
inline constexpr std::uint32_t delay_tap_right_b = 0x1004d348u;
inline constexpr std::uint32_t output_peak = 0x100d63f0u;
inline constexpr std::uint32_t postfilter_meter_a = 0x100d63e0u;
inline constexpr std::uint32_t postfilter_meter_b = 0x100d63e8u;
inline constexpr std::uint32_t clip_threshold = 0x1010f4b4u;
inline constexpr std::uint32_t output_selector = 0x101060c8u;
inline constexpr std::uint32_t output_gain_selector = 0x1010f4b8u;
inline constexpr std::uint32_t output_scale = 0x101060f8u;

// Level detector state.
inline constexpr std::uint32_t detector_input = 0x100d6360u;
inline constexpr std::uint32_t detector_output = 0x100d5ec8u;
inline constexpr std::uint32_t detector_smoothing = 0x100d5f28u;
inline constexpr std::uint32_t detector_terminal = 0x100d63b8u;
} // namespace address

static_assert(kCompatibilityVirtualBytes == 1064960u);
static_assert(kPhysicalBytes == 643072u);
static_assert(kConstantsBytes == 20480u);
static_assert(kRuntimeBytes == 581632u);
static_assert(kConfigurationBytes == 40960u);
static_assert(kVirtualPageCount == 260u);

} // namespace ssnative::detail::named_state
