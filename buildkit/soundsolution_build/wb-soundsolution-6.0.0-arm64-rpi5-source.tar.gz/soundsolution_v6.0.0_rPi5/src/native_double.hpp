#pragma once

// The 2.x branch keeps the historical NativeDouble symbol name only to minimize churn
// in the reconstructed DSP translation.  Its value is native IEEE-754 binary64;
// no x87 extended-precision or software binary80 implementation is present.

#include <bit>
#include <cmath>
#include <cstdint>

#if defined(__GNUC__) || defined(__clang__)
#  define SSNATIVE_DOUBLE_ALWAYS_INLINE inline __attribute__((always_inline))
#else
#  define SSNATIVE_DOUBLE_ALWAYS_INLINE inline
#endif

namespace ssnative::detail {

using NativeDouble = double;

[[nodiscard]] SSNATIVE_DOUBLE_ALWAYS_INLINE NativeDouble
native_double_from_binary64_bits(const std::uint64_t bits) noexcept {
    return std::bit_cast<double>(bits);
}

[[nodiscard]] SSNATIVE_DOUBLE_ALWAYS_INLINE std::uint64_t
native_double_round_to_binary64_bits(const NativeDouble value, NativeDouble& rounded) noexcept {
    const std::uint64_t bits = std::bit_cast<std::uint64_t>(value);
    rounded = value;
    return bits;
}

[[nodiscard]] SSNATIVE_DOUBLE_ALWAYS_INLINE std::uint64_t
native_double_to_binary64_bits(const NativeDouble value) noexcept {
    return std::bit_cast<std::uint64_t>(value);
}

[[nodiscard]] SSNATIVE_DOUBLE_ALWAYS_INLINE bool
native_double_isnan(const NativeDouble value) noexcept {
    return std::isnan(value);
}

[[nodiscard]] SSNATIVE_DOUBLE_ALWAYS_INLINE NativeDouble
native_double_abs(const NativeDouble value) noexcept {
    return std::fabs(value);
}

[[nodiscard]] SSNATIVE_DOUBLE_ALWAYS_INLINE NativeDouble
native_double_sqrt(const NativeDouble value) noexcept {
    return std::sqrt(value);
}

[[nodiscard]] inline NativeDouble native_double_cos(const NativeDouble value) noexcept {
    return std::cos(value);
}

[[nodiscard]] inline NativeDouble native_double_tan(const NativeDouble value) noexcept {
    return std::tan(value);
}

[[nodiscard]] SSNATIVE_DOUBLE_ALWAYS_INLINE std::int64_t
native_double_trunc_to_i64(const NativeDouble value) noexcept {
    return static_cast<std::int64_t>(std::trunc(value));
}

struct NativeDoublePair final {
    NativeDouble first{};
    NativeDouble second{};
};

[[nodiscard]] SSNATIVE_DOUBLE_ALWAYS_INLINE NativeDoublePair
native_double_pair_add(const NativeDoublePair& a, const NativeDoublePair& b) noexcept {
    return {a.first + b.first, a.second + b.second};
}

[[nodiscard]] SSNATIVE_DOUBLE_ALWAYS_INLINE NativeDoublePair
native_double_pair_sub(const NativeDoublePair& a, const NativeDoublePair& b) noexcept {
    return {a.first - b.first, a.second - b.second};
}

[[nodiscard]] SSNATIVE_DOUBLE_ALWAYS_INLINE NativeDoublePair
native_double_pair_mul(const NativeDoublePair& a, const NativeDoublePair& b) noexcept {
    return {a.first * b.first, a.second * b.second};
}

[[nodiscard]] SSNATIVE_DOUBLE_ALWAYS_INLINE NativeDoublePair
native_double_pair_mul_right(const NativeDoublePair& a, const NativeDouble b) noexcept {
    return {a.first * b, a.second * b};
}

[[nodiscard]] SSNATIVE_DOUBLE_ALWAYS_INLINE NativeDoublePair
native_double_pair_mul_left(const NativeDouble a, const NativeDoublePair& b) noexcept {
    return {a * b.first, a * b.second};
}

template <bool Subtract>
[[nodiscard]] SSNATIVE_DOUBLE_ALWAYS_INLINE NativeDoublePair
native_double_pair_mul_acc_right(const NativeDoublePair& accumulator,
                       const NativeDoublePair& value,
                       const NativeDouble coefficient) noexcept {
    const NativeDoublePair term = native_double_pair_mul_right(value, coefficient);
    if constexpr (Subtract) {
        return native_double_pair_sub(accumulator, term);
    }
    return native_double_pair_add(accumulator, term);
}

template <bool Subtract>
[[nodiscard]] SSNATIVE_DOUBLE_ALWAYS_INLINE NativeDoublePair
native_double_pair_mul_acc_left(const NativeDoublePair& accumulator,
                      const NativeDouble coefficient,
                      const NativeDoublePair& value) noexcept {
    return native_double_pair_mul_acc_right<Subtract>(accumulator, value, coefficient);
}

} // namespace ssnative::detail

#undef SSNATIVE_DOUBLE_ALWAYS_INLINE
