#include "ssnative/ssnative.h"

#include "ssnative/dat.hpp"
#include "ssnative/dsp.hpp"

#include "named_state_layout.hpp"
#include "native_process_layout.hpp"
#include "named_state_engine.hpp"

#include <exception>
#include <filesystem>
#include <memory>
#include <new>
#include <span>
#include <string>

struct ssnative_dsp {
    ssnative::Dsp impl;
    std::string last_error;
};

namespace {

void clear_error(ssnative_dsp* dsp) {
    if (dsp != nullptr) {
        dsp->last_error.clear();
    }
}

ssnative_status fail(ssnative_dsp* dsp,
                     const ssnative_status status,
                     const char* message) {
    if (dsp != nullptr) {
        dsp->last_error = message != nullptr ? message : "unknown error";
    }
    return status;
}

} // namespace

extern "C" {

const char* ssnative_version(void) {
    return "6.0.0";
}

const char* ssnative_arithmetic_mode(void) {
    return "native-double";
}

const char* ssnative_state_layout(void) {
    return "named-state-v14/structured-process-flow";
}

const char* ssnative_control_layout(void) {
    return "structured-process-v1/typed-state-loop";
}

size_t ssnative_state_active_bytes(void) {
    return ssnative::detail::named_state::kPhysicalBytes;
}

size_t ssnative_state_virtual_bytes(void) {
    return ssnative::detail::named_state::kCompatibilityVirtualBytes;
}

size_t ssnative_control_stack_virtual_bytes(void) {
    return 0u;
}

size_t ssnative_control_stack_physical_bytes(void) {
    return ssnative::detail::native_process::kProcessFrameBytes;
}

size_t ssnative_cold_control_stack_physical_bytes(void) {
    return ssnative::detail::native_process::kColdStackPhysicalBytes;
}

size_t ssnative_configure_control_stack_physical_bytes(void) {
    return ssnative::detail::native_process::kConfigureStackPhysicalBytes;
}

size_t ssnative_postload_control_stack_physical_bytes(void) {
    return ssnative::detail::native_process::kPostloadStackPhysicalBytes;
}

size_t ssnative_control_continuation_capacity(void) {
    return ssnative::detail::native_process::kContinuationCapacity;
}

size_t ssnative_control_executor_bytes(void) {
    return ssnative::detail::native_process_executor_bytes();
}

size_t ssnative_hot_control_cache_bytes(void) {
    return ssnative::detail::hot_control_cache_bytes();
}

size_t ssnative_control_domain_count(void) {
    return ssnative::detail::native_process::kControlDomainCount;
}

size_t ssnative_control_continuation_state_bytes(void) {
    return ssnative::detail::continuation_state_bytes();
}

size_t ssnative_persistent_continuation_bytes(void) {
    return ssnative::detail::persistent_continuation_bytes();
}

size_t ssnative_configure_continuation_state_bytes(void) {
    return ssnative::detail::native_process::kConfigureContinuationStateBytes;
}

size_t ssnative_postload_continuation_state_bytes(void) {
    return ssnative::detail::native_process::kPostloadContinuationStateBytes;
}

size_t ssnative_native_configure_function_count(void) {
    return ssnative::detail::native_process::kNativeConfigureFunctionCount;
}

size_t ssnative_native_configure_static_operation_count(void) {
    return ssnative::detail::native_process::kNativeConfigureStaticOperationCount;
}

size_t ssnative_native_postload_function_count(void) {
    return ssnative::detail::native_process::kNativePostloadFunctionCount;
}

size_t ssnative_native_postload_direct_call_count(void) {
    return ssnative::detail::native_process::kNativePostloadDirectCallCount;
}

size_t ssnative_native_postload_static_operation_count(void) {
    return ssnative::detail::native_process::kNativePostloadStaticOperationCount;
}

size_t ssnative_process_program_instruction_count(void) {
    return ssnative::detail::native_process::kProcessProgramInstructionCount;
}

size_t ssnative_process_frame_bytes(void) {
    return ssnative::detail::native_process::kProcessFrameBytes;
}

size_t ssnative_direct_process_body_count(void) {
    return ssnative::detail::native_process::kDirectProcessBodyCount;
}

size_t ssnative_structured_process_stage_count(void) {
    return ssnative::detail::native_process::kStructuredProcessStageCount;
}

size_t ssnative_persistent_process_workspace_bytes(void) {
    return 0u;
}

ssnative_dsp* ssnative_create(void) {
    try {
        return new ssnative_dsp{};
    } catch (...) {
        return nullptr;
    }
}

void ssnative_destroy(ssnative_dsp* dsp) {
    delete dsp;
}

ssnative_status ssnative_load_dat(ssnative_dsp* dsp, const char* filename) {
    if (dsp == nullptr || filename == nullptr || filename[0] == '\0') {
        return fail(dsp, SSNATIVE_STATUS_INVALID_ARGUMENT,
                    "dsp and filename are required");
    }
    try {
        const auto config = ssnative::DatFile::load(std::filesystem::path(filename));
        dsp->impl.load_config(config);
        clear_error(dsp);
        return SSNATIVE_STATUS_OK;
    } catch (const std::bad_alloc&) {
        return fail(dsp, SSNATIVE_STATUS_OUT_OF_MEMORY, "out of memory");
    } catch (const std::exception& error) {
        const std::string what = error.what();
        dsp->last_error = what;
        if (what.find("DAT") != std::string::npos ||
            what.find("signature") != std::string::npos ||
            what.find("version") != std::string::npos) {
            return SSNATIVE_STATUS_INVALID_DAT;
        }
        return SSNATIVE_STATUS_IO_ERROR;
    } catch (...) {
        return fail(dsp, SSNATIVE_STATUS_INTERNAL_ERROR, "unknown load error");
    }
}

ssnative_status ssnative_reset(ssnative_dsp* dsp) {
    if (dsp == nullptr) {
        return SSNATIVE_STATUS_INVALID_ARGUMENT;
    }
    dsp->impl.reset();
    clear_error(dsp);
    return SSNATIVE_STATUS_OK;
}

ssnative_status ssnative_process_s16_interleaved(
    ssnative_dsp* dsp,
    int16_t* samples,
    const size_t frames,
    const uint32_t channels,
    const uint32_t sample_rate) {
    if (dsp == nullptr || (samples == nullptr && frames != 0U) || channels == 0U) {
        return fail(dsp, SSNATIVE_STATUS_INVALID_ARGUMENT,
                    "invalid DSP handle or sample buffer");
    }
    if (frames > (static_cast<size_t>(-1) / channels)) {
        return fail(dsp, SSNATIVE_STATUS_INVALID_ARGUMENT,
                    "audio frame count overflows address space");
    }

    const auto sample_count = frames * channels;
    const auto result = dsp->impl.process_s16_interleaved(
        std::span<std::int16_t>(samples, sample_count), channels, sample_rate);
    switch (result) {
    case ssnative::ProcessStatus::ok:
        clear_error(dsp);
        return SSNATIVE_STATUS_OK;
    case ssnative::ProcessStatus::invalid_format:
        return fail(dsp, SSNATIVE_STATUS_INVALID_AUDIO_FORMAT,
                    "expected mono/stereo signed 16-bit PCM at >= 44100 Hz");
    case ssnative::ProcessStatus::internal_error:
        dsp->last_error = dsp->impl.last_error();
        return SSNATIVE_STATUS_INTERNAL_ERROR;
    }
    return fail(dsp, SSNATIVE_STATUS_INTERNAL_ERROR, "unknown process status");
}

const char* ssnative_last_error(const ssnative_dsp* dsp) {
    return dsp != nullptr ? dsp->last_error.c_str() : "invalid DSP handle";
}

const char* ssnative_status_string(const ssnative_status status) {
    switch (status) {
    case SSNATIVE_STATUS_OK: return "ok";
    case SSNATIVE_STATUS_INVALID_ARGUMENT: return "invalid argument";
    case SSNATIVE_STATUS_INVALID_DAT: return "invalid DAT";
    case SSNATIVE_STATUS_IO_ERROR: return "I/O error";
    case SSNATIVE_STATUS_INVALID_AUDIO_FORMAT: return "invalid audio format";
    case SSNATIVE_STATUS_CORE_NOT_YET_PORTED: return "reserved legacy status";
    case SSNATIVE_STATUS_OUT_OF_MEMORY: return "out of memory";
    case SSNATIVE_STATUS_INTERNAL_ERROR: return "internal error";
    }
    return "unknown status";
}

} // extern "C"
