#!/usr/bin/env python3
"""Inventory direct callees of the original ModifySamples implementation."""
from __future__ import annotations

import argparse
import collections
import re
from pathlib import Path

PROCESS_START = 0x100025D0
PROCESS_END = 0x1000392B

STUB_TARGETS = {
    0x10001055: 0x10007B90,
    0x1000105F: 0x10008D00,
    0x10001064: 0x10008AC0,
    0x1000106E: 0x10007FE0,
    0x10001073: 0x100095C0,
    0x10001078: 0x10009070,
    0x10001082: 0x100089F0,
    0x1000109B: 0x10008BD0,
    0x100010B4: 0x10008B60,
    0x100010B9: 0x10008FF0,
}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("disassembly", type=Path)
    args = parser.parse_args()

    call_re = re.compile(r"^([0-9a-fA-F]{8}):.*\bcall\s+0x([0-9a-fA-F]+)")
    counts: collections.Counter[int] = collections.Counter()
    sites: collections.defaultdict[int, list[int]] = collections.defaultdict(list)
    for line in args.disassembly.read_text(errors="replace").splitlines():
        match = call_re.match(line)
        if not match:
            continue
        site = int(match.group(1), 16)
        target = int(match.group(2), 16)
        if PROCESS_START <= site < PROCESS_END:
            target = STUB_TARGETS.get(target, target)
            counts[target] += 1
            sites[target].append(site)

    print("ModifySamples direct-call inventory")
    print(f"range: 0x{PROCESS_START:08X}-0x{PROCESS_END:08X}")
    for target, count in sorted(counts.items()):
        positions = ", ".join(f"0x{x:08X}" for x in sites[target])
        print(f"0x{target:08X}  calls={count:2d}  sites={positions}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
