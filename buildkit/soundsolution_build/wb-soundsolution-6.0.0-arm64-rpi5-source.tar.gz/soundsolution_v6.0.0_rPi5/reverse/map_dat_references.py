#!/usr/bin/env python3
"""List absolute references to DAT-backed memory in an objdump listing."""
from __future__ import annotations

import argparse
import collections
import re
from pathlib import Path

COMMON_BASE = 0x10106040
COMMON_END = COMMON_BASE + 0x3F8
PROCESS_BASE = 0x1010A860
PROCESS_END = PROCESS_BASE + 21 * 0x33C


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("disassembly", type=Path)
    args = parser.parse_args()

    references: collections.Counter[tuple[str, int]] = collections.Counter()
    for line in args.disassembly.read_text(errors="replace").splitlines():
        for text in re.findall(r"0x([0-9a-fA-F]{8})", line):
            address = int(text, 16)
            if COMMON_BASE <= address < COMMON_END:
                references[("common", address - COMMON_BASE)] += 1
            elif PROCESS_BASE <= address < PROCESS_END:
                references[("process", address - PROCESS_BASE)] += 1

    for (kind, offset), count in sorted(references.items()):
        print(f"{kind:7s} +0x{offset:04X}  refs={count}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
