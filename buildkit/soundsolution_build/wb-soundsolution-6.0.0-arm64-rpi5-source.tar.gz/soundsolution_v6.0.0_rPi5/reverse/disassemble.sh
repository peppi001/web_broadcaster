#!/usr/bin/env bash
set -euo pipefail
if [[ $# -ne 2 ]]; then
    echo "usage: $0 dsp.dll output.txt" >&2
    exit 2
fi
objdump -d -Mintel "$1" > "$2"
