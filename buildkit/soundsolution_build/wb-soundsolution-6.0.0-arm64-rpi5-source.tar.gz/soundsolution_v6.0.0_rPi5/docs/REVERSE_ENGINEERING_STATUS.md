# Reverse-engineering status

## Working in version 0.2

- PE32/x86 DSP entry point and complete `ModifySamples` call graph mapped.
- Windows GUI and profile calls excluded from the Linux runtime.
- Exact `.dat` read/write layout implemented and byte-exact round-trip tested.
- Configuration finalization, coefficient calculation, reset and audio
  processing execute through a generated native C++ translation layer.
- 2,494 reachable x86/x87 instructions are represented.
- In-place mono/stereo signed-16 PCM processing is active through the public C
  ABI.
- Deterministic PCM regression hash and reset-state regression are tested.

## Architecture

The first working core retains original virtual addresses in a private Linux
memory image. Integer and x87 operations are translated into C++ operations,
with direct threaded control flow generated at build-development time. The
runtime does not load or execute a PE DLL and does not call Windows APIs.

This structure is a migration layer, not the desired final source style. The
remaining engineering work is semantic cleanup: replace address-based state
access with named C++ structures and replace generated instruction sequences
with maintainable DSP functions while keeping the regression output stable.

## Dormant evaluation timer

The supplied DLL still contains the original four-minute/four-second timer
instructions, but its audio-muting block is unreachable because the supplied
binary jumps over it unconditionally. Version 0.4.1 removes this dead timer from
the runtime control flow while retaining the disassembled instruction records
for provenance. The observable PCM path and frame-count return value are kept
unchanged.
