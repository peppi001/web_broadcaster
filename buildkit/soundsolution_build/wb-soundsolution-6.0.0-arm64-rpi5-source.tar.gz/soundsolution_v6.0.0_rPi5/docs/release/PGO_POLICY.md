# PGO policy

A profil mindig az aktuális checkoutban készül. Régi `.gcda` fájl nem
használható. Az instrumentált és a végleges build konfigurációja azonos, csak a
PGO mód változik `generate` értékről `use` értékre.
