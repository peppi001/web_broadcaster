# Git release

Javasolt tag: `soundsolution-native-v6.0.0`.

Javasolt source archive: `soundsolution_v6.0.0_rPi5-structured-process-flow.tar.gz`.
