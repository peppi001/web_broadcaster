# SoundSolution 2.7.0 hot-cache isolation

## Cél

A 2.6.0 cold executor már csak konfigurációbetöltéskor létezett, de a közös
executor osztály objektumában továbbra is benne volt a process hot path két
előkonvertált `double` cache-e. A cold út ezeket nem használta.

## Változás

A cache-ek külön `HotControlCaches` objektumba kerültek:

- immutable constants: 1024 × 8 = 8192 bájt;
- filter constants: 64 × 8 = 512 bájt;
- összesen: 8704 bájt.

A tartós process executor pointerrel kapja meg ezt az állapotot. A configure és
postload ideiglenes executor null cache-pointerrel működik, és csak a statikus
control fordításhoz szükséges regiszter-, FPU-, continuation- és stackállapotot
tartalmazza.

## Stabilitási határ

A három statikusan fordított control egység továbbra is megmarad:

- `native_control_process.inc`;
- `native_control_configure.inc`;
- `native_control_postload.inc`.

A 2.7.0 nem változtatja meg az instrukciósorrendet vagy a DSP matematikáját.
A következő ágban a cold fragmentumok magas szintű átírása már kisebb,
process-only állapottól független executor környezetből indulhat.

## Build-validáció

A PGO és regressziós korpuszokat natív C generátor állítja elő. A régi Python
generátorok referenciaimplementációként megmaradtak; a 3 másodperces normál és
a 30 másodperces stressz bytefolyamot `cmp` kapuval egyeztettük.
