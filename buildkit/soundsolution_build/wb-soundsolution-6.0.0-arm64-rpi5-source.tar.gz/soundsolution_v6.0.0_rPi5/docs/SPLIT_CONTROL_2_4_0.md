# Split-control C2 — SoundSolution 2.4.0

A 2.3.0 már runtime interpreter nélkül futott, de a három statikus control egység
közös `ControlFrame` struktúrát használt. A 2.4.0 ezt a struktúrát megszünteti.

## Új felosztás

- `IntegerControlState`: EAX–EBP és az integer flag-ek.
- `FloatingControlState`: natív double stack, státusz, top és depth.
- `ReturnSite`: a 36 igazolt visszatérési pont típusos felsorolása.
- Fizikai kontroll-stack: 2048 bájt.
- Virtuális kontroll-stack ablak: 4096 bájt, a történeti címek megőrzésével.

A postload mért legmélyebb stackhasználata 1400 bájt, a configure 356 bájt, a
process 480 bájt. A 2048 bájtos fizikai felső ablak ezért tartalékkal lefedi az
összes igazolt utat.

## Stabilitási szabály

A virtuális stackcímek nem változtak. Csak a fizikai backing kezdőcíme tolódott
az igazolt felső 2 KiB-ra. A statikus stack fast-path-ok ugyanezt a fizikai
bázist használják.

## Nem állítjuk

A 2.4.0 még nem teljes magas szintű control-átírás. A három generált include
megmaradt, és továbbra is statikusan fordított x86-szerű regiszter- és
stackműveleteket tartalmaz.
