# Native-call control C3 — SoundSolution 2.5.0

## Cél

A 2.4.0 már típusos folytatási pontokat használt, de a lefordított `CALL`
utasítások a numerikus visszatérési címet továbbra is a virtuális x86 stackbe
írták, a `RET` pedig onnan `pop32()`-vel olvasta vissza.

A 2.5.0 ezt a kapcsolatot megszünteti.

## Megoldás

- `NativeContinuation`: 36 igazolt belső folytatási pont és az `Exit` érték.
- `continuation_stack_`: 8 elemű, fix méretű, heap nélküli C++ tömb.
- `enter_native_call()`: négy bájttal módosítja a virtuális ESP-t az eredeti
  argumentumelrendezés megtartásához, de a folytatást a natív tömbbe írja.
- `leave_native_call()`: visszaállítja az ESP-t és a natív tömbből veszi a
  folytatást.

Így a DSP matematikája és a lokális stackcímek nem változnak, miközben a guest
memóriában nincs programcím.

## Méretek

- virtuális kontroll-stack: 4096 bájt;
- fizikai kontroll-stack: 1536 bájt;
- continuation-kapacitás: 8;
- lefordított call-site: 37;
- lefordított return-path: 15.

## Határ

A `process`, `configure` és `postload` továbbra is statikus, fordítási időben
rögzített vezérlési forrás. A 2.5.0 nem magas szintű algoritmus-újraírás, hanem
a natív hívás/visszatérés stabil, bitazonos lépcsője.
