# Process-only control milestone — 4.0.0

A 4.0.0 után az örökölt vezérlési modell határa egyértelmű:

| Tartomány | Megvalósítás |
|---|---|
| configure | közvetlen, stack nélküli C++ |
| postload | közvetlen, stack nélküli C++ |
| reset | közvetlen named-state C++ |
| process | statikusan fordított hot path, típusos híváslokális continuation |

A cold/control oldalon nincs `Instruction`, `Operand`, virtuális regiszter, flag, FPU-stack, fizikai kontroll-stack vagy compile-time statikus művelet. A process programtábla 1031 ténylegesen használt utasítást tartalmaz.
