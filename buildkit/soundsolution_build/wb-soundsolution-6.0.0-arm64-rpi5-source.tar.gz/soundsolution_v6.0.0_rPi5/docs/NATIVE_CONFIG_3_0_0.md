# SoundSolution 3.0.0 native configure call graph

## Eltávolítva

- `src/native_control_configure.inc`
- `ConfigureContinuation`
- `NativeContinuationState<ConfigureContinuation>`
- configure return-dispatch switch
- configure guest-stack visszatérési állapot

## Új közvetlen call graph

A configure nyolc C++ függvényből áll:

1. `execute_native_configure`
2. `configure_square_to_i32`
3. `configure_rate_power`
4. `configure_time_coefficient`
5. `configure_scaled_pow_a`
6. `configure_scaled_pow_b`
7. `configure_filter_coefficients`
8. `configure_gain_pair`

A hívások továbbra is lefoglalják az eredeti x86 CALL négybájtos virtuális
stackhelyét, mert a még statikusan fordított lokális címek erre épülnek. A
visszatérés azonban normál C++ visszatérés, nem continuation-dispatch.

## Pontos állapot

- configure continuation state: 0 bájt
- configure fizikai stack: 384 bájt
- configure mért high-water: 352 bájt
- configure natív függvények: 8
- configure közvetlen hívások: 22
- megmaradt compile-time statikus műveletek: 289
- runtime instruction interpreter: nincs
- PCM eltérés a 2.9.0-hoz képest: 0
