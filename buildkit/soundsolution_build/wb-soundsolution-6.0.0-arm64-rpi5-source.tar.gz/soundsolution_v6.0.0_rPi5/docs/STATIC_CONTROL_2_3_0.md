# Static-control C1 — SoundSolution 2.3.0

## Cél

A maradék örökölt vezérlési réteg csökkentése a Raspberry Pi 5 stabilitásának,
PCM-kimenetének és teljesítményének változtatása nélkül.

## Eltávolított runtime elemek

- általános `fetch()` instruction lookup;
- dinamikus `execute_op()` interpreter;
- dinamikus `Operand` olvasó/író út;
- belépési cím alapján kapcsoló `run_function()` dispatcher;
- `direct_control_reset.inc` virtuális reset-program.

## Aktív control út

Három statikusan fordított egység maradt:

- `direct_control_process.inc`;
- `direct_control_configure.inc`;
- `direct_control_postload.inc`.

Ezek fordítási időben rögzített instruction metaadatokat használnak. Nincs
futásidejű instruction fetch vagy opcode dispatcher.

## Közvetlen reset

A reset három név szerinti tartományt nulláz:

- dynamics A: 2040 byte;
- dynamics B: 3560 byte;
- delay state: 1024 byte.

A reset nem állít fel control frame-et és nem használ virtuális stacket.

## Audit

A `tools/audit_static_control.py` kötelezően ellenőrzi, hogy:

- a runtime interpreter szimbólumai hiányoznak;
- a belépési cím dispatcher hiányzik;
- a virtuális reset include hiányzik;
- a három direct reset tartomány jelen van;
- csak a process/configure/postload static-control egységek maradtak.

## Elfogadási kapu

- CTest 3/3;
- warningmentes Release build;
- reset utáni bitazonosság;
- 8 blokkméreten bitazonos PCM;
- 30 másodperces normál és stressz hash;
- 270 másodperces referencia hash;
- nincs fejlesztői teljesítményregresszió.
