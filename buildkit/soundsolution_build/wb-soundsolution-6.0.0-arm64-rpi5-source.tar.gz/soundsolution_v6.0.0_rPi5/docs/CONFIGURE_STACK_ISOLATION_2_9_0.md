# SoundSolution 2.9.0 configure-stack isolation

## Cél

A 2.8.0-ban a process, configure és postload continuation tartomány már külön
típus volt, de a configure és a postload ugyanazt az 1536 bájtos fizikai cold
stacket használta. A statikus audit szerint a configure maximális tényleges
stackhasználata 352 bájt, a postloadé 1396 bájt.

## Megoldás

A 2.9.0 három külön fizikai backing méretet rögzít:

| Tartomány | Fizikai stack | Auditált maximum |
|---|---:|---:|
| process | 512 bájt | 480 bájt |
| configure | 384 bájt | 352 bájt |
| postload | 1536 bájt | 1396 bájt |

A virtuális x86 stackablak továbbra is 4096 bájt, ezért a statikusan lefordított
lokális címek változatlanok. Csak a mögöttes, ténylegesen nullázott tároló lett
külön méretezve.

## Stabilitási határ

A configure műveleti sorrendje, lebegőpontos számításai, continuation pontjai és
állapotcímei nem változtak. A kiadás kötelező kapuja a 2.8.0 native-double PCM
bitazonossága minden blokkméretnél, a normál, stressz- és hosszú korpuszon.

A `ssnative_cold_control_stack_physical_bytes()` ABI-kompatibilitásból továbbra
is a legnagyobb cold stack méretét, 1536 bájtot adja vissza. Két új additív API
jelenti a tartományonkénti értékeket.
