# v0.6.3 ARM64 exact NEON stereo milestone

This milestone keeps the deterministic software binary80 backend and adds an
AArch64-only two-lane multiplication primitive for independent stereo paths.
The 64-bit significands are split into 32-bit limbs and multiplied with NEON
`UMULL/UMLAL`; lane results are then rounded independently with the same
round-to-nearest-even code as scalar `NativeDouble::mul`.

Paired kernels cover the production filter bank, biquad, one-pole and
fourth-order stereo filters. Every original binary64 store remains in the same
place. Non-AArch64 builds retain the scalar path, while
`SSNATIVE_FORCE_X87_PAIR_KERNELS=ON` allows semantic regression testing on
amd64.

The binary80 square root uses an FP64 hardware estimate followed by one exact
128/64 Newton correction and integer proof/correction. FP64 is only a hint; the
returned integer floor root is proven by integer multiplication comparisons.

Raspberry builds include a million-case NEON-vs-scalar pair multiplication test
and retain the 3/30/270-second reference hashes. The default acceptance gate is
50.0 percent single-core real-time load on the 30-second benchmark.
