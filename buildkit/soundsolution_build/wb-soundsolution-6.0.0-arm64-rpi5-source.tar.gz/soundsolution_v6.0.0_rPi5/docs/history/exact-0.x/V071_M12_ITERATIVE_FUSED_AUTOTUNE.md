# v0.7.1 M12: corrected exact fused filters and iterative Pi 5 autotune

## Starting point

The fully bit-exact v0.7.0/M11 target run measured 16.02 CPU seconds for the
30-second corpus (53.4% of one Cortex-A76 core) and 144.16 CPU seconds for the
270-second continuous-state corpus (53.4%).  The remaining gap to the hard
50.0% gate is 1.02 CPU seconds per 30 seconds, or about 6.4% relative.

The selected M11 layout enabled only the joint stereo binary64 load.  The Pi
profile still attributed about 27.6% to exact binary80 addition, 18.8% to the
shared-coefficient pair multiplier, 10.8% to scalar multiplication and 13.8%
to the remaining process dispatcher.  The L1 instruction-cache miss ratio was
also material, so M12 treats arithmetic and code layout together.

## Corrected fused stereo arithmetic

M12 introduces a narrow exact `multiply -> round-to-binary80 -> add/sub` pair
kernel for the translated stereo filters.  It is not an FMA: each product is
rounded to the original binary80 precision before the following addition.

An earlier fused experiment discarded these already-rounded products whenever
the add exponent distance exceeded three and recomputed both multiplications
through the generic fallback.  M12 reuses the rounded products on that path.
The dominant distance-0..3 path uses the compact exact add kernel, while every
wide-distance or special IEEE case falls back to the established exact code.
A second candidate directly packs in-range rounded products without entering
the general overflow/subnormal pack dispatcher.

## Other exact candidates

The target matrix also measures:

- one shared dynamics body instead of duplicated low/high functions;
- direct in-range scalar and shared-coefficient pair multiply paths;
- alternate add hot paths and pair-add ABI;
- compact/dead-flag/size-oriented process-dispatch layouts;
- 256- and 1024-entry bit-identical `std::pow` result caches;
- paired binary80 stores;
- IPA clone suppression;
- GCC O2/O3;
- function/loop alignment tuned for dense code or Cortex-A76 fetch width;
- block reordering/partitioning alternatives;
- GCC scheduling and register-pressure flags.

No candidate is accepted without the fixed PCM SHA-256.

## Iterative target search

`start-v071-rpi5.sh` runs up to seven measurement rounds:

1. three-repeat non-PGO screening of every structural candidate;
2. five-repeat PGO30 measurement of every candidate;
3. three-repeat 30-second confirmation of the six PGO30 leaders;
4. PGO90 retraining and 30-second confirmation of the four leaders;
5. mixed normal/stress/block-size PGO cross-check of the two leaders;
6. when the best confirmed result is still above 49.8%, adaptive single- and
   paired compiler/layout mutations around that exact winning specification;
7. mixed-corpus retraining of the final two adaptive leaders.

Selection is based on median CPU time from complete 30-second runs, not on one
short sample.  The selected configuration is independently rebuilt and PGO-
trained again, then measured by three new 30-second runs.

## Mandatory release gates

The final build must pass:

- all six unit/differential tests;
- 3-second processing at block sizes 1, 7, 64, 255, 256, 1024, 2048 and 4096;
- three independent 30-second reference runs;
- the 270-second continuous-state reference;
- the 30-second impulse/DC/ramp stress corpus;
- no more than 50.0% median single-core CPU load.

If the performance gate fails, the final binary and complete profile remain
available for diagnosis, but no accepted runtime archive is created.
