# v0.7.2 M13 native-block and instruction-cache autotune

## Starting point

The Raspberry Pi 5 v0.7.1/M12 selected build is fully bit-exact at a median
15.870 CPU seconds for 30 seconds of stereo PCM, or 52.90% of one core.  The
270-second stateful reference measured 52.85%.  The remaining target gap is
0.870 CPU seconds per 30 seconds, approximately 5.48% relative.

The selected M12 configuration did not use the experimental fused filters.
Profiling still placed most execution time in exact binary80 add/multiply and
in the approximately 84 KiB generated `Machine::execute_process` body.  Pi 5
instruction-cache misses were high enough that reducing the live translated VM
body became an explicit M13 goal.

## Exact native VM blocks

M13 can remove five per-sample legacy ranges at compile time and replace them
with small exact C++ kernels:

* prefilter call setup and two stereo one-pole calls;
* dual state update and output mix;
* five-band recombination, two biquads and high-band dynamics setup;
* delay interpolation, history rotation and output peak update;
* four fourth-order stereo filters, optional soft clipping, output summation
  and the two peak/difference meters.

The native functions preserve the original binary80 operation order, all
explicit binary64 stores, raw QWORD history copies, emulated stack scratch
values, x87 comparison status and integer-register/flag effects observed by the
following translated code.  Every exceptional or configuration-dependent path
that is not proven equivalent remains in the established implementation.

The strongest local layout reduced the hot `execute_process` symbol from about
84 KiB to about 53 KiB.  Local x86 timings are only screening data; selection
is performed on the Raspberry Pi 5.

## Arithmetic and layout candidates

The target builder also tests:

* the corrected wide-normal fused fallback, which reuses already-rounded
  binary80 products instead of reclassifying them through the public add path;
* outlined filter-bank, biquad, one-pole and fourth-order stages;
* Cortex-A76 code-layout and scheduling variants;
* process-VM size optimization and IPA-clone control;
* combinations of the exact native blocks and the proven v0.7.1 baseline.

## Target autotune

`start-v072-rpi5.sh` runs a 32-candidate structural screen.  Every candidate is
hash-gated before it can continue.  All exact candidates receive PGO30 builds;
the strongest repeated 30-second results are retrained with PGO90 and a mixed
normal/stress corpus.  If the 49.7% preferred target is not reached, an adaptive
search toggles individual native blocks, outlining, compiler layout and
scheduling around the best confirmed specification.

The v0.7.1/M12 specification is a mandatory finalist and remains available as a
fallback.  The final selected specification is rebuilt from scratch and must
pass:

* all eight block sizes: 1, 7, 64, 255, 256, 1024, 2048 and 4096 frames;
* three independent 30-second performance/hash runs;
* the 270-second continuous-state reference;
* the 30-second impulse/DC/ramp stress corpus;
* all unit and arithmetic differential tests;
* the hard maximum of 50.0% of one Pi 5 core.

No accepted runtime package is created above the hard gate.  A complete profile
archive is still produced for the next optimization round.
