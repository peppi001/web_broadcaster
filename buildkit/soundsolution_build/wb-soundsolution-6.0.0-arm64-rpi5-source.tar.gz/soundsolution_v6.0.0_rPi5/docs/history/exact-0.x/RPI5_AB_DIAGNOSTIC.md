# Raspberry Pi 5 exact-backend A/B diagnostic

This package is diagnostic, not a release. It measures six bit-exact variants to isolate the cost of:

- ARM64 64-bit normal addition;
- FP-estimated exact integer square root;
- stereo pair kernels;
- NEON 32-bit partial-product pair multiplication versus scalar AArch64 MUL/UMULH.

Run:

```bash
SSNATIVE_AB_SECONDS=30 ./tools/benchmark_rpi5_variants.sh
```

Every variant must produce the fixed reference PCM hash. Results are written to `_build/rpi5-abdiag/RESULTS.tsv`.
