# Bit-exact optimization policy — v0.4.0

The Wine/AppImage output is the behavioral authority. Performance changes are
accepted only when the raw interleaved s16le output has the same length and the
same bytes as the reference output.

## Accepted v0.4.0 changes

1. **Static x87 state specialization**
   A control-flow analysis proved that every one of the 2,494 reachable
   translated instruction addresses has one unambiguous x87 stack top and
   depth. The generated path therefore indexes the same 80-bit values directly
   instead of calculating the circular stack position at run time.

2. **Direct hot-helper calls**
   Already translated DSP helpers are invoked as normal non-inlined C++ member
   functions instead of simulating the legacy return-address dispatcher.
   Preventing aggressive inlining avoids instruction-cache growth.

3. **Specialized integer branches**
   Ninety-five adjacent `cmp`/`test` and conditional-jump pairs use compile-time
   operand widths and signedness. This removes generic flag materialization but
   preserves the original branch result.

4. **Direct multiband-state access**
   Known global addresses in the hottest dynamics routine bypass the general
   guest-memory region switch. Stored values and all explicit `double`
   roundings remain unchanged.

5. **CPU-level shared libraries**
   The Debian 12 package ships generic, x86-64-v2 and x86-64-v3 libraries using
   glibc-hwcaps selection. This changes code generation only; the strict
   floating-point rules are identical in every variant.

## Forbidden release options

- `-ffast-math`
- FMA contraction
- floating-point reassociation
- replacing an x87 extended intermediate with `float`
- unchecked SIMD transformations

## Required regression checks

- long deterministic stereo PCM: exact SHA-256 match;
- edge corpus containing silence, impulses, full-scale values, ramps and noise;
- block sizes 1, 7, 64, 255, 256, 1024, 2048 and 4096 frames;
- supplied `.dat` byte-for-byte round trip.
