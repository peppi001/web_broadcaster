# ARM64 performance experiments

These experiments guide later Raspberry optimization. They are not enabled in
the strict v0.6.0 milestone unless the arithmetic equivalence is established,
not merely observed on one corpus.

## Software-binary80 profile

A one-second development-host cycle profile attributed approximately:

- filter bank: 63.63%
- band delay/mix: 24.01%
- biquad: 9.77%
- smoothing: 1.55%
- clipping and remaining helpers: about 1%

The filter bank is therefore the primary ARM64 optimization target.

## Region-by-region binary64 experiments

Each candidate replaced software binary80 with hardware binary64 only inside
one direct C++ region and was compared with the native-x87 reference over the
270-second validation class.

- biquad-only binary64: zero observed mismatches
- dynamics-only binary64: zero observed mismatches
- delay/mix-only binary64: zero observed mismatches
- filter-bank-only binary64: mismatches observed; rejected
- all-double backend: two mismatching bytes; rejected

The delay/mix-only experiment produced the same 47,628,000-byte output and
SHA-256 `57ec5a6305ca3465fb1761786898806f6ef09f71f5140187441a4c694bf88f2e`.
It is not enabled because corpus equality does not prove equivalence for every
possible state and sample sequence.

## Accepted optimization in this milestone

The software-binary80 normalization originally shifted one bit per iteration
after near-cancellation. It now computes the leading bit directly and applies a
single shift-with-jam. This transformation preserves the exact rounding state
and passed the full 270-second comparison.

## Next safe optimization direction

1. Profile the strict backend on Pi 4 and Pi 5 with CPU frequency and thermal
   throttling recorded.
2. Optimize the exact filter-bank add/multiply primitives first.
3. Consider paired stereo operations that share exponent/normalization work.
4. Keep the strict backend as the oracle and reject every candidate on the
   first differing byte.
5. Do not enable a corpus-only binary64 shortcut in production without a
   stronger equivalence argument and AArch64 validation.
