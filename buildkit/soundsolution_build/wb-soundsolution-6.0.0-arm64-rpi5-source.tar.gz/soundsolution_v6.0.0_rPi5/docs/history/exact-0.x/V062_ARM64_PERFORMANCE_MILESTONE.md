# v0.6.2 ARM64 performance milestone

Version 0.6.2 removes another frame-level legacy-VM hotspot and adds target-local
profile-guided optimization for Raspberry Pi 4 and Raspberry Pi 5. The strict
software-binary80 arithmetic remains the behavioral authority on AArch64.

## Validated Pi 5 baseline

The preceding v0.6.1 runtime was validated on a Raspberry Pi 5 Model B Rev 1.1:

- 30-second corpus: 25.440 seconds, 1.179x real time, 84.8% of one core;
- 270-second corpus: 229.294 seconds, 1.178x real time, 84.9% of one core;
- all 47,628,000 continuous output bytes matched the amd64 native-x87 oracle;
- continuous output SHA-256:
  `7eafc62739b028cb2bd56acf85571b025667b2726b142a95d5dfac5fb779f329`.

## Direct detector translation

The helper at `0x10008D00` was previously executed as roughly forty generated
legacy instructions for each call. The top-level detector calls it once for
each of five bands per audio frame.

Version 0.6.2 translates both the helper and the surrounding five-band range
`0x10002E7A-0x10002F16` into direct C++ while preserving:

- the original x87 comparison rule: the first magnitude wins only when it is
  strictly greater; equality and unordered comparisons select the second;
- the exact square, coefficient blend and addition order;
- the non-popping binary64 detector-state store before `FSQRT`;
- the binary80 square root and final binary64 level store;
- the enabled and bypass detector branches;
- loop terminal register values needed by the remaining translated caller.

The five fixed detector coefficients are represented directly as their exact
binary80 fields in the software backend, avoiding repeated binary64-to-binary80
conversion without changing their values.

## Raspberry-local PGO

`tools/build_raspberry_pi.sh` enables GCC PGO by default:

1. build a Cortex-A72 or Cortex-A76 profile-generation library;
2. process a deterministic 30-second stereo corpus on the target Pi;
3. rebuild in the same build directory with `-fprofile-use` and
   `-fprofile-correction`;
4. reject the build if GCC reports missing, stale or mismatched profile data;
5. run all unit, block-size and optional long PCM checks on the final binary.

PGO changes branch layout, inlining and hot/cold code placement only. The build
still uses `-ffp-contract=off`, disables tree vectorization, and never enables
`fast-math`, reassociation or reduced precision.

PGO can be disabled for comparison:

```bash
SSNATIVE_ENABLE_PGO=0 ./tools/build_raspberry_pi.sh pi5
```

The training length can be overridden:

```bash
SSNATIVE_PGO_SECONDS=60 ./tools/build_raspberry_pi.sh pi5
```

## Development-host validation

The source was compared against the native amd64 x87 backend with the supplied
`ss18.dat`:

- block sizes 1, 7, 64, 255, 256, 1024, 2048 and 4096: zero differing bytes;
- 3-second SHA-256:
  `ea5c85b2ebb0100fa44585ec4f106a9cae8b61c16489ff358beddf6ac181d49a`;
- 30-second SHA-256:
  `a1a4768be678cc2bffe50828a2eb1de655d1125a9ebad063de07b1776dac3e12`;
- 270-second output: 47,628,000 bytes, zero differences;
- 270-second SHA-256:
  `7eafc62739b028cb2bd56acf85571b025667b2726b142a95d5dfac5fb779f329`.

Indicative development-host timings were 18.70 seconds without PGO and 17.54
seconds with PGO for the 30-second corpus. These are not Raspberry benchmarks;
a target Pi 4/Pi 5 build remains the performance acceptance test.
