# v0.5.0 bit-exact hot-loop optimization

## Replaced legacy range

The generated VM path from `0x10002F85` through `0x10003055` was replaced by
`Machine::fast_band_delay_mix()`.

For each audio frame this range previously executed:

- one circular delay-index update;
- interpolation of five band gains;
- five persistent blend-state updates;
- a five-iteration outer loop;
- a two-iteration channel loop inside every band;
- ten delayed-history updates;
- ten weighted output-state writes;
- virtual x86 register, flag, x87-stack and address-dispatch operations around
  each translated instruction.

The direct routine uses `long double` for x87-equivalent intermediates and
explicit `double` stores at the same points as the original code. The output
and persistent state remain bit-identical.

## Validation

- 30-second PCM: zero mismatching bytes versus v0.4.1 and Wine reference.
- edge corpus: zero mismatching bytes at 1, 7, 64, 255, 256, 1024, 2048 and
  4096 frame blocks.
- 270-second continuous PCM: zero mismatching bytes versus v0.4.1, including
  operation beyond the former dormant 240-second timer threshold.

Local development-machine measurements showed roughly 18-20 percent lower
elapsed time than v0.4.1 on the 30-second corpus. Target-system Wine comparison
must be measured with the supplied A/B script because CPU generation and host
load materially affect the result.
