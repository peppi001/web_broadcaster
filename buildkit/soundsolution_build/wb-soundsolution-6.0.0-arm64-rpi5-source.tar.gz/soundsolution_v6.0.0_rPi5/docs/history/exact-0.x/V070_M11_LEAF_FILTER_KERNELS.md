# v0.7.0 M11: exact leaf multiply and stereo conversion paths

The Raspberry Pi 5 v0.6.9 M10 run remained bit-exact and reduced the measured
30-second single-core load from 54.4% to 53.7%. The 270-second continuous run
measured 53.9%. Reaching the 50.0% acceptance limit therefore requires about
6.9% less processor time than the M10 result.

The M10 profile still concentrated most samples in exact software-binary80
arithmetic: `NativeDouble::add` was about 27%, shared-coefficient stereo multiplication
about 17%, scalar multiplication about 11%, and the remaining process VM about
14%. M11 preserves the proven M10 add configuration and focuses on structural
work around multiplication and stereo state conversion.

## Exact candidates

### Paired binary64 load

Two stereo binary64 values are classified together. When both are normal, their
sign/exponent metadata and 64-bit binary80 significands are formed directly.
Signed zero is also handled directly. Subnormal, infinity and NaN inputs fall
back independently to the existing strict converter. The autotune compares both
an always-inline form and an outlined form. The latter keeps the translated
filter bodies smaller and allows AArch64 call sites to share one exact converter.

### Paired binary64 store

Two binary80 stereo values use one outlined store helper. Each lane still calls
the exact original binary80-to-binary64 conversion and therefore retains all
rounding and special-value behavior. This candidate exists primarily to test
AArch64 call-site and instruction-cache layout.

### In-range normal scalar multiply leaf

For two normal operands whose result exponent is provably within the normal
binary80 range, a small outlined kernel performs only:

1. one exact 64x64-to-128 multiplication;
2. the original round-to-nearest-even product rounding;
3. direct sign/exponent/significand construction.

Overflow, underflow and subnormal results keep the original `pack_normal_fast`
and cold fallback path.

### In-range shared-coefficient pair multiply leaf

The stereo kernel applies the same proof to both lanes and reuses the common
coefficient. The two products retain independent binary80 rounding. A separate
candidate handles the production normal-coefficient case when either state lane
is an exact signed zero, without invoking two generic scalar multipliers.

### VM interaction candidates

The focused autotune also rechecks the compact process include and the proven
CFG-based dead-flag include in combination with the M11 arithmetic layout. They
remain optional and can be selected only by target-local median CPU time.

## Target autotune

`tools/build_raspberry_pi_m11.sh` starts from the exact v0.6.9 M10 winner:

- M10 significand add classifier enabled;
- complete add value ABI enabled;
- cold pack fallback enabled;
- packed add inlining enabled;
- scalar pair inlining disabled;
- exact 1024-entry pow cache enabled;
- optimization level O2 and autovectorization enabled.

Nineteen non-PGO M11 layouts are measured three times on the Pi 5. The proven
M10 baseline and the fastest eight M11 layouts are then rebuilt with target-
local GCC PGO and measured again. Every measurement must reproduce the fixed
10-second PCM SHA-256 before it is eligible for selection.

The selected build must pass the complete unit/differential suite, all eight
3-second block sizes, the 30-second reference, the 270-second continuous-state
reference and the impulse/DC/ramp stress corpus. A runtime package is emitted
only when the 30-second single-core load is at most 50.0%.
