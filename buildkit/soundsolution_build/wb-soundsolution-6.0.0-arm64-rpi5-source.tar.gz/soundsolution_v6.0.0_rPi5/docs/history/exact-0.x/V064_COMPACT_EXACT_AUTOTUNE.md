# v0.6.4 compact exact core and Raspberry autotune

Version 0.6.4 removes the rejected NEON partial-product path and keeps only
byte-exact scalar binary80 arithmetic.  The production VM is split from the
configuration, reset and post-load graphs so the real-time process path no
longer carries the whole generated interpreter body in its instruction working
set.

Accepted exact changes include:

- a dedicated production threaded graph;
- direct binary64 bit-pattern load/store helpers shared by native x87 and the
  software-binary80 backend;
- 64-bit state copies instead of two 32-bit copies;
- direct global-memory access in the fixed five-stage filter bank;
- predecoded exact binary80 coefficient tables;
- compact normal-finite add/multiply paths with cold special-value fallbacks;
- an optional exact square root that uses FP64 only to choose a bounded search
  interval and proves the result with integer squares, with reference fallback;
- optional compiler auto-vectorization only when the resulting PCM hash remains
  identical.

The Raspberry builder no longer assumes that one compiler layout is fastest.
It benchmarks exact variants locally on the target CPU and chooses among:

- scalar or stereo-pair kernels;
- inline or compact dynamics layout;
- reference or bounded-search exact square root;
- compiler vectorization enabled or disabled;
- optional target-local PGO, retained only when it wins the measured CPU-time
  comparison.

Every tuning candidate must produce the fixed 10-second PCM SHA-256 before it
can participate.  The winning build is then rebuilt cleanly, unit-tested and
validated on all block sizes.  The 30-second acceptance gate remains at 50.0%
single-core process CPU load.  A slower build is reported as a failed
performance candidate and no accepted runtime tarball is emitted.

No fast-math, arithmetic reassociation, FMA contraction, binary64 substitute
DSP path or approximate final result is enabled.
