# v0.6.8 M9 exact hot-path reduction

## Starting point

The Raspberry Pi 5 v0.6.7 target run passed every bit-exact validation but
measured 16.390 CPU seconds for 30 seconds of audio, or 54.6% of one Cortex-A76
core. The 270-second stateful run measured the same 54.6% load. The remaining
target gap is 1.390 CPU seconds per 30 seconds of audio.

The selected v0.6.7 layout was packed exact normal addition, the native exact
128/64 divider, Cortex-A76 code generation and PGO. The experimental M8 fused
multiply-accumulate path was not selected by target autotuning.

## M9 candidates

All M9 changes preserve software binary80 behavior and are separately
autotuned:

1. **Dead guest-flag elision.** A conservative CFG analysis treats CF/ZF/SF/OF
   as one live unit and removes updates only when every successor proves them
   dead. It rewrites 62 of 75 process-path flag-defining static instructions.
2. **Compact exact stereo add/sub.** Two stereo lanes enter one exact kernel,
   sharing the normal-value gate and avoiding two generic arithmetic call
   boundaries. Special values retain the original fallback.
3. **Shared-coefficient value ABI and metadata reuse.** Hot pair
   multiplication receives its three binary80 inputs as values. The common
   coefficient sign and unbiased exponent are decoded once and reused for both
   independently rounded products; safe reference outputs and all fallback
   behavior remain unchanged.
4. **Normalized pack fast path.** Hot arithmetic paths whose significands are
   already normalized skip a redundant integer-bit test; exponent boundary and
   subnormal fallback behavior remain unchanged.
5. **Exact bounded-distance aligner.** The normal-add GRS alignment computes
   the sticky bit without constructing a variable-width mask. Distances 1..66
   retain the original guard, round and sticky semantics.
6. **Exact normal-exponent range gate.** The normal finite test is rewritten
   from two comparisons to an equivalent unsigned subtract-and-range check.
   It remains separately target-autotuned because code generation differs by
   architecture.
7. **Exact binary64 `pow` result cache.** Dynamics processing uses only three
   exponent bit patterns (`0.6`, `-0.75`, and `-0.9`). A per-engine direct
   cache stores the original libm result bits keyed by the exact binary64 base
   and exponent. Cache hits therefore return precisely the same binary64 value;
   sizes 0, 64, 256 and 1024 are target-autotuned.

The autotune measures every candidate three times and selects by median CPU
time. It first selects the best cache-free M9 layout, then retests 64, 256 and
1024-entry exact `pow` caches on that same layout, preventing independent gains
from being compared only in isolation. The extended pass also retests
auto-vectorization, O2/O3, pair inlining, compiler arithmetic inlining and the
combined PGO layout because these options can interact with register pressure
on Cortex-A76.

## Development-host validation

- 6 of 6 CTest targets passed.
- 1,000,000-case exact arithmetic differential tests passed.
- 1,000,000-case shared-coefficient pair multiplication test passed.
- The actual scalar two-product implementation was enabled on the development
  host with the test-only scalar-pair switch, so validation did not exercise
  only the generic fallback.
- 3-second output matched at block sizes 1, 7, 64, 255, 256, 1024, 2048 and
  4096.
- 10-second SHA-256:
  `59ca7b2083869545a8ebb6ee3be028fd1e77307ed68fccf8b892951ae6e403b4`.
- 30-second SHA-256:
  `a1a4768be678cc2bffe50828a2eb1de655d1125a9ebad063de07b1776dac3e12`.
- 270-second SHA-256:
  `7eafc62739b028cb2bd56acf85571b025667b2726b142a95d5dfac5fb779f329`.
- 30-second impulse/DC/ramp SHA-256:
  `7a83b7fd031719070d943dfe74d01054066ec90e9d333ea40553af3146e844b9`.
- A 256-entry exact `pow` cache reduced local 10-second CPU time by roughly
  1.5--2 percent; the Raspberry Pi chooses its own cache size.
- The scalar-pair simulation with all M9 switches and a 256-entry cache matched
  the 270-second continuous-state hash; measured development-host CPU time was
  125.01 seconds (124.85 user + 0.16 system).

The <=50.0% target remains pending a Raspberry Pi 5 autotune run. No runtime
package is accepted when the measured 30-second CPU load exceeds the gate.
