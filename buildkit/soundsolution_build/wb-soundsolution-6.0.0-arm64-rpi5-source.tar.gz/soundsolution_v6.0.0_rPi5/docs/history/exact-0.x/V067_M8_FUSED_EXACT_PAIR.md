# v0.6.7 M8 fused exact stereo arithmetic

M8 targets the dominant Pi 5 profile cost without changing arithmetic order.
It adds an optional exact pair multiply-accumulate helper that preserves the
intermediate binary80 product rounding, then performs the original add/sub.
The helper removes repeated function boundaries and duplicate normal-value
classification from the hot stereo filter kernels.

Optional target-autotuned switches:

- `SSNATIVE_ENABLE_M8_FUSED_PAIR_ACCUM`
- `SSNATIVE_M8_AUTO_INLINE_ARITH`
- `SSNATIVE_ENABLE_M8_PACKED_ADD`
- the existing exact `SSNATIVE_M7_HW_DIV`

All candidates must pass the unchanged 3 s, 10 s, 30 s, 270 s and stress PCM
hashes. The Raspberry Pi build still refuses to emit an accepted runtime when
the measured 30-second single-core load exceeds 50%.
