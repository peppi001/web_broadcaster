# soundsolution-native

GUI-free native Linux reconstruction of the Sound Solution 2.0 Winamp DSP.
It builds a 64-bit `libsoundsolution.so`, reads the original fixed-size `.dat`
configuration and processes interleaved signed 16-bit PCM in place without
Wine, Winamp or a Windows subprocess.

## Version 0.7.3 M14 dedicated AArch64 exact arithmetic

**Build-fix 1:** the standalone M14 arithmetic test executables now link the
AArch64 assembly translation unit explicitly. The original source package
linked it only into `libsoundsolution`, which caused `ssnative-m6-x87-tests`
and then `ssnative-x87-pair-tests` to fail with undefined
`ssnative_m14_*_asm` references on Raspberry Pi. No DSP or arithmetic code was
changed by this build fix.

Version 0.7.3 starts from the fully bit-exact Raspberry Pi 5 v0.7.2 result at
51.87% median single-core load. M14 targets the remaining software-binary80
cost with three independent stack-free AArch64 assembly kernels: normal/zero
addition, scalar multiplication and shared-coefficient stereo multiplication.
All rare IEEE, boundary, overflow and subnormal cases retain the established
C++ fallback. Tiny C++ wrappers are forced inline so callers invoke the assembly
entry points directly.

The focused Pi builder always retains the proven M13 configuration and measures
all eight meaningful add/mul/pair combinations with plain, PGO30, repeated
30-second, PGO90 and mixed-corpus stages. The final build still must pass every
fixed PCM hash, the 270-second state test, the stress corpus and the hard 50.0%
CPU gate.

```bash
./start-v073-rpi5.sh
```

See [`docs/V073_M14_AARCH64_ARITHMETIC.md`](docs/V073_M14_AARCH64_ARITHMETIC.md).

## Version 0.7.2 M13 native VM blocks and instruction-cache autotune

Version 0.7.2 starts from the fully bit-exact Raspberry Pi 5 v0.7.1 result at
52.90% median single-core load.  M13 targets the remaining translated-VM and
instruction-cache cost rather than forcing the slower M12 fused candidates.
Five per-sample legacy ranges can be removed at compile time and replaced by
small exact native kernels covering state/output smoothing, band postprocessing,
delay interpolation, prefilter setup and the fourth-order/clip/output-meter
pipeline.  All original binary80 ordering, binary64 rounding stores, raw state
copies and observable VM side effects are retained.

The Pi builder screens 32 structural candidates, keeps the proven v0.7.1
configuration as a mandatory fallback, and performs PGO30, repeated 30-second
confirmation, PGO90, mixed-corpus retraining and an adaptive Cortex-A76 layout
search.  The selected build is independently rebuilt and must pass every fixed
PCM hash plus the hard 50.0% acceptance gate.

```bash
./start-v072-rpi5.sh
```

See [`docs/V072_M13_NATIVE_BLOCK_AUTOTUNE.md`](docs/V072_M13_NATIVE_BLOCK_AUTOTUNE.md).

## Version 0.7.1 M12 corrected fused filters and iterative Pi autotune

Version 0.7.1 starts from the bit-exact Raspberry Pi 5 v0.7.0 result at 53.4%
single-core load.  M12 corrects the earlier fused stereo experiment so a
rounded pair product is never recomputed when the following add leaves the
small-distance path.  The common filter case therefore performs exact
multiply, binary80 rounding and add/sub in one narrow call-site kernel, while
all special, overflow, subnormal and wide-distance behavior retains the
established exact fallback.

The Pi 5 builder no longer selects from one short benchmark round.  It measures
every structural candidate with and without PGO, confirms the leaders on
repeated 30-second runs, retrains them with 90-second and mixed corpora, and—if
the best result remains above 49.8%—launches an adaptive Cortex-A76 code-layout,
block-reordering, scheduling and compiler search around the current winner.
The selected binary is rebuilt independently and must pass three new 30-second
runs, the 270-second reference, the stress corpus and the hard 50.0% gate.

```bash
./start-v071-rpi5.sh
```

See [`docs/V071_M12_ITERATIVE_FUSED_AUTOTUNE.md`](docs/V071_M12_ITERATIVE_FUSED_AUTOTUNE.md).

## Version 0.7.0 M11 exact leaf multiply and stereo conversion paths

Version 0.7.0 starts from the fully bit-exact Raspberry Pi 5 v0.6.9 result:
53.7% single-core load for the 30-second corpus and 53.9% for the 270-second
continuous run. M11 keeps the selected register-ABI add path and targets the
remaining shared-coefficient and scalar multiply overhead. Exact in-range
normal products can run in small leaf kernels with direct binary80 packing,
while all overflow, underflow, subnormal, infinity and NaN behavior remains in
the original fallback. Independent candidates also combine stereo binary64 loads/stores, compare an
inline paired load against a compact outlined helper, and handle a normal shared
coefficient with signed-zero lanes.

The focused Pi 5 builder measures nineteen hash-gated non-PGO layouts. The
proven M10 baseline plus the fastest eight M11 layouts are then rebuilt with
Pi-local GCC PGO. The selected build still has to pass every block size, the
30- and 270-second references and the stress corpus before the 50.0% CPU gate.

```bash
./start-v070-rpi5.sh
```

See [`docs/V070_M11_LEAF_FILTER_KERNELS.md`](docs/V070_M11_LEAF_FILTER_KERNELS.md).

## Version 0.6.9 M10 exact register-ABI add path

Version 0.6.9 starts from the Raspberry Pi 5 v0.6.8 target result, which was
fully bit-exact at 54.4% single-core load for 30 seconds and 54.2% for the
270-second continuous run. The new profile places exact binary80 addition at
27.67% of samples. M10 removes the 48-byte AArch64 stack frame and operand
store/reload sequence from the hot add dispatcher by passing both normal and
special operands in registers. It also autotunes a compact significand-based
normal classifier, a cold overflow/subnormal pack fallback and internal packed
add inlining.

The focused Pi 5 builder measures ten exact layouts with three-repeat median
CPU time, then separately rebuilds and measures the fastest four with target-
local GCC PGO. Every run must match the fixed PCM SHA-256 before selection.

```bash
./start-v069-rpi5.sh
```

See [`docs/V069_M10_REGISTER_ABI.md`](docs/V069_M10_REGISTER_ABI.md).

## Version 0.6.7 M8 fused exact stereo arithmetic

Version 0.6.7 continues the Pi 5 optimization from the bit-exact v0.6.6 M7
57.3% result. M8 fuses shared-coefficient stereo multiplication with the
following exact add/sub while retaining the original intermediate binary80
rounding. It also adds an exact packed-metadata normal-add kernel that removes
redundant hot-path classification without changing binary80 rounding. The target
build autotunes both M8 paths together with the exact M7 hardware divider and
compiler/PGO-controlled arithmetic inlining. See
`docs/V067_M8_FUSED_EXACT_PAIR.md`.

## Version 0.6.6 M7 register-layout exact autotune

Version 0.6.6 follows the selected v0.6.5 Pi 5 profile, where exact addition,
scalar/pair multiplication, binary64 loading and the remaining production VM
accounted for most CPU samples. The M7 candidate stores the x87 sign/exponent
metadata in a full 64-bit word while preserving the 16-byte object size and
all low-16-bit binary80 semantics. This removes halfword loads and padding
traffic from hot arithmetic calls.

The Pi builder compares the proven M6 layout with M7 meta64, an exact native
64-bit 128/64 divider, a compact production VM, two-register value ABI and an
inline normal binary64 load. Every candidate must produce the same 10-second
PCM hash before it can be selected, and PGO is retained only if measured CPU
time improves.

```bash
SSNATIVE_AUTOTUNE=1 \
SSNATIVE_AUTOTUNE_EXTENDED=1 \
SSNATIVE_ENABLE_PGO=1 \
SSNATIVE_PGO_SECONDS=30 \
SSNATIVE_RUN_LONG_TEST=1 \
SSNATIVE_RUN_270S_TEST=1 \
SSNATIVE_RUN_STRESS_TEST=1 \
SSNATIVE_MAX_SINGLE_CORE_LOAD=50.0 \
./tools/build_raspberry_pi.sh pi5
```

See [`docs/V066_META64_EXACT_AUTOTUNE.md`](docs/V066_META64_EXACT_AUTOTUNE.md).

## Version 0.6.5 branchless exact arithmetic core

Version 0.6.5 targets the arithmetic bottlenecks measured in the selected
v0.6.4 Pi 5 profile. Normal binary80 rounding uses branchless
round-to-nearest-even formulas, zero operands have exact short paths, and a
binary64 state store can return the already-rounded binary80 value without
immediately decoding the same 64-bit pattern again.

The Raspberry builder compares the proven v0.6.4/M5 arithmetic with a focused
M6 matrix: pair inlining, shared stereo coefficients and a single-divmod
variant remain optional and are selected only when target CPU time improves.
Every candidate must first produce the fixed 10-second reference hash. The
final build then runs the arithmetic differential suite and the normal PCM
validation gates.

```bash
SSNATIVE_AUTOTUNE=1 \
SSNATIVE_AUTOTUNE_EXTENDED=1 \
SSNATIVE_ENABLE_PGO=1 \
SSNATIVE_RUN_LONG_TEST=1 \
SSNATIVE_RUN_270S_TEST=1 \
SSNATIVE_RUN_STRESS_TEST=1 \
SSNATIVE_MAX_SINGLE_CORE_LOAD=50.0 \
./tools/build_raspberry_pi.sh pi5
```

See [`docs/V065_BRANCHLESS_EXACT_CORE.md`](docs/V065_BRANCHLESS_EXACT_CORE.md).

## Version 0.6.4 compact exact core and Pi-local autotune

Version 0.6.4 removes the slower NEON partial-product experiment and keeps the
validated scalar `MUL`/`UMULH` exact path.  The production VM graph is split
from configuration/reset code, fixed filter coefficients are predecoded,
binary64 state is moved by exact bit pattern, and the normal binary80 core is
kept compact with rare cases in cold fallbacks.

The Raspberry builder benchmarks exact code-layout variants on the target Pi
and selects the fastest byte-identical combination.  It also compares PGO
against the non-PGO winner instead of assuming PGO helps.  With
`SSNATIVE_RUN_LONG_TEST=1`, the hard acceptance gate remains 50.0% single-core
process CPU load; a slower result creates no accepted runtime package.

```bash
SSNATIVE_RUN_LONG_TEST=1 \
SSNATIVE_RUN_270S_TEST=1 \
SSNATIVE_RUN_STRESS_TEST=1 \
./tools/build_raspberry_pi.sh pi5
```

See [`docs/V064_COMPACT_EXACT_AUTOTUNE.md`](docs/V064_COMPACT_EXACT_AUTOTUNE.md).

## Version 0.6.3 ARM64 exact NEON milestone

Version 0.6.3 keeps the deterministic software binary80 backend and processes
independent left/right filter operations in exact two-lane kernels on AArch64.
The significand products use NEON `UMULL/UMLAL` partial products; each lane is
then rounded independently with the same p=64 round-to-nearest-even logic as
the scalar NativeDouble reference.

The paired path covers the production filter bank, biquad, one-pole and
fourth-order stereo filters. All original binary64 state stores remain in the
same order. A faster binary80 square root uses an FP64 estimate only as a hint,
then proves and corrects the integer root exactly. Normal finite addition uses
a 64-bit significand plus explicit guard/round/sticky bits instead of a generic
128-bit temporary.

The Raspberry builder runs a million-case NEON pair-multiply differential test,
the reference PCM hashes and an optional impulse/DC/ramp stress corpus. With
the 30-second benchmark enabled, the default acceptance gate is 50.0 percent
single-core real-time load; a slower build is rejected and no accepted runtime
tarball is emitted.

## Version 0.6.2 ARM64 performance milestone

Version 0.6.2 directly translates the five-band detector loop and its legacy
`0x10008D00` RMS helper. It preserves the exact binary80 operation order and
both binary64 storage points while removing repeated VM register, stack,
branch and FPU dispatch work from every audio frame.

The Raspberry build now performs GCC profile-guided optimization locally on the
target Pi by default. It trains with deterministic audio, rebuilds in the same
build directory, verifies that the profile was consumed, and then runs the
normal bit-exact validation suite. Disable PGO only for A/B measurements with
`SSNATIVE_ENABLE_PGO=0`.

```bash
SSNATIVE_RUN_LONG_TEST=1 ./tools/build_raspberry_pi.sh auto
```

For the complete continuous-state acceptance test:

```bash
SSNATIVE_RUN_LONG_TEST=1 SSNATIVE_RUN_270S_TEST=1 \
    ./tools/build_raspberry_pi.sh auto
```

See
[`docs/V062_ARM64_PERFORMANCE_MILESTONE.md`](docs/V062_ARM64_PERFORMANCE_MILESTONE.md).

## Version 0.6.1 ARM64 performance milestone

Version 0.6.1 is a profile-driven optimization of the strict software-binary80
backend used on Raspberry Pi 4 and Pi 5. It keeps the v0.6.0 reference
arithmetic as the fallback and adds short exact fast paths only for already
normal finite values and already-normalized in-range results.

The accepted changes optimize normal `double`/binary80 conversion, normal
addition, product rounding and redundant normalization. Every subnormal,
underflow, overflow, NaN and infinity case continues through the full reference
path. No `fast-math`, FMA contraction, reassociation or binary64 DSP shortcut is
enabled.

Validation for this source release includes:

- one million deterministic random arithmetic records compared byte-for-byte
  with the pristine v0.6.0 software-binary80 implementation;
- zero differing records across add, subtract, multiply, divide and both
  conversion directions;
- explicit underflow and binary64-subnormal unit tests;
- unchanged 3-second and 30-second PCM reference hashes.

The Pi builder now reports the processor-only elapsed time, real-time factor and
estimated single-core load during the optional 30-second validation:

```bash
SSNATIVE_RUN_LONG_TEST=1 ./tools/build_raspberry_pi.sh auto
```

The full continuous-state acceptance corpus can also be run on the target Pi:

```bash
SSNATIVE_RUN_LONG_TEST=1 SSNATIVE_RUN_270S_TEST=1 \
    ./tools/build_raspberry_pi.sh auto
```

See
[`docs/V061_ARM64_PERFORMANCE_MILESTONE.md`](docs/V061_ARM64_PERFORMANCE_MILESTONE.md).

## Version 0.6.0 ARM64 milestone

Version 0.6.0 starts the Raspberry Pi 4/5 port. It adds explicit CPU targets
for Cortex-A72 and Cortex-A76 and a deterministic software binary80 backend for
the x87 extended-precision operations that AArch64 cannot execute natively.

The software backend has matched the native amd64 x87 backend byte-for-byte on
the arithmetic tests, every regression block size, a 30-second portable corpus
and a 270-second continuous corpus. A plain `double` implementation was
rejected after two differing bytes appeared in the 270-second comparison.

This package is the first ARM64 port milestone. Raspberry Pi 5 execution,
bit-exact 3/30-second validation, CPU load and thermal profiling have since been
completed; Pi 4 validation and further performance work remain open. See
[`docs/RASPBERRY_PI_ARM64.md`](docs/RASPBERRY_PI_ARM64.md).

### Raspberry build

```bash
./tools/build_raspberry_pi.sh auto
```

Explicit targets are `pi4` and `pi5`. The build script compiles the correct
Cortex-tuned binary, runs the tests and validates all supported block sizes
against the embedded amd64 PCM hash.

### Backend equivalence validation on amd64

```bash
./tools/validate_native_double_backends.sh
```

## Version 0.5.0

Version 0.5.0 is a bit-exact performance update based on v0.4.1. It keeps the
strict acceptance rule: every optimized build must produce byte-for-byte the
same signed 16-bit PCM as the established Wine/AppImage reference with the
supplied `ss18.dat` configuration.

The principal change is a direct C++ translation of the hot legacy range
`0x10002F85-0x10003055`. The old generated VM executed a five-band outer loop
and a two-channel inner loop for every audio frame. Version 0.5.0 performs the
same operations directly while preserving:

- the original x87 80-bit intermediate precision;
- the exact arithmetic order;
- every binary64 (`double`) storage and reload point;
- circular-delay indexing and state write order;
- signed integer conversions and final PCM behavior.

This removes repeated virtual register, flag, FPU-stack, address-decoding and
loop-dispatch work from a frame-level hotspot. Existing v0.4.x optimizations are
retained, including static x87 stack specialization, direct hot helpers,
branch specialization, the 64 KiB guest-stack reset window, and generic/v2/v3
CPU variants.

No `-ffast-math`, FMA contraction, arithmetic reassociation, reduced precision
or approximate DSP calculation is enabled.

### Bit-exact validation

- 30-second reference output SHA-256:
  `838f1e9154195e8d48435b3bd71b2927563d89b2d85512e58cbc7542e1b05325`
- edge-corpus SHA-256 for block sizes 1, 7, 64, 255, 256, 1024, 2048 and 4096:
  `53b15f0d1e0695b3ba80ff81c5dd4dd7ed53a11250241c74099d3e7beaa08664`
- continuous 270-second output SHA-256:
  `df7b3b66ae936cdb2cf18fc8e2aaef73739d03a090ac45f7554d7cc7b094d0f1`

All compared outputs had zero mismatching bytes.

The binary package contains generic, x86-64-v2 and x86-64-v3 shared-library
variants. Debian 12 glibc automatically loads the best variant supported by the
processor and falls back to the generic library.

## Build and test

```bash
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build build
ctest --test-dir build --output-on-failure
```

Select an explicit CPU target with `-DSSNATIVE_CPU_LEVEL=` followed by
`x86-64`, `x86-64-v2`, `x86-64-v3`, `armv8-a`, `raspberry-pi-4` or
`raspberry-pi-5`. The x87 backend is selected automatically by architecture,
or explicitly with `-DSSNATIVE_X87_BACKEND=native|soft`.

## C API

```c
ssnative_dsp *dsp = ssnative_create();
ssnative_load_dat(dsp, "/path/ss18.dat");

ssnative_process_s16_interleaved(
    dsp,
    samples,
    frames,
    2,
    44100
);

ssnative_destroy(dsp);
```

The DSP handle owns all delay lines and detector state. Do not process the same
handle concurrently. Separate stations must use separate handles.

## Raw PCM processor

```bash
cat input-s16le.raw | \
  ./build/ssnative-process-raw testdata/ss18.dat 2 44100 \
  > output-s16le.raw
```

The input and output are headerless signed 16-bit little-endian interleaved PCM.
The default block size is 1024 frames. Regression block size can be selected
with `SSNATIVE_BLOCK_FRAMES`.

## Scalar-pair diagnostic revision

The scalar pair multiply no longer uses inline assembly.  It expresses the
exact 64x64->128 unsigned product as `unsigned __int128`; GCC AArch64 lowers
this to scalar `MUL` + `UMULH`.  Run:

```bash
SSNATIVE_AB_SECONDS=30 SSNATIVE_AB_REPEATS=3 \
  ./tools/benchmark_rpi5_scalar_pair.sh
```

## Scalar-pair diagnostic hotfix

This package fixes the `pair_scalar` build failure caused by the scalar helper
using an inline macro that was defined only after `native_double.hpp` had already
been included. Run `tools/check_scalar_pair_header.sh` for a compile-only
regression check before the benchmark.
