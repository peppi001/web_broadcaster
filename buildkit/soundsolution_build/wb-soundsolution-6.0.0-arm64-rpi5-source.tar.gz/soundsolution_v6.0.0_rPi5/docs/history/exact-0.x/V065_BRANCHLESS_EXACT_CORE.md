# v0.6.5 branchless exact arithmetic core

## Profile basis

The selected v0.6.4 Pi 5 build processed 30 seconds in 22.15 seconds of CPU
(73.8% of one core), with all reference hashes passing. Its profile moved the
bottleneck out of instruction-cache misses and into the exact arithmetic core:
`NativeDouble::add`, scalar/pair multiplication and binary64 conversion accounted for
most samples.

## Exact M6 changes

The M6 core does not use `fast-math`, reassociation, contraction or a direct
binary64 DSP path. It preserves binary80 p=64 round-to-nearest-even results.

- Normal binary80 to binary64 rounding uses an arithmetic nearest-even
  increment and branchless significand carry handling.
- Product and add guard/round/sticky packing use the same exact branchless
  nearest-even formula.
- Exact zero operands bypass general special-value helpers without changing
  NaN or infinity behavior.
- `global_round_store_f64` can write the binary64 bits and return their exact
  binary80 reconstruction directly, avoiding an immediate decode of the same
  bit pattern.
- Pair inlining, same-coefficient pair multiplication and one-call 128-bit
  div/mod are separate target-autotuned options, not mandatory assumptions.

## Independent differential validation

`tests/test_native_double_m6.cpp` performs one million deterministic comparisons for each
of these operations against locally implemented branchy reference algorithms:

- normal binary80 addition;
- normal binary80 multiplication;
- normal binary80 division using quotient and remainder;
- normal binary80 to binary64 nearest-even conversion;
- direct round/store reconstruction versus parsing the emitted binary64 bits.

The existing pair test also validates the optional shared-coefficient kernel.
These arithmetic tests are independent of the end-to-end PCM hashes.

## Raspberry autotune matrix

The builder measures the v0.6.4/M5 reference and the following byte-identical
M6 candidates with a fixed 10-second corpus:

- M6 exact core with direct round/store;
- pair-inline variant;
- shared-coefficient pair variant;
- pair-inline plus shared coefficient;
- single-divmod variant;
- non-pair scalar layout.

The exact sqrt reference variant is measured again. Extended autotune also
checks the opposite vectorization setting and `-O2`/`-O3`. Pi-local PGO is
retained only when its measured CPU time wins.

## Acceptance

No accepted runtime is emitted unless all requested reference hashes pass and
the 30-second process CPU load is at or below the configured gate, 50.0% by
default.
