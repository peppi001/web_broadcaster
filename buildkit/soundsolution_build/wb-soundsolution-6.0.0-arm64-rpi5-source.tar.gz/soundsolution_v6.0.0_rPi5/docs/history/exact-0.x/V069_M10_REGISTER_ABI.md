# v0.6.9 M10: exact register-ABI add path

The Raspberry Pi 5 v0.6.8 M9 target run remained bit-exact but measured 54.4%
single-core load for the 30-second corpus and 54.2% for the 270-second
continuous-state corpus. The profile moved `NativeDouble::add` to 27.67% of samples, so
v0.6.9 focuses on the exact binary80 add dispatch rather than repeating the
broad M9 search.

Instrumentation of the reference workload counted 136,993,432 additions in ten
seconds. 121,538,135 had two normal finite operands. Every remaining production
case involved an exact zero; no NaN, infinity or subnormal operand reached the
add entry. Roughly three quarters of normal additions had exponent distance at
most three, but fixed-distance shift specializations were slower in development
host A/B tests and are not part of the focused target matrix.

AArch64 code inspection exposed a more important cost. The v0.6.8 add dispatcher
created a 48-byte stack frame, stored both 16-byte operands, and passed references
to the outlined normal kernel. M10 can pass both normal and special add operands
as four AArch64 argument registers. The normal path then has no stack frame and
tail-branches to the exact packed add kernel. A separate candidate also places
the rare overflow/subnormal pack fallback in a cold noinline section, shrinking
the hot normal arithmetic body.

All changes preserve the binary80 intermediate rounding points. The focused Pi
5 autotune measures the v0.6.8 winner and these independent M10 switches:

- significand-based normal operand classification;
- complete add value ABI;
- cold rare pack fallback;
- internal packed-add inlining;
- scalar pair inlining on and off.

Every candidate is measured three times against the fixed ten-second SHA-256.
The fastest four non-PGO layouts are rebuilt and measured separately with
30-second target-local GCC PGO training. Only a hash-matching candidate can be
selected.
