# v0.7.3 M14 dedicated AArch64 exact arithmetic kernels

## Purpose

The Raspberry Pi 5 v0.7.2/M13 build is fully bit-exact at a three-run median
of 51.87% single-core load.  The remaining cost is concentrated in deterministic
software binary80 arithmetic: `NativeDouble::add`, scalar `NativeDouble::mul`, and the
shared-coefficient stereo multiply together account for about 56.9% of sampled
CPU time.  M14 is the final focused attempt to reach the 50.0% acceptance gate.

## New kernels

M14 adds three independent AArch64 assembly candidates:

- `ssnative_m14_add_asm`: normal-or-zero exact binary80 addition;
- `ssnative_m14_mul_asm`: in-range normal/zero exact scalar multiplication;
- `ssnative_m14_mul_pair_same_asm`: two exact products sharing one coefficient.

The normal paths use only caller-saved registers and do not create stack frames.
The generated symbol sizes are approximately 604, 220 and 304 bytes,
respectively, versus roughly 1048, 328 and 624 bytes for the corresponding
selected C++ functions in the v0.7.2 profile.  Rare NaN, infinity, pseudo-
denormal, subnormal, overflow and underflow cases tail-branch to the previously
validated C++ implementation.

The tiny C++ dispatch wrappers are forced inline, so DSP callers invoke the
assembly symbols directly.  No extra `NativeDouble::add -> assembly` or
`NativeDouble::mul -> assembly` call layer remains.

## Bit-exact policy

The assembly source is paired with a portable C++ model implementing the same
branching and rounding decisions.  On development builds this model is exercised
by the existing one-million-record add/multiply differential test and the
one-million-record pair-multiply test.  The maximum M14 layout also passed:

- all six unit/differential tests;
- 3-, 10- and 30-second fixed reference hashes;
- block sizes 1, 7, 64, 255, 256, 1024, 2048 and 4096;
- the 30-second impulse/DC/ramp stress hash.

The complete 270-second stateful validation remains mandatory in the Raspberry
Pi builder.  An accepted runtime is never produced if any hash differs.

## Raspberry Pi autotune

The Pi 5 builder retains the proven v0.7.2/M13 configuration as a mandatory
baseline and evaluates eight arithmetic layouts:

1. M13 baseline;
2. add only;
3. scalar multiply only;
4. pair multiply only;
5. add + scalar multiply;
6. add + pair multiply;
7. scalar + pair multiply;
8. all three kernels.

Every layout is screened without PGO and with PGO30.  The leaders receive
independent repeated 30-second confirmation, PGO90 retraining and mixed-corpus
PGO.  The selected configuration is rebuilt from scratch and must pass all
reference hashes plus the hard 50.0% single-core gate.

## Stop rule

M14 is deliberately the last architecture-specific arithmetic round.  If the
Pi 5 target still remains above 50.0%, v0.7.2/M13 or the fastest bit-exact M14
configuration should be treated as the rational endpoint unless the project is
willing to replace larger filter call sites with hand-written assembly.
