# v0.6.0 ARM64 milestone validation record

Validation host: amd64 Linux development container, Release build,
`-march=x86-64`, FMA contraction disabled.

## Build tests

Both `SSNATIVE_X87_BACKEND=native` and `SSNATIVE_X87_BACKEND=soft` passed:

1. `ssnative-dat-roundtrip`
2. `ssnative-c-api`
3. `ssnative-translated-kernels`
4. `ssnative-soft-x87-arithmetic`

## Portable corpus

Generator: `tools/generate_bitexact_pcm.py`, 44.1 kHz, stereo, signed 16-bit.

Input hashes:

- 3 seconds: `dc1d9263b214b8217ca8e38fdc4063c385b37b17ba1e769cca0d60fcc3a4f3d6`
- 30 seconds: `21fb7428bb6a150d3a2ae4f66c6f89db0bae1e9b810ad7759002f119214846fc`

Native-x87 and software-binary80 output hashes:

- 3 seconds: `ea5c85b2ebb0100fa44585ec4f106a9cae8b61c16489ff358beddf6ac181d49a`
- 30 seconds: `a1a4768be678cc2bffe50828a2eb1de655d1125a9ebad063de07b1776dac3e12`

The 3-second output was identical at block sizes 1, 7, 64, 255, 256, 1024,
2048 and 4096 frames.

## Long continuous comparison

Compared bytes: 47,628,000

- native-x87 SHA-256:
  `57ec5a6305ca3465fb1761786898806f6ef09f71f5140187441a4c694bf88f2e`
- software-binary80 SHA-256:
  `57ec5a6305ca3465fb1761786898806f6ef09f71f5140187441a4c694bf88f2e`
- mismatching bytes: 0

A separate all-`double` experiment produced two differing bytes in the same
270-second class of test and was rejected.

## Software binary80 performance change

A normalization hotspot was changed from repeated single-bit shifts to a
constant-time leading-bit calculation.

Development-host result on the 3-second portable corpus:

- before: 3.35 seconds
- after: 2.26 seconds
- PCM difference: 0 bytes

The optimized software backend processed the 30-second portable corpus in
23.24 seconds on the development amd64 host. These are implementation
measurements, not Raspberry Pi performance claims.

## Not validated in this milestone

- AArch64 compiler/linker output
- actual Raspberry Pi 4 or Pi 5 execution
- ARM64 `libm` equivalence for audio-dependent `pow()` calls
- Raspberry real-time scheduling, CPU load, maximum callback time or thermals

These remain release blockers.
