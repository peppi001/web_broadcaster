# Raspberry Pi 5 current-best profile

This diagnostic build profiles the fastest validated combination from the M4 A/B tests:

- exact software binary80 backend;
- exact 64-bit normal addition enabled;
- exact scalar stereo pair kernels enabled;
- scalar AArch64 64x64->128 multiplication (`MUL` + `UMULH` code generation);
- experimental fast integer square root disabled;
- no fast-math and no FMA contraction.

Run:

```bash
SSNATIVE_PROFILE_SECONDS=30 ./tools/profile_rpi5_current_best.sh
```

The script creates `rpi5-current-best-profile-<UTC>.tar.gz` containing CPU counters,
flat and call-graph perf reports, symbol sizes, disassembly, instruction counts, hashes,
and the complete timing report.
