# v0.6.1 ARM64 performance milestone

Version 0.6.1 is the first profile-driven Raspberry Pi performance update for
the deterministic software-binary80 backend.

## Raspberry Pi 5 v0.6.0 baseline

The production Pi 5 report was collected on a Raspberry Pi 5 Model B Rev 1.1
at 2.4 GHz. The processor remained unthrottled (`0x0`) and below 47 C. A
30-second 44.1 kHz stereo corpus required 27.73 seconds, corresponding to
1.082x real time and approximately 92.4% of one CPU core.

The flat cycle profile identified the main costs as:

- `NativeDouble::add`: 17.49%
- `Machine::execute`: 13.83%
- `NativeDouble::mul`: 9.06%
- arithmetic wrapper calls: approximately 18%
- binary64/binary80 conversions: approximately 12%
- 128-bit division helpers: approximately 3%

The run was instruction and branch limited, not memory limited. L1 data-cache
misses were only 0.02%, while branch misses were 3.61%.

## Accepted changes

The following transformations preserve the original operation order and exact
round-to-nearest-even behavior:

1. Normal finite `double` values are mapped directly to binary80 fields without
   invoking the general normalizer.
2. Normal binary80 values use a direct binary64 conversion path while retaining
   the original special/subnormal fallback.
3. Already-normalized, in-range results bypass redundant leading-zero
   normalization. Out-of-range and non-normal values always use the complete
   v0.6.0 reference packer.
4. Normal finite addition uses a bounded 67-bit guard/round/sticky path instead
   of the fully general width-normalization path.
5. 64x64 multiplication rounding is specialized for the only two shifts used
   by the binary80 product path.
6. Non-mutating arithmetic operators call the exact primitive directly instead
   of routing through a temporary compound-assignment wrapper.

No `fast-math`, FMA contraction, reassociation, approximate transcendental
function, or binary64 DSP shortcut is enabled.

## Validation

- Unit tests include explicit binary80 underflow and binary64-subnormal cases.
- One million deterministic random records were compared against the pristine
  v0.6.0 software-binary80 implementation. Each record covered add, subtract,
  multiply, divide, binary80-to-double, and double-to-binary80 conversion.
- Differing records: zero.
- The 3-second and 30-second PCM reference hashes remain unchanged.
- A fresh 270-second deterministic continuous-state corpus was processed by the
  native amd64 x87 backend and the v0.6.1 software-binary80 backend. All
  47,628,000 output bytes matched. The common output SHA-256 is
  `7eafc62739b028cb2bd56acf85571b025667b2726b142a95d5dfac5fb779f329`.
- The development-host software-binary80 run completed in 172.148 seconds
  (1.568x real time). This is not a Raspberry Pi benchmark.

The Pi build script reports processor-only elapsed time, real-time factor, and
estimated single-core real-time load when `SSNATIVE_RUN_LONG_TEST=1` is used.
The complete continuous-state test is available with
`SSNATIVE_RUN_270S_TEST=1`. A target-Pi performance result remains mandatory
before promoting a final ARM64 runtime binary.
