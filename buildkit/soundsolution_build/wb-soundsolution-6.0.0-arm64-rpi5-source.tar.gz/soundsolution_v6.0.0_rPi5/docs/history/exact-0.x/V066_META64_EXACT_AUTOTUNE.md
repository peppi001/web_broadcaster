# v0.6.6 M7 register-layout exact autotune

## Pi 5 profile basis

The selected v0.6.5 M6 build processed 30 seconds in 18.32 seconds of CPU
(61.1% of one Cortex-A76 core) with all short, continuous and stress hashes
passing. The flat profile attributed 28.08% to `NativeDouble::add`, 14.65% to
`NativeDouble::mul_pair_same`, 12.07% to `NativeDouble::mul`, 5.74% to binary64 loading and
12.16% to the inlined production VM body.

## Exact M7 candidates

All M7 changes preserve software-binary80 p=64 round-to-nearest-even results.
No fast-math, reassociation or direct binary64 DSP path is used.

- **64-bit metadata (`meta64`)**: the sign/exponent field occupies a full
  64-bit register word instead of a 16-bit field plus six padding bytes. The
  object remains exactly 16 bytes and the public bit representation remains
  the original low 16 bits. Local target-like testing improved the 10-second
  run from about 4.81 to 4.53 CPU seconds.
- **Native 128/64 divider**: a normalized base-2^32 Knuth/Hacker's Delight
  quotient/remainder kernel uses native 64-bit divisions instead of
  `__udivti3`/`__umodti3`. It is optional because development-host timing was
  neutral/slower, while the Pi profile assigned 3.87% to the libgcc helpers.
- **Compact production VM**: labels whose only incoming edge is the immediately
  preceding unconditional natural-flow `goto` are removed. All real branch,
  call and return targets remain. The include shrinks from 2252 to 1288 lines
  and is target-autotuned rather than forced.
- **Two-register value ABI** and **inline binary64 load** are optional AArch64
  code-generation experiments. They were slower on the development host and
  can be retained only when the Pi measurement wins.

## Independent validation

`tests/test_native_double_m6.cpp` is also compiled with the selected M7 arithmetic
options. It performs one million deterministic differential checks per normal
addition, multiplication, division, binary80-to-binary64 conversion and direct
round/store reconstruction. A static assertion keeps `sizeof(NativeDouble) == 16`.

The final source candidate passed:

- native x87 and software-binary80 CTest suites;
- 3-second validation at block sizes 1, 7, 64, 255, 256, 1024, 2048 and 4096;
- 30-second reference hash;
- 270-second continuous-state hash over 47,628,000 output bytes;
- 30-second impulse/DC/ramp stress hash;
- zero byte differences against the native x87 reference.

## Raspberry autotune matrix

The target builder measures the v0.6.5 M6 reference and focused M7 variants:
meta64, shared/non-shared pair layout, native divider, compact VM, value ABI,
inline binary64 load and selected combinations. Extended mode checks the
opposite vectorization setting and `-O2`/`-O3`. PGO is accepted only when its
10-second process CPU time beats the non-PGO candidate.

The hard release gate remains 50.0% single-core process load for the 30-second
corpus. A bit-exact result above the gate produces no accepted runtime package.
