# Cold-control isolation C4 — SoundSolution 2.6.0

## Cél

A 2.5.0 ugyanazon `NativeControlExecutor` 1536 bájtos fizikai stackjét tartotta
meg az audio `process`, a `configure` és a `postload` számára. Mérés szerint a
legmélyebb hozzáférések:

- process: 480 bájt;
- configure: 352 bájt;
- postload: 1396 bájt.

## Megoldás

- A tartós, audioútban használt executor 512 bájtos fizikai stackkel működik.
- A 1536 bájtos cold-control stack csak `load_config()` alatt, lokális tömbként
  létezik.
- A `configure` és `postload` külön ideiglenes executoron fut; csak a named-state
  tár közös a process executorral.
- A virtuális stackcímek, a műveleti sorrend és a typed continuation működés
  változatlan, ezért a PCM bitazonos marad.
- A process út továbbra sem foglal memóriát.

## Határ

A három `native_control_*.inc` továbbra is statikusan fordított control-forrás.
A 2.6.0 célja a cold utak életciklusának és tárigényének leválasztása, nem a
configure/postload algoritmus magas szintű újraírása.
