# Translated DSP kernels

The standalone x87 helper routines below have direct algebraic C++ versions
and independent unit tests. The complete top-level audio path is also active
through the generated native translation layer, so these routines now serve as
the starting point for replacing address-based instructions with maintainable
semantic DSP code.

| Original address | Native routine | Status |
|---:|---|---|
| `0x10007AC0` | `quadratic_map` | translated and tested |
| `0x10007B20` | `multiply_milli` | translated and tested |
| `0x10007B50` | `time_coefficient_ms` | translated and tested |
| `0x10008240` | `db_tenths_to_pcm` | translated and tested |
| `0x10008270` | `db_hundredths_to_pcm` | translated and tested |
| `0x10008AC0` | stereo second-order IIR kernel | translated and tested |
| `0x10008B60` | stereo first-order IIR kernel | translated and tested |
| `0x10008BD0` | stereo fourth-order IIR kernel | translated and tested |
| `0x10008D00` | exact RMS envelope helper | translated and PCM-validated |
| `0x10002E7A-0x10002F16` | five-band level detector loop | translated and PCM-validated |
| `0x10008FF0` | single-channel soft clipper | translated and tested |
| `0x10009070` | stereo soft clipper | translated and tested |
| `0x100095C0` | downward state smoother | translated and tested |

The larger routines at `0x10007B90`, `0x10007FE0`, and the remaining
`ModifySamples` body execute through the generated C++ migration layer. They
remain the main semantic-cleanup targets; audio processing is no longer blocked
on that cleanup.
