# Native cold-control 3.5.0

A 3.5.0-ban a cold vezérlés két tartománya közvetlen C++ callgraph:

- configure: 8 natív függvény, 21 belső közvetlen hívás, 0 continuation bájt;
- postload: 1 natív főfüggvény, 6 közvetlen hívás a közös configure segédekhez, 0 continuation bájt.

Eltávolítva:

- `native_control_configure.inc`;
- `native_control_postload.inc`;
- `ConfigureContinuation`;
- `PostloadContinuation`;
- cold return-dispatch.

A process hot path változatlanul híváslokális típusos continuation állapotot használ. A configure-core 289, a postload-core 109 compile-time statikus műveletet tartalmaz; ezek fordításkor rögzítettek, nem runtime interpreterek.
