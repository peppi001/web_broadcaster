# SoundSolution 2.8.0 control-domain isolation

A 2.7.0-ban a hot cache már fizikailag elkülönült, de a process, configure és
postload ugyanazt a continuation típust és az executor tartós continuation
mezőit használta.

A 2.8.0 három külön enumot használ:

- `ProcessContinuation`: 6 címkézett visszatérési pont;
- `ConfigureContinuation`: 24 címkézett visszatérési pont;
- `PostloadContinuation`: 7 címkézett visszatérési pont.

Mindegyik hívás saját `NativeContinuationState<T>` objektumot kap. Az objektum
a hívás befejezésekor megszűnik; a tartós audio executor nem őriz cold-control
visszatérési állapotot. A megengedett maximális mélység továbbra is 8, és a
virtuális x86 stack layout változatlan, ezért az átalakítás nem módosítja a
PCM műveleti sorrendjét.

A statikusan fordított process/configure/postload fragmentumok megmaradtak.
Ez a lépés a configure későbbi közvetlen C++ átírását készíti elő azzal, hogy
annak hívási állapota már önálló és típusosan elkülönített.
