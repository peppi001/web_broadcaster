# Raspberry Pi 5 / ARM64

A célplatform 64 bites Raspberry Pi OS / Debian 12, Raspberry Pi 5
(Cortex-A76). A kiadási build friss, 30 másodperces PGO-profilt használ.

A 2.9.0 célgépes referencia 30 másodperc hangot 2,15 CPU-másodperc alatt
dolgozott fel, ami 7,17% egy magos terhelés. A 3.5.0 kötelezően ugyanazokat a
PCM-hasheket adja. A configure continuation állapota teljesen megszűnt, de a
384 bájtos konfigurációs lokális backing megmaradt, hogy a statikusan fordított
koefficiensmag címei változatlanok legyenek. A Pi 5-ös célgépes build méri a
végleges terhelést.
