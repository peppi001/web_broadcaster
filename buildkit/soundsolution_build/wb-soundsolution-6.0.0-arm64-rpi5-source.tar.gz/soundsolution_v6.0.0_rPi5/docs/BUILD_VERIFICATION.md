# Build verification

A kiadás elfogadási feltételei:

- warningmentes Release build;
- CTest 3/3;
- named-state cím-audit: 319 egyedi cím, 0 gap-hozzáférés;
- split-control audit: nincs runtime interpreter vagy entry dispatcher;
- direct reset és reset utáni determinisztikus PCM;
- 8 blokkméreten azonos PCM;
- normál 30 s, stressz 30 s és normál 270 s referenciahash;
- Pi 5 csomagkapu legfeljebb 30% egy magos terhelés.
