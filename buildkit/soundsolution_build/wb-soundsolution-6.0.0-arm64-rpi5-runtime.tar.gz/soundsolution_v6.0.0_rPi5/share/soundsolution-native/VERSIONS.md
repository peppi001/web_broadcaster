# Versions

- Package version: `6.0.0`
- Engine version: `6.0.0`
- SONAME: `libsoundsolution.so.2`
- Arithmetic: `native-double`
- State layout: `named-state-v14/structured-process-flow`
- Process layout: `structured-process-v1/typed-state-loop`
