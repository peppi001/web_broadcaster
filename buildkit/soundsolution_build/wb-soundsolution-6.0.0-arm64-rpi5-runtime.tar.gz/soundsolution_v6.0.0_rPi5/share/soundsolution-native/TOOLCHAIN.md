# Toolchain

A fejlesztőgépes validáció GCC/G++ 14.2.0-val készült. A Pi-build GCC vagy
Clang C++20 fordítót igényel; a referencia továbbra is GCC 14.2.0. A build
warningként kezeli a `-Wall -Wextra -Wpedantic -Wconversion -Wshadow` által
jelzett problémákat, és a csomagoló script elutasítja a warningot tartalmazó
buildnaplót.
