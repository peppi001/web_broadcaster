# soundsolution_v6.0.0_rPi5

SoundSolution Native **6.0.0 structured process flow**, Raspberry Pi 5-re.

A 6.0.0 a 5.1.0 bitazonos native-double DSP-jét tartja meg, de a process
vezérlés utolsó mechanikusan fordított x86-szerű formáját is eltávolítja.

## Fő változások

- nincs `goto`;
- nincs numerikus `L_1000...` címke;
- nincs `eax/ebx/ecx/edx/esi/edi/esp/ebp` azonosító;
- nincs `x87_compat.hpp`, `X87` vagy `x87_*` elnevezés;
- a process egy típusos `ProcessStage` enumot, `for` ciklust és `switch` vezérlést használ;
- a process állapota híváslokális `ProcessCallState`;
- a 512 bájtos frame kizárólag natív scratch tároló;
- configure, postload és reset továbbra is közvetlen, stack nélküli C++;
- nincs process-kódot tartalmazó `.inc`; csak a két konstans adatfájl maradt.

A matematikai sorrend, a binary64 visszaírási pontok és a PCM referenciahashek
változatlanok.

## Build Raspberry Pi 5-ön

```bash
tar -xzf soundsolution_v6.0.0_rPi5-structured-process-flow.tar.gz
cd soundsolution_v6.0.0_rPi5
SSNATIVE_RUN_LONG_VALIDATION=1 ./build.sh
```

A runtime kimenete:

```text
_dist/soundsolution_v6.0.0_rPi5.tar.gz
```

## Stabil C ABI

A SONAME továbbra is `libsoundsolution.so.2`. Az 5.x C API kompatibilis; az új
`ssnative_structured_process_stage_count()` diagnosztikai függvény additív.
