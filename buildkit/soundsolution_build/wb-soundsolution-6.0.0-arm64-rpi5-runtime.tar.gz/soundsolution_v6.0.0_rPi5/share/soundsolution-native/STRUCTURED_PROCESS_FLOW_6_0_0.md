# Structured process-flow milestone — 6.0.0

## Cél

A process C++ forrásból eltávolítani minden numerikus címkét, `goto` ágat,
x86 regiszternevet és x87-kompatibilitási elnevezést a PCM megváltoztatása
nélkül.

## Eredmény

- `goto`: 0
- numerikus process címke: 0
- x86 regiszterazonosító: 0
- x87-prefixed szimbólum: 0
- runtime instruction table: nincs
- runtime dispatcher: nincs
- continuation state: 0 bájt
- process-kód `.inc`: nincs
- típusos process stage: 87
- híváslokális natív frame: 512 bájt

A 87 stage nem bytecode vagy interpreter. A fordító közvetlen gépi kódot készít
a `switch` egyes ágaiból, és a friss PGO profil a tényleges ágvalószínűségeket
rögzíti.

## Numerikus kompatibilitás

A `NativeDouble` továbbra is IEEE-754 binary64. A műveleti sorrend és a
memóriába történő visszaírások helye nem változott, ezért a 3, 30, stressz és
270 másodperces PCM-kapuknak bitre egyezniük kell az 5.1.0-val.
