# Build method

A Raspberry Pi 5 build lefuttatja a named-state és integrated process source auditot,
friss, 30 másodperces PGO-profilt készít, majd `-fprofile-use` módban újrafordít.

A process közvetlen C++ body: nincs runtime programtábla, interpreter,
continuation vagy tartós process workspace. Minden hívás saját 512 bájtos natív
scratch frame-et kap. A végleges build kötelezően ellenőrzi a blokkhatár-,
30 másodperces, stressz- és opcionálisan a 270 másodperces PCM-hasheket.
