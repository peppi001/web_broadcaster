# SoundSolution Native 6.0.0 — structured process flow

A 6.0.0 a process utolsó x86-szerű vezérlési maradványait távolítja el.

## Eltávolítva

- 86 numerikus process címke;
- 110 `goto` ág;
- a nyolc x86 regiszternév;
- az x87 kompatibilitási elnevezések;
- a mechanikus `original-index` utasításkommentek.

## Új szerkezet

- 87 típusos `ProcessStage` állapot;
- strukturált `for (;;)` + `switch` vezérlés;
- `ProcessFlow`, `ProcessCondition`, `ProcessFloatingValues` és
  `ProcessCallState` típusok;
- `NativeDouble` és `NativeDoublePair` aritmetikai elnevezések.

A state loop nem runtime interpreter: minden case közvetlenül lefordított C++
kód, nincs programtábla, opcode-dispatch, continuation vagy dinamikus
allokáció.

## Referenciahashek

- 3 s: `ea5c85b2ebb0100fa44585ec4f106a9cae8b61c16489ff358beddf6ac181d49a`
- 30 s: `a1a4768be678cc2bffe50828a2eb1de655d1125a9ebad063de07b1776dac3e12`
- stressz 30 s: `5d2a39e1a2eddf9d27744117bf13f6a5ce26ae72414144c435089e91a8001235`
- 270 s: `8d4c8140b967dddbb94a0c91e4381d0caeff326cdbff105fdbcf757e1cfea09c`

A Raspberry Pi 5 célgépes terhelés a felhasználói build után rögzíthető.
