# Build verification

A kiadási build kötelező kapui:

- warningmentes Release/PGO build;
- 3/3 CTest;
- 8 blokkméret bitazonossága;
- 30 másodperces normál és stressz referencia;
- opcionális 270 másodperces hosszú referencia;
- configure/postload stack: 0 bájt;
- configure/postload statikus művelet: 0;
- egyetlen megmaradt fordított vezérlési tartomány: process hot path;
- `libsoundsolution.so.2` SONAME.
