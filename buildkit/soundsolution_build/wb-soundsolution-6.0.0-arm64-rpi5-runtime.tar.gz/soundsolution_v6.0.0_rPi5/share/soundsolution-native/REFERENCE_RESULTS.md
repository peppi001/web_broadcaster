# Reference results

A 6.0.0 bitazonos az 5.1.0/5.0.0 native-double referenciával.

- 3 s: `ea5c85b2ebb0100fa44585ec4f106a9cae8b61c16489ff358beddf6ac181d49a`
- 30 s: `a1a4768be678cc2bffe50828a2eb1de655d1125a9ebad063de07b1776dac3e12`
- stressz 30 s: `5d2a39e1a2eddf9d27744117bf13f6a5ce26ae72414144c435089e91a8001235`
- 270 s: `8d4c8140b967dddbb94a0c91e4381d0caeff326cdbff105fdbcf757e1cfea09c`
