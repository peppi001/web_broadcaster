# Warning policy

A profilgeneráló és a végleges buildnek nulla compiler warninggal kell
lefutnia a referencia toolchainnel. Aktív: `-Wall -Wextra -Wpedantic
-Wconversion -Wshadow`.
