# License status

A csomag a felhasználó által biztosított visszafejtési és portolási projekt
forrását tartalmazza. Nyilvános terjesztés előtt a projekt tulajdonosának kell
ellenőriznie az eredeti SoundSolution komponensekhez és visszafejtett adatokhoz
kapcsolódó jogokat.
