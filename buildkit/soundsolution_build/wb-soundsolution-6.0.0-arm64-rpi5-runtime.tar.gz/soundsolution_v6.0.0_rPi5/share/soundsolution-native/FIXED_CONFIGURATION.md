# Fixed configuration

- `SSNATIVE_CPU_LEVEL=raspberry-pi-5`
- `SSNATIVE_X87_BACKEND=double`
- `SSNATIVE_OPTIMIZATION_LEVEL=3`
- auto-vectorization enabled
- FMA contraction disabled
- native M13 state/output, band, delay, prefilter and postfilter blocks enabled
- outlined stereo biquad, one-pole and fourth-order bodies enabled
- exact M14 binary80 assembly disabled
